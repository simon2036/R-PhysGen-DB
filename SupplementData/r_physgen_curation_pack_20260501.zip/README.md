# R-PhysGen-DB curation pack

Files in this pack:

- `manual_property_observations_supplement_20260501.csv`: strict-candidate manual observation rows for exact public GWP/safety evidence.
- `resolve_mix511a_curations.py`: repository-root script that writes traceable `MIX_511A` fraction curations using existing component `mol_id` values.
- `property_governance_20260422_unresolved_curations_template.csv`: exact-column template for governance identity crosswalks.
- `governance_substance_curation_workflow.md`: rule-based governance curation procedure.
- `active_learning_queue_template.csv` and `active_learning_decision_log_template.csv`: optional raw manual input templates.
- `active_learning_manual_closure.sql`: DuckDB queries to triage human follow-ups and generate decision-log rows.
- `ci_build_validate_gate_proposal.yml`: CI expansion proposal; make the rebuild job required only after artifact/runtime policy is settled.

Important cautions:

1. Append the supplement CSV only after checking duplicate rows against the current `data/raw/manual/manual_property_observations.csv`.
2. `tierc_candidate_1336mzzz` and `tierc_candidate_1224ydz` have PubChem failures in the current quality report; property rows will only reach model layers if identity resolution succeeds.
3. R-1132a and R-1132(E) GWP entries with `<1`/`<<1` were intentionally not converted into strict numeric rows. Keep those as review-queue items unless the repository adds an explicit upper-bound value policy.
4. `resolve_mix511a_curations.py` will fail closed if it cannot classify the existing component IDs as R-290 and E170 by alias evidence.
