# R-PhysGen-DB governance substance curation workflow

This workflow targets the remaining unmapped governance substances. It is meant for `data/raw/manual/property_governance_20260422_unresolved_curations.csv` and follows the repository contract: only high-confidence, single-structure identity resolutions should enter the ingestion file.

## Intake fields

Use the repository contract columns exactly:

`substance_id,refrigerant_number,cas_number,canonical_smiles,isomeric_smiles,inchi,inchikey,resolution_source,resolution_source_url,resolution_confidence,notes`

Do not add property values here. This file is identity-resolution only.

## Resolution rule

Accept a row only when all available identifiers resolve to one structure:

1. CAS Registry Number, refrigerant number/name, PubChem CID/InChIKey, and any governance bundle name are mutually consistent.
2. The structure has one canonical InChIKey and no unresolved E/Z or stereochemical ambiguity.
3. `resolution_confidence` is `high`.
4. `notes` states the crosswalk basis, e.g. `CAS+PubChem+ASHRAE designation agree; no stereochemical ambiguity`.

Reject or hold for manual review when:
- the CAS points to a mixture or formulation rather than a single molecule;
- the refrigerant number is a blend designation;
- aliases map to multiple PubChem CIDs or stereoisomers;
- the source is a vendor-only marketing page without a structure;
- the source only provides a property, not identity evidence.

## Triage order for the 73-row queue

First pass:
- exact CAS -> PubChem CID -> InChIKey;
- exact R-number -> ASHRAE refrigerant designation table;
- exact blend IDs -> route to mixture tables, not molecule_core.

Second pass:
- normalize punctuation and isomer notation: `R1224ydZ`, `R-1224yd(Z)`, `HCFO-1224yd(Z)`;
- normalize E/Z aliases and common misspellings;
- normalize `E170`, `R-E170`, `dimethyl ether`, `methoxymethane`.

Third pass:
- mark `hold_low_confidence` outside the ingestion CSV when any ambiguity remains.
