-- Active-learning manual closure queries for R-PhysGen-DB DuckDB index.
-- Run from repository root after build has produced data/index/r_physgen_v2.duckdb.

-- 1) Work queue by manual action.
SELECT recommended_next_action, status, COUNT(*) AS n
FROM active_learning_queue
GROUP BY 1, 2
ORDER BY 1, 2;

-- 2) Non-computational follow-ups that need human review first.
SELECT queue_entry_id, mol_id, campaign_id, recommended_next_action, priority_score,
       uncertainty_score, novelty_score, feasibility_score, hard_constraint_status, payload_json, notes
FROM active_learning_queue
WHERE status = 'proposed'
  AND recommended_next_action IN ('manual_curation', 'literature_search')
ORDER BY priority_score DESC, uncertainty_score DESC, novelty_score DESC;

-- 3) Proposed decision-log rows for completed quantum jobs with no decision record yet.
-- Review before appending to data/raw/manual/active_learning_decision_log.csv.
SELECT
  '' AS decision_id,
  q.queue_entry_id,
  'complete' AS decision_action,
  'closed' AS decision_status,
  'manual_curator' AS decided_by,
  CURRENT_TIMESTAMP AS decided_at,
  'source_r_physgen_quantum_pilot_csv' AS evidence_source_id,
  'closed after quantum result bundle loaded and validated' AS notes
FROM active_learning_queue q
LEFT JOIN active_learning_decision_log d USING (queue_entry_id)
WHERE q.recommended_next_action = 'run_quantum'
  AND q.status = 'completed'
  AND d.queue_entry_id IS NULL;
