#!/usr/bin/env python
"""Resolve and write MIX_511A/R-511A fraction curations from existing component mol_ids.

Run from the repository root after a current build has produced:
  data/silver/mixture_composition.parquet
  data/silver/molecule_alias.parquet

The script deliberately reads the component_mol_id values already present in
mixture_composition, then classifies the two rows by alias evidence. It does
not invent component identifiers and it does not estimate fractions.
"""

from __future__ import annotations

from pathlib import Path
import pandas as pd

ROOT = Path.cwd()
COMP_PATH = ROOT / "data" / "silver" / "mixture_composition.parquet"
ALIAS_PATH = ROOT / "data" / "silver" / "molecule_alias.parquet"
OUT_PATH = ROOT / "data" / "raw" / "manual" / "mixture_fraction_curations.csv"

SOURCE_ID = "source_manual_mixture_fraction_curations"
SOURCE_NAME = "Manual Mixture Fraction Curations"
SOURCE_URL = "https://www.ashrae.org/technical-resources/standards-and-guidelines/ashrae-refrigerant-designations"

REQUIRED_COLUMNS = [
    "mixture_id",
    "component_mol_id",
    "composition_basis",
    "fraction_value",
    "source_id",
    "source_name",
    "source_url",
    "notes",
]

PROPANE_ALIASES = {"r-290", "r290", "propane", "n-propane", "74-98-6"}
E170_ALIASES = {"e170", "r-e170", "re170", "dimethyl ether", "methoxymethane", "115-10-6"}


def normalize(value: object) -> str:
    return str(value or "").strip().lower()


def classify_component(mol_id: str, aliases: pd.DataFrame) -> tuple[str, float] | None:
    values = {normalize(v) for v in aliases.loc[aliases["mol_id"].astype(str) == mol_id, "alias_value"].tolist()}
    values.add(normalize(mol_id))
    if values & PROPANE_ALIASES:
        return ("R-290", 0.95)
    if values & E170_ALIASES:
        return ("E170", 0.05)
    return None


def main() -> None:
    if not COMP_PATH.exists():
        raise SystemExit(f"Missing {COMP_PATH}; run build first.")
    if not ALIAS_PATH.exists():
        raise SystemExit(f"Missing {ALIAS_PATH}; run build first.")

    comp = pd.read_parquet(COMP_PATH)
    aliases = pd.read_parquet(ALIAS_PATH)

    target = comp[
        (comp["mixture_id"].astype(str) == "MIX_511A")
        & (comp["composition_basis"].astype(str) == "mass_fraction")
    ].copy()

    if len(target) != 2:
        raise SystemExit(f"Expected exactly two MIX_511A mass_fraction component rows, found {len(target)}.")

    rows = []
    unresolved = []
    for _, row in target.iterrows():
        mol_id = str(row["component_mol_id"]).strip()
        classified = classify_component(mol_id, aliases)
        if classified is None:
            unresolved.append(mol_id)
            continue
        label, fraction = classified
        rows.append(
            {
                "mixture_id": "MIX_511A",
                "component_mol_id": mol_id,
                "composition_basis": "mass_fraction",
                "fraction_value": fraction,
                "source_id": SOURCE_ID,
                "source_name": SOURCE_NAME,
                "source_url": SOURCE_URL,
                "notes": (
                    "R-511A listed by ASHRAE as R-290/E170 (95.0/5.0) mass percent; "
                    f"classified existing component_mol_id as {label} by molecule_alias evidence"
                ),
            }
        )

    if unresolved:
        raise SystemExit(
            "Could not classify MIX_511A component_mol_id(s): "
            + ", ".join(unresolved)
            + ". Inspect molecule_alias for R-290/E170 aliases before writing strict curations."
        )
    if len(rows) != 2 or abs(sum(float(r["fraction_value"]) for r in rows) - 1.0) > 1e-12:
        raise SystemExit("Internal error: curated R-511A fractions do not contain two rows summing to 1.0.")

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    new_df = pd.DataFrame(rows, columns=REQUIRED_COLUMNS)

    if OUT_PATH.exists():
        existing = pd.read_csv(OUT_PATH).fillna("")
        for col in REQUIRED_COLUMNS:
            if col not in existing.columns:
                existing[col] = ""
        # Replace only the targeted MIX_511A mass_fraction rows; preserve all other manual curations.
        existing = existing[
            ~(
                (existing["mixture_id"].astype(str) == "MIX_511A")
                & (existing["composition_basis"].astype(str) == "mass_fraction")
            )
        ][REQUIRED_COLUMNS]
        out = pd.concat([existing, new_df], ignore_index=True)
    else:
        out = new_df

    out.to_csv(OUT_PATH, index=False)
    print(f"Wrote {len(new_df)} MIX_511A curation rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
