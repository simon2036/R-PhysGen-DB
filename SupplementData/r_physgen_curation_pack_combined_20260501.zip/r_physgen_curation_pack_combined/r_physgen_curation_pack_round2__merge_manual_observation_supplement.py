#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
KEY_COLUMNS=["seed_id","r_number","property_name","value","value_num","unit","source_name","source_url","assessment_version","time_horizon"]
def main():
    p=argparse.ArgumentParser(); p.add_argument("--base",default="data/raw/manual/manual_property_observations.csv"); p.add_argument("--supplement",required=True); p.add_argument("--out",default="data/raw/manual/manual_property_observations.csv"); a=p.parse_args()
    base=pd.read_csv(Path(a.base)).fillna(""); supp=pd.read_csv(Path(a.supplement)).fillna("")
    missing=[c for c in base.columns if c not in supp.columns]; extra=[c for c in supp.columns if c not in base.columns]
    if missing or extra: raise SystemExit(f"schema mismatch: missing={missing}; extra={extra}")
    merged=pd.concat([base,supp[base.columns]],ignore_index=True); before=len(merged); key=[c for c in KEY_COLUMNS if c in merged.columns]
    merged=merged.drop_duplicates(subset=key,keep="first").reset_index(drop=True); Path(a.out).parent.mkdir(parents=True,exist_ok=True); merged.to_csv(a.out,index=False)
    print(f"base_rows={len(base)} supplement_rows={len(supp)} output_rows={len(merged)} dropped_exact_duplicates={before-len(merged)}")
if __name__=="__main__": main()
