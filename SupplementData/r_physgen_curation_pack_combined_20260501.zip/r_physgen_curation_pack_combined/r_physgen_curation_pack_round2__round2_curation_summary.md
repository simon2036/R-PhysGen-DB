# R-PhysGen-DB curation supplement round 2 — 2026-05-01

This round adds 69 strict-eligible manual observation rows and 13 review-only inequality/bound evidence rows. Strict-eligible rows include only exact numeric GWP/ODP values or categorical ASHRAE safety/toxicity letters. Inequality values such as `<1`, `<<1`, or `<0.0004` are kept out of direct ingestion because the current strict/model-ready contract does not encode bound semantics.

Files:

- `manual_property_observations_supplement_round2_20260501.csv`
- `review_only_inequality_observations_round2_20260501.csv`
- `mix511a_fraction_evidence_round2_20260501.csv`
- `merge_manual_observation_supplement.py`
- `qc_manual_observation_supplement.py`

Suggested commands from repository root:

```bash
python /path/to/qc_manual_observation_supplement.py /path/to/manual_property_observations_supplement_round2_20260501.csv
python /path/to/merge_manual_observation_supplement.py --supplement /path/to/manual_property_observations_supplement_round2_20260501.csv
python pipelines/build_v1_dataset.py
python pipelines/validate_v1_dataset.py
python -m pytest -q tests/test_schema_contract.py tests/test_reproducibility_ci.py
```
