#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
REQUIRED=["seed_id","r_number","property_name","value","value_num","unit","temperature","pressure","phase","source_type","source_name","source_url","method","uncertainty","quality_level","assessment_version","time_horizon","year","notes"]
CATEGORICAL={"ashrae_safety","toxicity_class"}; NUMERIC={"gwp_100yr","gwp_20yr","odp","atmospheric_lifetime_yr"}
def main():
    p=argparse.ArgumentParser(); p.add_argument("csv_path"); a=p.parse_args(); df=pd.read_csv(Path(a.csv_path)).fillna("")
    missing=[c for c in REQUIRED if c not in df.columns]; extra=[c for c in df.columns if c not in REQUIRED]
    if missing or extra: raise SystemExit(f"schema mismatch: missing={missing}; extra={extra}")
    bad_num=df[df["property_name"].isin(NUMERIC) & (df["value_num"].astype(str).str.strip()=="")]
    if not bad_num.empty: raise SystemExit(f"numeric rows missing value_num: {bad_num[['seed_id','property_name','value']].to_dict('records')[:10]}")
    bad_cat=df[df["property_name"].isin(CATEGORICAL) & (df["value_num"].astype(str).str.strip()!="")]
    if not bad_cat.empty: raise SystemExit(f"categorical rows should not carry value_num: {bad_cat[['seed_id','property_name','value_num']].to_dict('records')[:10]}")
    if df["source_url"].astype(str).str.len().eq(0).any(): raise SystemExit("source_url missing in at least one row")
    print(f"ok rows={len(df)} numeric={df['property_name'].isin(NUMERIC).sum()} categorical={df['property_name'].isin(CATEGORICAL).sum()}")
if __name__=="__main__": main()
