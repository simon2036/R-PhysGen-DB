// Molecule browser + detail pages.

const { mols: allMols, canonical, observations, regulatory, properties } = window.DB;

const MoleculeBrowser = ({setPage, setSelectedMol, query}) => {
  const [tier, setTier] = useState("all");
  const [family, setFamily] = useState("all");
  const [inclusion, setInclusion] = useState("all");
  const [sort, setSort] = useState("r_name");

  const families = useMemo(()=>Array.from(new Set(allMols.map(m=>m.family))).sort(), []);

  const rows = useMemo(()=>{
    let rs = allMols;
    if (tier !== "all") rs = rs.filter(m=>m.tier===tier);
    if (family !== "all") rs = rs.filter(m=>m.family===family);
    if (inclusion !== "all") rs = rs.filter(m=>m.model_inclusion===inclusion);
    if (query && query.trim()) {
      const q = query.trim().toLowerCase();
      rs = rs.filter(m=>
        m.mol_id.toLowerCase().includes(q) ||
        (m.r_name||"").toLowerCase().includes(q) ||
        (m.formula||"").toLowerCase().includes(q) ||
        (m.cas||"").toLowerCase().includes(q) ||
        (m.inchikey||"").toLowerCase().includes(q) ||
        (m.family||"").toLowerCase().includes(q)
      );
    }
    const dir = sort.startsWith("-") ? -1 : 1;
    const key = sort.replace(/^-/, "");
    rs = [...rs].sort((a,b)=>{
      const av = a[key], bv = b[key];
      if (av==null && bv==null) return 0;
      if (av==null) return 1;
      if (bv==null) return -1;
      return av > bv ? dir : av < bv ? -dir : 0;
    });
    return rs;
  }, [tier, family, inclusion, sort, query]);

  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">silver · molecule_core.parquet</div>
        <h1 className="page-title">Molecules</h1>
        <p className="page-sub">
          Resolved single-component refrigerant molecules and candidate species.
          The full inventory includes {fmtInt(5598)} rows; the promoted model-ready subset
          holds {fmtInt(120)} tier A/B/C molecules.
        </p>
      </div>

      <div className="card">
        <div className="filterbar">
          <span className="filter-label">Tier</span>
          <div className="chip-group">
            {["all","A","B","C","D"].map(t=>(
              <button key={t} className={"chip "+(tier===t?"active":"")} onClick={()=>setTier(t)}>
                {t==="all"?"All":t}
              </button>
            ))}
          </div>
          <span className="filter-label" style={{marginLeft:8}}>Model</span>
          <div className="chip-group">
            {["all","yes","no"].map(v=>(
              <button key={v} className={"chip "+(inclusion===v?"active":"")} onClick={()=>setInclusion(v)}>
                {v==="all"?"All":(v==="yes"?"Included":"Excluded")}
              </button>
            ))}
          </div>
          <span className="filter-label" style={{marginLeft:8}}>Family</span>
          <select className="select" value={family} onChange={e=>setFamily(e.target.value)}>
            <option value="all">All families</option>
            {families.map(f=><option key={f} value={f}>{f}</option>)}
          </select>
          <div style={{marginLeft:"auto", display:"flex", alignItems:"center", gap:8}}>
            <span className="mono subtle" style={{fontSize:11.5}}>{fmtInt(rows.length)} of {fmtInt(allMols.length)} shown</span>
            <button className="btn sm ghost"><Icon name="download" size={12}/> CSV</button>
          </div>
        </div>

        <div style={{maxHeight:"calc(100vh - 280px)", overflowY:"auto"}}>
          <table className="data-table">
            <thead>
              <tr>
                <SortHead label="ID"       k="mol_id"   sort={sort} setSort={setSort}/>
                <SortHead label="Name"     k="r_name"   sort={sort} setSort={setSort}/>
                <th>Formula</th>
                <SortHead label="MW"       k="mw"       sort={sort} setSort={setSort} align="right"/>
                <th>Family</th>
                <th>Tier</th>
                <SortHead label="NBP / K"  k="nbp"      sort={sort} setSort={setSort} align="right"/>
                <SortHead label="Tc / K"   k="tcrit"    sort={sort} setSort={setSort} align="right"/>
                <SortHead label="GWP"      k="gwp"      sort={sort} setSort={setSort} align="right"/>
                <SortHead label="ODP"      k="odp"      sort={sort} setSort={setSort} align="right"/>
                <th>ASHRAE</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map(m=>(
                <tr key={m.mol_id} onClick={()=>{setSelectedMol(m.mol_id); setPage("molecule");}}>
                  <td className="col-id">{m.mol_id}</td>
                  <td className="col-name" style={{fontFamily:"var(--font-serif)"}}>{m.r_name}</td>
                  <td className="mono" style={{fontSize:12.5}}><Formula str={m.formula}/></td>
                  <td className="col-num">{fmt(m.mw,2)}</td>
                  <td><span className="mono subtle" style={{fontSize:11.5}}>{m.family}</span></td>
                  <td><TierPill tier={m.tier}/></td>
                  <td className="col-num">{fmt(m.nbp,1)}</td>
                  <td className="col-num">{fmt(m.tcrit,1)}</td>
                  <td className="col-num">{fmt(m.gwp,0)}</td>
                  <td className="col-num">{m.odp==null?"—":fmt(m.odp,3)}</td>
                  <td><SafetyPill cls={m.ashrae}/></td>
                  <td><Icon name="chevron" size={14}/></td>
                </tr>
              ))}
              {rows.length===0 && (
                <tr><td colSpan="12" className="empty">No molecules match these filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const SortHead = ({label, k, sort, setSort, align}) => {
  const active = sort===k || sort==="-"+k;
  const desc = sort==="-"+k;
  return (
    <th style={{cursor:"pointer", textAlign:align||"left"}}
        onClick={()=>setSort(active && !desc ? "-"+k : k)}>
      <span style={{display:"inline-flex", alignItems:"center", gap:4, opacity: active?1:0.8}}>
        {label}
        {active && <span style={{fontSize:9, color:"var(--accent)"}}>{desc?"▼":"▲"}</span>}
      </span>
    </th>
  );
};

// ---------------------------------------------------------------- Detail page
const MoleculeDetail = ({molId, setPage}) => {
  const m = allMols.find(x=>x.mol_id===molId);
  const [tab, setTab] = useState("properties");
  if (!m) return <div className="page"><div className="empty">Molecule not found.</div></div>;

  const molCanon = canonical.filter(c=>c.mol_id===molId);
  const molObs = observations.filter(o=>o.mol_id===molId);
  const molReg = regulatory.filter(r=>r.mol_id===molId);

  // group canonical by property group
  const byGroup = {};
  molCanon.forEach(c=>{
    const prop = properties.find(p=>p.key===c.canonical_feature_key);
    const g = prop?.group || "Other";
    (byGroup[g] = byGroup[g] || []).push({...c, prop});
  });

  return (
    <div className="page">
      <div className="crumbs">
        <a onClick={()=>setPage("molecules")}>Molecules</a>
        <span className="sep">›</span>
        <span>{m.mol_id}</span>
      </div>

      {/* Hero */}
      <div className="hero-panel">
        <div className="struct-box">
          <div className="struct-stripes"/>
          <div className="placeholder-label">2D STRUCTURE · placeholder</div>
          <span className="struct-formula"><Formula str={m.formula}/></span>
        </div>
        <div>
          <div style={{display:"flex", alignItems:"baseline", gap:12, marginBottom:4}}>
            <h1 style={{fontFamily:"var(--font-serif)", fontSize:32, fontWeight:600, margin:0, letterSpacing:"-0.02em"}}>
              {m.r_name}
            </h1>
            <TierPill tier={m.tier}/>
            <span className={"pill " + (m.model_inclusion==="yes"?"accent":"ghost")}>
              <span className="pill-dot"/>model {m.model_inclusion}
            </span>
          </div>
          <div className="mono subtle" style={{fontSize:12, marginBottom:18}}>{m.mol_id} · {m.family}</div>
          <dl className="kv-list" style={{gridTemplateColumns:"140px 1fr"}}>
            <dt>Formula</dt><dd><Formula str={m.formula}/></dd>
            <dt>Molecular weight</dt><dd>{fmt(m.mw,3)} g·mol⁻¹</dd>
            <dt>SMILES</dt><dd style={{wordBreak:"break-all"}}>{m.smiles}</dd>
            <dt>InChIKey</dt><dd>{m.inchikey}</dd>
            <dt>CAS RN</dt><dd>{m.cas}</dd>
            <dt>Applications</dt>
            <dd style={{fontFamily:"var(--font-sans)"}}>
              {(m.applications||[]).map((a,i)=>(
                <span key={i} className="pill" style={{marginRight:4, marginBottom:4}}>{a}</span>
              ))}
            </dd>
          </dl>
        </div>
        <div style={{display:"flex", flexDirection:"column", gap:8}}>
          <button className="btn sm"><Icon name="copy" size={12}/> Copy InChIKey</button>
          <button className="btn sm"><Icon name="external" size={12}/> PubChem</button>
          <button className="btn sm"><Icon name="external" size={12}/> NIST WebBook</button>
          <button className="btn sm primary"><Icon name="download" size={12}/> Download record</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        {[
          {id:"properties", label:"Canonical properties", badge: molCanon.length},
          {id:"observations", label:"Observations", badge: molObs.length},
          {id:"regulatory", label:"Regulatory", badge: molReg.length},
          {id:"provenance", label:"Provenance & QC"},
        ].map(t=>(
          <button key={t.id} className={"tab "+(tab===t.id?"active":"")} onClick={()=>setTab(t.id)}>
            {t.label}{t.badge!=null && <span className="subtle mono" style={{marginLeft:6, fontSize:11}}>{t.badge}</span>}
          </button>
        ))}
      </div>

      {tab==="properties" && <PropertiesTab byGroup={byGroup}/>}
      {tab==="observations" && <ObservationsTab obs={molObs}/>}
      {tab==="regulatory" && <RegulatoryTab reg={molReg}/>}
      {tab==="provenance" && <ProvenanceTab canon={molCanon} obs={molObs}/>}
    </div>
  );
};

const PropertiesTab = ({byGroup}) => {
  const order = ["Thermodynamic","Environmental","Safety","Structural","Cycle","Other"];
  return (
    <div>
      {order.filter(g=>byGroup[g]).map(g=>(
        <div key={g}>
          <div className="section-title">{g}</div>
          <div className="grid-3">
            {byGroup[g].map(c=>(
              <PropertyCard key={c.canonical_feature_key} c={c}/>
            ))}
          </div>
        </div>
      ))}
      {Object.keys(byGroup).length===0 && (
        <div className="empty"><div className="icon">◌</div>No canonical rows — inventory-only.</div>
      )}
    </div>
  );
};

const PropertyCard = ({c}) => {
  const p = c.prop;
  const cls = c.conflict_flag ? "conflict" : c.is_proxy_or_screening ? "proxy" : c.in_strict ? "strict" : "";
  return (
    <div className={"property-card " + cls}>
      <div className="prop-name">
        <span>{p?.name || c.canonical_feature_key}</span>
        {c.in_strict && <span className="pill good" style={{fontSize:10}}><span className="pill-dot"/>strict</span>}
        {c.is_proxy_or_screening && <span className="pill" style={{fontSize:10}}>proxy</span>}
        {c.conflict_flag && <span className="pill warn" style={{fontSize:10}}>conflict</span>}
      </div>
      <div>
        <span className="prop-value">{fmt(isNaN(Number(c.value)) ? c.value : Number(c.value), 4)}</span>
        <span className="prop-unit">{c.unit==="—"?"":c.unit}</span>
      </div>
      <div className="prop-src">
        <span style={{flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}} title={c.selected_source_name}>
          {c.selected_source_name}
        </span>
        <span>rank {c.source_priority_rank}</span>
      </div>
      <div className="quality-bar" title={"quality "+c.data_quality_score_100}>
        <div style={{width: (c.data_quality_score_100||0)+"%"}}/>
      </div>
    </div>
  );
};

const ObservationsTab = ({obs}) => (
  <div className="card" style={{padding:0}}>
    <div className="scroll-x">
      <table className="data-table">
        <thead>
          <tr>
            <th>Observation</th>
            <th>Property</th>
            <th>Value</th>
            <th>Unit</th>
            <th>T / K</th>
            <th>P / kPa</th>
            <th>Phase</th>
            <th>Source</th>
            <th>Type</th>
            <th>Quality</th>
            <th>QC</th>
          </tr>
        </thead>
        <tbody>
          {obs.map(o=>(
            <tr key={o.observation_id}>
              <td className="col-id">{o.observation_id}</td>
              <td><span className="mono" style={{fontSize:12}}>{o.canonical_feature_key||o.property_name}</span></td>
              <td className="col-num strong">{typeof o.value==="number"?fmt(o.value,3):o.value}</td>
              <td className="mono subtle" style={{fontSize:12}}>{o.unit}</td>
              <td className="col-num">{fmt(o.temperature,2)}</td>
              <td className="col-num">{fmt(o.pressure,2)}</td>
              <td><span className="pill" style={{fontSize:10}}>{o.phase||"—"}</span></td>
              <td style={{fontSize:12}}>{o.source}</td>
              <td><span className="pill" style={{fontSize:10}}>{o.source_type}</span></td>
              <td><span className="pill" style={{fontSize:10}}>{o.quality}</span></td>
              <td>
                {o.qc==="pass" ? <span className="pill good" style={{fontSize:10}}>pass</span>
                               : <span className="pill warn" style={{fontSize:10}}>flag</span>}
              </td>
            </tr>
          ))}
          {obs.length===0 && <tr><td colSpan="11" className="empty">No observations.</td></tr>}
        </tbody>
      </table>
    </div>
  </div>
);

const RegulatoryTab = ({reg}) => (
  <div className="card" style={{padding:0}}>
    <table className="data-table">
      <thead>
        <tr><th>Jurisdiction</th><th>End use</th><th>Acceptability</th><th>Effective</th></tr>
      </thead>
      <tbody>
        {reg.map((r,i)=>(
          <tr key={i}>
            <td className="strong">{r.jurisdiction}</td>
            <td>{r.end_use}</td>
            <td>
              <span className={"pill " + (
                /Accept/i.test(r.acceptability) ? "good" :
                /Banned|Unacceptable/i.test(r.acceptability) ? "danger" :
                /Phase/i.test(r.acceptability) ? "warn" : ""
              )}>
                {r.acceptability}
              </span>
            </td>
            <td className="mono subtle" style={{fontSize:12}}>{r.effective}</td>
          </tr>
        ))}
        {reg.length===0 && <tr><td colSpan="4" className="empty">No regulatory records.</td></tr>}
      </tbody>
    </table>
  </div>
);

const ProvenanceTab = ({canon, obs}) => {
  // source breakdown
  const bySource = {};
  obs.forEach(o=>{ bySource[o.source] = (bySource[o.source]||0) + 1; });
  const entries = Object.entries(bySource).sort((a,b)=>b[1]-a[1]);
  const total = obs.length || 1;
  return (
    <div className="grid-2">
      <div className="card">
        <div className="card-head"><div className="card-title">Source composition</div>
          <div className="card-sub">{total} obs</div></div>
        <div className="card-body">
          {entries.map(([src,n])=>(
            <div key={src} style={{marginBottom:10}}>
              <div style={{display:"flex", justifyContent:"space-between", marginBottom:4, fontSize:12.5}}>
                <span>{src}</span>
                <span className="mono subtle">{n}</span>
              </div>
              <div style={{height:5, background:"var(--bg-sunken)", borderRadius:3, overflow:"hidden"}}>
                <div style={{height:"100%", width: (n/total*100)+"%", background:"var(--accent)"}}/>
              </div>
            </div>
          ))}
          {entries.length===0 && <div className="empty">No provenance data.</div>}
        </div>
      </div>
      <div className="card">
        <div className="card-head"><div className="card-title">Canonical selection flags</div>
          <div className="card-sub">{canon.length} features</div></div>
        <div className="card-body">
          <div className="kv-list" style={{gridTemplateColumns:"auto 1fr"}}>
            <dt>Strict-layer eligible</dt>
              <dd>{canon.filter(c=>c.in_strict).length} of {canon.length}</dd>
            <dt>Proxy-only</dt>
              <dd>{canon.filter(c=>c.is_proxy_or_screening).length}</dd>
            <dt>Conflict flagged</dt>
              <dd>{canon.filter(c=>c.conflict_flag).length}</dd>
            <dt>Source divergence</dt>
              <dd>{canon.filter(c=>c.source_divergence_flag).length}</dd>
          </div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { MoleculeBrowser, MoleculeDetail });
