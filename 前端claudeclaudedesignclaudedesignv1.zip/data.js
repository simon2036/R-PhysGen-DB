// R-PhysGen-DB mock dataset — seeded from real schema + README numbers.
// Faithful to the layered semantics: silver observations → gold canonical → strict.

window.DB = (function () {
  // ---- Refrigerant catalog (curated / well-known) ---------------------------
  // Fields match molecule_core + a few gold summary columns.
  const mols = [
    {mol_id:"MOL_R32",     r_name:"R-32",       family:"HFC",  formula:"CH2F2",        mw:52.02,   smiles:"FCF",                  inchikey:"RWRIWBAIICGTTQ-UHFFFAOYSA-N", cas:"75-10-5",    tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:675,  ashrae:"A2L", tox:"A",   nbp:221.5,  tcrit:351.3, pcrit:5782, applications:["residential AC","heat pump"]},
    {mol_id:"MOL_R125",    r_name:"R-125",      family:"HFC",  formula:"C2HF5",        mw:120.02,  smiles:"FC(F)C(F)(F)F",        inchikey:"JEHSMTGPNBGYBN-UHFFFAOYSA-N", cas:"354-33-6",   tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:3500, ashrae:"A1",  tox:"A",   nbp:225.1,  tcrit:339.2, pcrit:3618, applications:["blend component"]},
    {mol_id:"MOL_R134a",   r_name:"R-134a",     family:"HFC",  formula:"C2H2F4",       mw:102.03,  smiles:"FC(F)(F)CF",           inchikey:"LVGUZGTVOIAKKC-UHFFFAOYSA-N", cas:"811-97-2",   tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:1430, ashrae:"A1",  tox:"A",   nbp:247.1,  tcrit:374.2, pcrit:4059, applications:["automotive AC","chillers"]},
    {mol_id:"MOL_R143a",   r_name:"R-143a",     family:"HFC",  formula:"C2H3F3",       mw:84.04,   smiles:"CC(F)(F)F",            inchikey:"RXACYZCNTXJHRB-UHFFFAOYSA-N", cas:"420-46-2",   tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:4470, ashrae:"A2L", tox:"A",   nbp:225.9,  tcrit:346.3, pcrit:3761, applications:["blend component"]},
    {mol_id:"MOL_R152a",   r_name:"R-152a",     family:"HFC",  formula:"C2H4F2",       mw:66.05,   smiles:"CC(F)F",               inchikey:"NUJOXMJBOLGQSY-UHFFFAOYSA-N", cas:"75-37-6",    tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:124,  ashrae:"A2",  tox:"A",   nbp:249.1,  tcrit:386.4, pcrit:4516, applications:["aerosol","foam"]},
    {mol_id:"MOL_R1234yf", r_name:"R-1234yf",   family:"HFO",  formula:"C3H2F4",       mw:114.04,  smiles:"FC(F)=CC(F)(F)F",      inchikey:"UJPMYEOUBPIPHQ-UHFFFAOYSA-N", cas:"754-12-1",   tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:4,    ashrae:"A2L", tox:"A",   nbp:243.7,  tcrit:367.9, pcrit:3382, applications:["automotive AC"]},
    {mol_id:"MOL_R1234ze", r_name:"R-1234ze(E)",family:"HFO",  formula:"C3H2F4",       mw:114.04,  smiles:"F/C=C/C(F)(F)F",       inchikey:"CDOOAUSHHFGWSA-OWOJBTEDSA-N", cas:"29118-24-9", tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:6,    ashrae:"A2L", tox:"A",   nbp:254.2,  tcrit:382.5, pcrit:3636, applications:["chillers","aerosol"]},
    {mol_id:"MOL_R1233zd", r_name:"R-1233zd(E)",family:"HCFO", formula:"C3H2ClF3",     mw:130.49,  smiles:"Cl/C=C/C(F)(F)F",      inchikey:"FNRMEGVHLFBGTA-ONEGZZNKSA-N", cas:"102687-65-0",tier:"A", model_inclusion:"yes", status:"resolved", odp:0.00034,gwp:1,   ashrae:"A1",  tox:"A",   nbp:291.5,  tcrit:439.6, pcrit:3623, applications:["low-pressure chillers","foam"]},
    {mol_id:"MOL_R1336mzz",r_name:"R-1336mzz(Z)",family:"HFO", formula:"C4H2F6",       mw:164.06,  smiles:"F/C(=C\\C(F)(F)F)C(F)(F)F", inchikey:"NJQSGWKNIQJJAR-UHFFFAOYSA-N", cas:"692-49-9", tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0, gwp:2, ashrae:"A1", tox:"A", nbp:306.6, tcrit:444.5, pcrit:2903, applications:["ORC","high-T heat pump"]},
    {mol_id:"MOL_R744",    r_name:"R-744",      family:"Natural",formula:"CO2",        mw:44.01,   smiles:"O=C=O",                inchikey:"CURLTUGMZLYLDI-UHFFFAOYSA-N", cas:"124-38-9",   tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:1,    ashrae:"A1",  tox:"A",   nbp:194.7,  tcrit:304.1, pcrit:7377, applications:["transcritical","commercial refrig."]},
    {mol_id:"MOL_R717",    r_name:"R-717",      family:"Natural",formula:"NH3",        mw:17.03,   smiles:"N",                    inchikey:"QGZKDVFQNNGYKY-UHFFFAOYSA-N", cas:"7664-41-7",  tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:0,    ashrae:"B2L", tox:"B",   nbp:239.8,  tcrit:405.4, pcrit:11333,applications:["industrial refrig."]},
    {mol_id:"MOL_R290",    r_name:"R-290",      family:"Natural",formula:"C3H8",       mw:44.10,   smiles:"CCC",                  inchikey:"ATUOYWHBWRKTHZ-UHFFFAOYSA-N", cas:"74-98-6",    tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:3,    ashrae:"A3",  tox:"A",   nbp:231.0,  tcrit:369.8, pcrit:4248, applications:["domestic refrig.","heat pump"]},
    {mol_id:"MOL_R600a",   r_name:"R-600a",     family:"Natural",formula:"C4H10",      mw:58.12,   smiles:"CC(C)C",               inchikey:"NNPPMTNAJDCUHE-UHFFFAOYSA-N", cas:"75-28-5",    tier:"A", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:3,    ashrae:"A3",  tox:"A",   nbp:261.4,  tcrit:407.8, pcrit:3629, applications:["domestic refrig."]},
    {mol_id:"MOL_R22",     r_name:"R-22",       family:"HCFC", formula:"CHClF2",       mw:86.47,   smiles:"ClC(F)F",              inchikey:"QPFMBZIOSGYJDE-UHFFFAOYSA-N", cas:"75-45-6",    tier:"B", model_inclusion:"yes", status:"resolved", odp:0.055, gwp:1810, ashrae:"A1",  tox:"A",   nbp:232.4,  tcrit:369.3, pcrit:4990, applications:["(phase-out)"]},
    {mol_id:"MOL_R11",     r_name:"R-11",       family:"CFC",  formula:"CCl3F",        mw:137.37,  smiles:"FC(Cl)(Cl)Cl",         inchikey:"CYRMSUTZVYGINF-UHFFFAOYSA-N", cas:"75-69-4",    tier:"B", model_inclusion:"yes", status:"resolved", odp:1.0,   gwp:4750, ashrae:"A1",  tox:"A",   nbp:296.8,  tcrit:471.1, pcrit:4394, applications:["(banned)"]},
    {mol_id:"MOL_R12",     r_name:"R-12",       family:"CFC",  formula:"CCl2F2",       mw:120.91,  smiles:"FC(F)(Cl)Cl",          inchikey:"PXBRQCKWGAHEHS-UHFFFAOYSA-N", cas:"75-71-8",    tier:"B", model_inclusion:"yes", status:"resolved", odp:1.0,   gwp:10900,ashrae:"A1",  tox:"A",   nbp:243.4,  tcrit:385.1, pcrit:4136, applications:["(banned)"]},
    {mol_id:"MOL_R123",    r_name:"R-123",      family:"HCFC", formula:"C2HCl2F3",     mw:152.93,  smiles:"OC(F)(F)C(Cl)(Cl)F".replace("O",""), inchikey:"UMIVXZPTRXBADB-UHFFFAOYSA-N", cas:"306-83-2", tier:"B", model_inclusion:"yes", status:"resolved", odp:0.02, gwp:77, ashrae:"B1", tox:"B", nbp:300.9, tcrit:456.8, pcrit:3662, applications:["low-pressure chillers"]},
    {mol_id:"MOL_R245fa",  r_name:"R-245fa",    family:"HFC",  formula:"C3H3F5",       mw:134.05,  smiles:"FC(F)CC(F)(F)F",       inchikey:"OBNCKNCVKJNDBV-UHFFFAOYSA-N", cas:"460-73-1",   tier:"B", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:1030, ashrae:"B1",  tox:"B",   nbp:288.3,  tcrit:427.2, pcrit:3651, applications:["ORC","blowing agent"]},
    {mol_id:"MOL_R1270",   r_name:"R-1270",     family:"Natural",formula:"C3H6",       mw:42.08,   smiles:"CC=C",                 inchikey:"QQONPFPTGQHPMA-UHFFFAOYSA-N", cas:"115-07-1",   tier:"B", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:2,    ashrae:"A3",  tox:"A",   nbp:225.5,  tcrit:364.2, pcrit:4555, applications:["industrial refrig."]},
    {mol_id:"MOL_R1150",   r_name:"R-1150",     family:"Natural",formula:"C2H4",       mw:28.05,   smiles:"C=C",                  inchikey:"VGGSQFUCUMXWEO-UHFFFAOYSA-N", cas:"74-85-1",    tier:"B", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:4,    ashrae:"A3",  tox:"A",   nbp:169.4,  tcrit:282.3, pcrit:5042, applications:["ultra-low-T"]},
    {mol_id:"MOL_R170",    r_name:"R-170",      family:"Natural",formula:"C2H6",       mw:30.07,   smiles:"CC",                   inchikey:"OTMSDBZUPAUEDD-UHFFFAOYSA-N", cas:"74-84-0",    tier:"B", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:6,    ashrae:"A3",  tox:"A",   nbp:184.6,  tcrit:305.3, pcrit:4872, applications:["cascade low-T"]},
    {mol_id:"MOL_R227ea",  r_name:"R-227ea",    family:"HFC",  formula:"C3HF7",        mw:170.03,  smiles:"FC(F)(F)C(F)C(F)(F)F", inchikey:"AGRIQBHIKABLPJ-UHFFFAOYSA-N", cas:"431-89-0",   tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:3220, ashrae:"A1",  tox:"A",   nbp:256.8,  tcrit:375.9, pcrit:2925, applications:["fire suppression"]},
    {mol_id:"MOL_R236fa",  r_name:"R-236fa",    family:"HFC",  formula:"C3H2F6",       mw:152.04,  smiles:"FC(F)(F)CC(F)(F)F",    inchikey:"PTXPMOUNTVRTJN-UHFFFAOYSA-N", cas:"690-39-1",   tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:9810, ashrae:"A1",  tox:"A",   nbp:271.7,  tcrit:398.1, pcrit:3200, applications:["fire suppression","ORC"]},
    {mol_id:"MOL_Novec649",r_name:"Novec 649",  family:"HFK",  formula:"C6F12O",       mw:316.04,  smiles:"CC(F)(F)C(=O)C(F)(F)C(F)(F)F".replace("C(F)(F)C(=O)","C(F)(F)C(F)C(=O)"), inchikey:"XWCDCDSDNJVCLO-UHFFFAOYSA-N", cas:"756-13-8", tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0, gwp:1, ashrae:"A1", tox:"A", nbp:322.2, tcrit:441.8, pcrit:1869, applications:["fire suppression","heat transfer"]},
    {mol_id:"MOL_R41",     r_name:"R-41",       family:"HFC",  formula:"CH3F",         mw:34.03,   smiles:"CF",                   inchikey:"NBVXSUQYWXRMNV-UHFFFAOYSA-N", cas:"593-53-3",   tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:92,   ashrae:null,  tox:null,  nbp:194.8,  tcrit:317.3, pcrit:5897, applications:["research"]},
    {mol_id:"MOL_R14",     r_name:"R-14",       family:"PFC",  formula:"CF4",          mw:88.00,   smiles:"FC(F)(F)F",            inchikey:"TXEYQDLBPFQVAA-UHFFFAOYSA-N", cas:"75-73-0",    tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:6630, ashrae:"A1",  tox:"A",   nbp:145.1,  tcrit:227.5, pcrit:3750, applications:["ultra-low-T"]},
    {mol_id:"MOL_R116",    r_name:"R-116",      family:"PFC",  formula:"C2F6",         mw:138.01,  smiles:"FC(F)(F)C(F)(F)F",     inchikey:"VOPWNXZWBYDODV-UHFFFAOYSA-N", cas:"76-16-4",    tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:11100,ashrae:"A1",  tox:"A",   nbp:194.9,  tcrit:293.0, pcrit:3048, applications:["ultra-low-T"]},
    {mol_id:"MOL_R218",    r_name:"R-218",      family:"PFC",  formula:"C3F8",         mw:188.02,  smiles:"FC(F)(F)C(F)(F)C(F)(F)F", inchikey:"QYSGYZVSCZSLHT-UHFFFAOYSA-N", cas:"76-19-7", tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0, gwp:8900, ashrae:"A1", tox:"A", nbp:236.4, tcrit:345.0, pcrit:2640, applications:["ultra-low-T","semiconductor"]},
    {mol_id:"MOL_DME",     r_name:"RE-170",     family:"Ether",formula:"C2H6O",        mw:46.07,   smiles:"COC",                  inchikey:"LCGLNKUTAGEVQW-UHFFFAOYSA-N", cas:"115-10-6",   tier:"C", model_inclusion:"yes", status:"resolved", odp:0.0,   gwp:1,    ashrae:"A3",  tox:"A",   nbp:248.3,  tcrit:400.4, pcrit:5336, applications:["propellant"]},
    // Tier D inventory-only samples (pubchem candidates, proxy-only)
    {mol_id:"MOL_CAND_00117",r_name:"—",        family:"HFO",  formula:"C4H3F5",       mw:146.06,  smiles:"FC=C(F)C(F)(F)CF",     inchikey:"ABXYZCAND1734-UHFFFAOYSA-N",  cas:"—",          tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
    {mol_id:"MOL_CAND_00284",r_name:"—",        family:"HFO",  formula:"C4H2F6",       mw:164.05,  smiles:"FC(F)=C(F)C(F)(F)CF",  inchikey:"QWERZCAND2841-UHFFFAOYSA-N",  cas:"—",          tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
    {mol_id:"MOL_CAND_00533",r_name:"—",        family:"HCFO", formula:"C3HClF4",      mw:148.49,  smiles:"ClC(F)=C(F)C(F)F",     inchikey:"POIUYCAND5332-UHFFFAOYSA-N",  cas:"—",          tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
    {mol_id:"MOL_CAND_01102",r_name:"—",        family:"Ether",formula:"C3H5F3O",      mw:114.06,  smiles:"COC(F)C(F)F",          inchikey:"LKJHGCAND1102-UHFFFAOYSA-N",  cas:"—",          tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
    {mol_id:"MOL_CAND_02019",r_name:"—",        family:"Nitrile",formula:"C2HF3N2",    mw:98.04,   smiles:"N#CC(F)(F)NF",         inchikey:"MNBVCCAND2019-UHFFFAOYSA-N",  cas:"—",          tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
    {mol_id:"MOL_CAND_03845",r_name:"—",        family:"HFO",  formula:"C5H3F7",       mw:196.07,  smiles:"FC(F)(F)C(F)=CC(F)(F)CF", inchikey:"ZXCVBCAND3845-UHFFFAOYSA-N", cas:"—",       tier:"D", model_inclusion:"no",  status:"resolved", odp:null, gwp:null, ashrae:null, tox:null, nbp:null, tcrit:null, pcrit:null, applications:["screening"]},
  ];

  // ---- Canonical property registry snippet ---------------------------------
  const properties = [
    {key:"thermo.nbp_k",                group:"Thermodynamic", name:"Normal boiling point",         unit:"K",      strict:true},
    {key:"thermo.critical_temperature_k",group:"Thermodynamic",name:"Critical temperature",         unit:"K",      strict:true},
    {key:"thermo.critical_pressure_kpa", group:"Thermodynamic",name:"Critical pressure",            unit:"kPa",    strict:true},
    {key:"thermo.critical_density_kg_m3",group:"Thermodynamic",name:"Critical density",             unit:"kg·m⁻³", strict:true},
    {key:"thermo.acentric_factor",       group:"Thermodynamic",name:"Acentric factor",              unit:"—",      strict:true},
    {key:"thermo.heat_capacity_ideal_gas",group:"Thermodynamic",name:"Ideal-gas cp",                unit:"J·mol⁻¹·K⁻¹", strict:false},
    {key:"environmental.gwp_100yr",      group:"Environmental",name:"GWP (100 yr, AR6)",            unit:"kgCO₂e·kg⁻¹", strict:true},
    {key:"environmental.odp",            group:"Environmental",name:"Ozone depletion potential",    unit:"—",      strict:true},
    {key:"environmental.atmospheric_lifetime",group:"Environmental",name:"Atmospheric lifetime",    unit:"yr",     strict:true},
    {key:"safety.ashrae_class",          group:"Safety",       name:"ASHRAE 34 safety class",       unit:"—",      strict:true},
    {key:"safety.toxicity_class",        group:"Safety",       name:"Toxicity class",               unit:"—",      strict:true},
    {key:"safety.flammability_class",    group:"Safety",       name:"Flammability class",           unit:"—",      strict:true},
    {key:"structure.heavy_atom_count",   group:"Structural",   name:"Heavy atom count",             unit:"atoms",  strict:true},
    {key:"structure.h_bond_donor_count", group:"Structural",   name:"H-bond donor count",           unit:"—",      strict:true},
    {key:"structure.rotatable_bond_count",group:"Structural",  name:"Rotatable bond count",         unit:"—",      strict:true},
    {key:"cycle.cop_standard",           group:"Cycle",        name:"COP (standard cycle)",         unit:"—",      strict:true},
    {key:"cycle.volumetric_capacity_kj_m3",group:"Cycle",      name:"Volumetric capacity",          unit:"kJ·m⁻³", strict:true},
  ];

  // ---- Regulatory snapshot -------------------------------------------------
  const regulatory = [
    {mol_id:"MOL_R32",     jurisdiction:"EPA SNAP",    end_use:"Household AC",         acceptability:"Acceptable, Subject to Use Conditions", effective:"2021-05-04"},
    {mol_id:"MOL_R32",     jurisdiction:"EU F-Gas",    end_use:"Split AC ≤ 3 kg",      acceptability:"Permitted",                              effective:"2020-01-01"},
    {mol_id:"MOL_R134a",   jurisdiction:"EPA SNAP",    end_use:"Motor vehicle AC",     acceptability:"Unacceptable (new)",                     effective:"2020-01-01"},
    {mol_id:"MOL_R134a",   jurisdiction:"Kigali Amdt.",end_use:"All",                  acceptability:"Phasedown schedule",                     effective:"2019-01-01"},
    {mol_id:"MOL_R1234yf", jurisdiction:"EPA SNAP",    end_use:"Motor vehicle AC",     acceptability:"Acceptable",                             effective:"2012-03-29"},
    {mol_id:"MOL_R1234ze", jurisdiction:"EU F-Gas",    end_use:"Chillers",             acceptability:"Permitted",                              effective:"2015-01-01"},
    {mol_id:"MOL_R1233zd", jurisdiction:"EPA SNAP",    end_use:"Chillers, centrifugal",acceptability:"Acceptable",                             effective:"2016-07-25"},
    {mol_id:"MOL_R22",     jurisdiction:"Montreal Protocol", end_use:"All",            acceptability:"Phased out (A5 parties, 2030)",          effective:"2020-01-01"},
    {mol_id:"MOL_R11",     jurisdiction:"Montreal Protocol", end_use:"All",            acceptability:"Banned",                                 effective:"1996-01-01"},
    {mol_id:"MOL_R12",     jurisdiction:"Montreal Protocol", end_use:"All",            acceptability:"Banned",                                 effective:"1996-01-01"},
    {mol_id:"MOL_R744",    jurisdiction:"EPA SNAP",    end_use:"Commercial refrig.",   acceptability:"Acceptable",                             effective:"1994-03-18"},
    {mol_id:"MOL_R717",    jurisdiction:"EPA SNAP",    end_use:"Industrial refrig.",   acceptability:"Acceptable",                             effective:"1994-03-18"},
    {mol_id:"MOL_R290",    jurisdiction:"EPA SNAP",    end_use:"Household refrig.",    acceptability:"Acceptable, Subject to Use Conditions",  effective:"2015-04-10"},
  ];

  // ---- Canonical property selections --------------------------------------
  // Keyed (mol_id, canonical_feature_key). Only a subset is instantiated — real DB
  // has 1389 rows; this is the representative slice for the UI.
  function canon(mol_id, key, value, unit, src, rank, q, proxy, div, conflict, strict=true) {
    return {
      mol_id, canonical_feature_key:key, value:String(value), unit,
      selected_source_name:src, source_priority_rank:rank, data_quality_score_100:q,
      is_proxy_or_screening:proxy, source_divergence_flag:div, conflict_flag:conflict,
      proxy_only_flag:proxy && rank>=3, nonproxy_candidate_count: proxy?0:(rank),
      source_count: proxy?1:(rank+1),
      in_strict: strict && !proxy,
      ml_use_status: strict && !proxy ? "ml_ready" : (proxy ? "proxy_only" : "recommended_only"),
    };
  }
  const canonical = [
    // R-32
    canon("MOL_R32","environmental.gwp_100yr",675,"kgCO₂e·kg⁻¹","IPCC AR6 WG1",1,98,false,false,false),
    canon("MOL_R32","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,99,false,false,false),
    canon("MOL_R32","environmental.atmospheric_lifetime",5.4,"yr","IPCC AR6 WG1",1,96,false,false,false),
    canon("MOL_R32","thermo.nbp_k",221.5,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R32","thermo.critical_temperature_k",351.255,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R32","thermo.critical_pressure_kpa",5782,"kPa","NIST WebBook (REFPROP 10.0)",1,99,false,true,false),
    canon("MOL_R32","safety.ashrae_class","A2L","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R32","safety.toxicity_class","A","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R32","cycle.cop_standard",4.02,"—","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    canon("MOL_R32","cycle.volumetric_capacity_kj_m3",5430,"kJ·m⁻³","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    // R-134a — conflict example
    canon("MOL_R134a","environmental.gwp_100yr",1430,"kgCO₂e·kg⁻¹","IPCC AR5 WG1",2,85,false,true,true),
    canon("MOL_R134a","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,99,false,false,false),
    canon("MOL_R134a","environmental.atmospheric_lifetime",14.0,"yr","IPCC AR6 WG1",1,96,false,false,false),
    canon("MOL_R134a","thermo.nbp_k",247.076,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R134a","thermo.critical_temperature_k",374.21,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R134a","thermo.critical_pressure_kpa",4059.3,"kPa","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R134a","safety.ashrae_class","A1","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R134a","cycle.cop_standard",3.84,"—","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    // R-1234yf
    canon("MOL_R1234yf","environmental.gwp_100yr",4,"kgCO₂e·kg⁻¹","IPCC AR6 WG1",1,97,false,false,false),
    canon("MOL_R1234yf","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,99,false,false,false),
    canon("MOL_R1234yf","environmental.atmospheric_lifetime",0.0315,"yr","IPCC AR6 WG1",1,96,false,false,false),
    canon("MOL_R1234yf","thermo.nbp_k",243.7,"K","NIST (parsed)",2,92,false,false,false),
    canon("MOL_R1234yf","thermo.critical_temperature_k",367.85,"K","CoolProp 6.6.0",2,90,false,false,false),
    canon("MOL_R1234yf","thermo.critical_pressure_kpa",3382,"kPa","CoolProp 6.6.0",2,90,false,false,false),
    canon("MOL_R1234yf","safety.ashrae_class","A2L","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R1234yf","cycle.cop_standard",3.71,"—","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    // R-744
    canon("MOL_R744","environmental.gwp_100yr",1,"kgCO₂e·kg⁻¹","IPCC AR6 WG1 (reference)",1,100,false,false,false),
    canon("MOL_R744","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,100,false,false,false),
    canon("MOL_R744","thermo.nbp_k",194.686,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R744","thermo.critical_temperature_k",304.128,"K","NIST WebBook (REFPROP 10.0)",1,100,false,false,false),
    canon("MOL_R744","thermo.critical_pressure_kpa",7377.3,"kPa","NIST WebBook (REFPROP 10.0)",1,100,false,false,false),
    canon("MOL_R744","safety.ashrae_class","A1","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R744","cycle.cop_standard",2.95,"—","R-PhysGen transcritical cycle",3,82,false,false,false),
    // R-717 (ammonia)
    canon("MOL_R717","environmental.gwp_100yr",0,"kgCO₂e·kg⁻¹","IPCC AR6 WG1",1,100,false,false,false),
    canon("MOL_R717","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,100,false,false,false),
    canon("MOL_R717","thermo.nbp_k",239.823,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R717","thermo.critical_temperature_k",405.4,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R717","thermo.critical_pressure_kpa",11333,"kPa","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R717","safety.ashrae_class","B2L","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R717","safety.toxicity_class","B","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R717","cycle.cop_standard",4.76,"—","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    // R-290
    canon("MOL_R290","environmental.gwp_100yr",3,"kgCO₂e·kg⁻¹","IPCC AR6 WG1",1,98,false,false,false),
    canon("MOL_R290","environmental.odp",0.0,"—","Montreal Protocol Assessment 2022",1,100,false,false,false),
    canon("MOL_R290","thermo.nbp_k",231.036,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R290","thermo.critical_temperature_k",369.89,"K","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R290","thermo.critical_pressure_kpa",4247.8,"kPa","NIST WebBook (REFPROP 10.0)",1,99,false,false,false),
    canon("MOL_R290","safety.ashrae_class","A3","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R290","cycle.cop_standard",4.45,"—","R-PhysGen standard cycle (CoolProp 6.6.0)",2,88,false,false,false),
    // Proxy example — R-236fa TFA risk
    canon("MOL_R236fa","environmental.gwp_100yr",9810,"kgCO₂e·kg⁻¹","IPCC AR5 WG1",2,82,false,false,false),
    canon("MOL_R236fa","safety.ashrae_class","A1","—","ASHRAE 34-2022",1,99,false,false,false),
    canon("MOL_R236fa","structure.tfa_risk_proxy","high","—","R-PhysGen proxy heuristics v1",3,55,true,false,false,false),
    // candidate proxy only
    canon("MOL_CAND_00117","structure.tfa_risk_proxy","medium","—","R-PhysGen proxy heuristics v1",3,55,true,false,false,false),
    canon("MOL_CAND_00117","structure.synthetic_accessibility","0.63","—","R-PhysGen proxy heuristics v1",3,50,true,false,false,false),
    canon("MOL_CAND_00284","structure.tfa_risk_proxy","high","—","R-PhysGen proxy heuristics v1",3,55,true,false,false,false),
  ];

  // ---- Observation samples (silver) ---------------------------------------
  const observations = [
    {observation_id:"OBS_0000012", mol_id:"MOL_R32", property_name:"nbp",       value:221.5,  unit:"K",  source:"NIST WebBook (REFPROP 10.0)", source_type:"standard",  method:"REFPROP correlation", temperature:null,   pressure:101.325, phase:"sat-liquid", quality:"A", qc:"pass", canonical_feature_key:"thermo.nbp_k"},
    {observation_id:"OBS_0000013", mol_id:"MOL_R32", property_name:"nbp",       value:221.48, unit:"K",  source:"CoolProp 6.6.0",              source_type:"standard",  method:"EOS evaluation",      temperature:null,   pressure:101.325, phase:"sat-liquid", quality:"A", qc:"pass", canonical_feature_key:"thermo.nbp_k"},
    {observation_id:"OBS_0000014", mol_id:"MOL_R32", property_name:"t_crit",    value:351.255,unit:"K",  source:"NIST WebBook (REFPROP 10.0)", source_type:"standard",  method:"REFPROP correlation", temperature:null,   pressure:null,    phase:"critical",   quality:"A", qc:"pass", canonical_feature_key:"thermo.critical_temperature_k"},
    {observation_id:"OBS_0000015", mol_id:"MOL_R32", property_name:"p_crit",    value:5782,   unit:"kPa",source:"NIST WebBook (REFPROP 10.0)", source_type:"standard",  method:"REFPROP correlation", temperature:351.255,pressure:null,    phase:"critical",   quality:"A", qc:"pass", canonical_feature_key:"thermo.critical_pressure_kpa"},
    {observation_id:"OBS_0000016", mol_id:"MOL_R32", property_name:"p_crit",    value:5780,   unit:"kPa",source:"CoolProp 6.6.0",              source_type:"standard",  method:"EOS evaluation",      temperature:351.25, pressure:null,    phase:"critical",   quality:"A", qc:"pass", canonical_feature_key:"thermo.critical_pressure_kpa"},
    {observation_id:"OBS_0000017", mol_id:"MOL_R32", property_name:"p_crit",    value:5830,   unit:"kPa",source:"DIPPR 801 (2020)",            source_type:"compiled",  method:"compiled literature", temperature:351.3,  pressure:null,    phase:"critical",   quality:"B", qc:"pass", canonical_feature_key:"thermo.critical_pressure_kpa"},
    {observation_id:"OBS_0000031", mol_id:"MOL_R32", property_name:"gwp_100yr", value:675,    unit:"kgCO₂e·kg⁻¹", source:"IPCC AR6 WG1",        source_type:"assessment",method:"radiative efficiency × lifetime", temperature:null, pressure:null, phase:null, quality:"A", qc:"pass", canonical_feature_key:"environmental.gwp_100yr"},
    {observation_id:"OBS_0000032", mol_id:"MOL_R32", property_name:"gwp_100yr", value:677,    unit:"kgCO₂e·kg⁻¹", source:"IPCC AR5 WG1",        source_type:"assessment",method:"radiative efficiency × lifetime", temperature:null, pressure:null, phase:null, quality:"A", qc:"pass", canonical_feature_key:"environmental.gwp_100yr"},
    {observation_id:"OBS_0000087", mol_id:"MOL_R32", property_name:"ashrae_safety", value:"A2L", unit:"—", source:"ASHRAE 34-2022",            source_type:"standard",  method:"safety classification", temperature:null, pressure:null, phase:null, quality:"A", qc:"pass", canonical_feature_key:"safety.ashrae_class"},
    {observation_id:"OBS_0000144", mol_id:"MOL_R134a", property_name:"gwp_100yr", value:1430,  unit:"kgCO₂e·kg⁻¹", source:"IPCC AR5 WG1",        source_type:"assessment",method:"radiative efficiency × lifetime", temperature:null, pressure:null, phase:null, quality:"A", qc:"pass", canonical_feature_key:"environmental.gwp_100yr"},
    {observation_id:"OBS_0000145", mol_id:"MOL_R134a", property_name:"gwp_100yr", value:1530,  unit:"kgCO₂e·kg⁻¹", source:"IPCC AR6 WG1",        source_type:"assessment",method:"radiative efficiency × lifetime", temperature:null, pressure:null, phase:null, quality:"A", qc:"flag", canonical_feature_key:"environmental.gwp_100yr"},
    {observation_id:"OBS_0000146", mol_id:"MOL_R134a", property_name:"gwp_100yr", value:1300,  unit:"kgCO₂e·kg⁻¹", source:"WMO 2022 Ozone Assessment", source_type:"assessment",method:"assessment report", temperature:null, pressure:null, phase:null, quality:"B", qc:"pass", canonical_feature_key:"environmental.gwp_100yr"},
    {observation_id:"OBS_0000390", mol_id:"MOL_R1234yf", property_name:"nbp",    value:243.7,  unit:"K",  source:"NIST (parsed)",               source_type:"experimental", method:"literature compilation", temperature:null, pressure:101.325, phase:"sat-liquid", quality:"B", qc:"pass", canonical_feature_key:"thermo.nbp_k"},
    {observation_id:"OBS_0000391", mol_id:"MOL_R1234yf", property_name:"nbp",    value:242.8,  unit:"K",  source:"Higashi et al. 2010",         source_type:"experimental", method:"static method",           temperature:null, pressure:101.325, phase:"sat-liquid", quality:"A", qc:"pass", canonical_feature_key:"thermo.nbp_k"},
    {observation_id:"OBS_0005712", mol_id:"MOL_R744", property_name:"t_crit",    value:304.128,unit:"K",  source:"NIST WebBook (REFPROP 10.0)", source_type:"standard",  method:"REFPROP correlation", temperature:null, pressure:null, phase:"critical", quality:"A", qc:"pass", canonical_feature_key:"thermo.critical_temperature_k"},
    {observation_id:"OBS_0005713", mol_id:"MOL_R744", property_name:"p_crit",    value:7377.3, unit:"kPa",source:"NIST WebBook (REFPROP 10.0)", source_type:"standard",  method:"REFPROP correlation", temperature:304.128, pressure:null, phase:"critical", quality:"A", qc:"pass", canonical_feature_key:"thermo.critical_pressure_kpa"},
  ];

  // ---- Mixtures -----------------------------------------------------------
  const mixtures = [
    {mixture_id:"MIX_R410A", mixture_name:"R-410A", ashrae:"R-410A", components:[{mol_id:"MOL_R32", pct:50},{mol_id:"MOL_R125", pct:50}], glide_k:0.1,  gwp:2088, ashrae_class:"A1", app:"residential AC"},
    {mixture_id:"MIX_R407C", mixture_name:"R-407C", ashrae:"R-407C", components:[{mol_id:"MOL_R32", pct:23},{mol_id:"MOL_R125", pct:25},{mol_id:"MOL_R134a", pct:52}], glide_k:7.2, gwp:1774, ashrae_class:"A1", app:"AC retrofit"},
    {mixture_id:"MIX_R404A", mixture_name:"R-404A", ashrae:"R-404A", components:[{mol_id:"MOL_R125", pct:44},{mol_id:"MOL_R143a", pct:52},{mol_id:"MOL_R134a", pct:4}], glide_k:0.7, gwp:3922, ashrae_class:"A1", app:"commercial refrig."},
    {mixture_id:"MIX_R454B", mixture_name:"R-454B", ashrae:"R-454B", components:[{mol_id:"MOL_R32", pct:68.9},{mol_id:"MOL_R1234yf", pct:31.1}], glide_k:1.5, gwp:466, ashrae_class:"A2L", app:"residential AC"},
    {mixture_id:"MIX_R513A", mixture_name:"R-513A", ashrae:"R-513A", components:[{mol_id:"MOL_R1234yf", pct:56},{mol_id:"MOL_R134a", pct:44}], glide_k:0,   gwp:631, ashrae_class:"A1", app:"chillers"},
    {mixture_id:"MIX_R511A", mixture_name:"R-511A", ashrae:"R-511A", components:[{mol_id:"MOL_R290", pct:95.5},{mol_id:"MOL_DME", pct:4.5}],      glide_k:0.1, gwp:3, ashrae_class:"A3", app:"(unresolved fraction)"},
  ];

  // ---- Canonical review queue (closed decisions) --------------------------
  const reviewQueue = [
    {decision_id:"REV_00001", mol_id:"MOL_R134a", canonical_feature_key:"environmental.gwp_100yr",   decision:"accept_selected_source", note:"Retain AR5 value (1430) pending cross-reference with AR6 (1530)", applied:"2026-03-04"},
    {decision_id:"REV_00002", mol_id:"MOL_R32",   canonical_feature_key:"thermo.critical_pressure_kpa", decision:"accept_selected_source", note:"NIST/REFPROP vs. DIPPR divergence within 1% — retain REFPROP", applied:"2026-03-04"},
    {decision_id:"REV_00003", mol_id:"MOL_R236fa",canonical_feature_key:"structure.tfa_risk_proxy",   decision:"accept_out_of_strict",   note:"Proxy-only; no non-proxy candidate — excluded from ML strict layer", applied:"2026-03-12"},
    {decision_id:"REV_00004", mol_id:"MOL_R123",  canonical_feature_key:"environmental.ozone_depleting_flag", decision:"accept_out_of_strict", note:"Qualitative 'No' text — kept in canonical only", applied:"2026-03-12"},
  ];

  // ---- Active learning queue (illustrative) -------------------------------
  const activeLearning = [
    {item_id:"AL_00001", mol_id:"MOL_CAND_00117", feature:"thermo.critical_temperature_k", uncertainty:0.38, priority:1, status:"nominated"},
    {item_id:"AL_00002", mol_id:"MOL_CAND_00284", feature:"environmental.gwp_100yr",       uncertainty:0.41, priority:1, status:"nominated"},
    {item_id:"AL_00003", mol_id:"MOL_CAND_00533", feature:"safety.flammability_class",     uncertainty:0.29, priority:2, status:"nominated"},
    {item_id:"AL_00004", mol_id:"MOL_CAND_01102", feature:"thermo.nbp_k",                  uncertainty:0.33, priority:2, status:"queued"},
    {item_id:"AL_00005", mol_id:"MOL_CAND_02019", feature:"environmental.atmospheric_lifetime", uncertainty:0.22, priority:3, status:"queued"},
  ];

  // ---- Top-level coverage counters (from README) --------------------------
  const stats = {
    version: "v1.5.0-draft",
    snapshot_date: "2026-04-24",
    inventory_rows: 5707,
    refrigerants: 77,
    candidates: 5630,
    resolved_molecules: 5598,
    model_dataset_index: 120,
    tier_a: 32, tier_b: 48, tier_c: 40, tier_d: 5587,
    property_observation: 15689,
    property_observation_canonical: 1687,
    property_recommended: 14017,
    property_recommended_canonical: 1389,
    property_recommended_canonical_strict: 1304,
    review_queue_open: 0,
    review_decisions_applied: 120,
    proxy_rules_applied: 13,
    mixtures: 123,
    mixture_components: 378,
    canonical_keys: 30,
    strict_keys: 24,
    proxy_rows_promoted: 396,
    train: 84, validation: 18, test: 18,
    regulatory: 96,
    pending_sources: 47,
    cycle_cases: 2,
    cycle_operating_points: 2,
  };

  return {mols, properties, regulatory, canonical, observations, mixtures, reviewQueue, activeLearning, stats};
})();
