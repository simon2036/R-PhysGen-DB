// Dashboard page — overview, stats, coverage.

const { stats, mols } = window.DB;

const Dashboard = ({setPage, setSelectedMol}) => {
  const s = stats;
  const tierTotal = s.tier_a + s.tier_b + s.tier_c + s.tier_d;

  // sparkline bars for observation growth (mocked)
  const growth = [320, 412, 510, 690, 820, 970, 1180, 1320, 1510, 1687];

  const topMols = mols.filter(m=>m.tier!=="D").slice(0, 6);

  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">Snapshot · {s.snapshot_date}</div>
        <h1 className="page-title">Refrigerant database overview</h1>
        <p className="page-sub">
          Traceable, extensible foundation for single-component refrigerants and candidate fifth-generation
          refrigerants. Build <span className="mono strong">{s.version}</span> — file-lake-first, PubChem + NIST + EPA + CoolProp
          open-source adapters, DuckDB local query layer.
        </p>
      </div>

      {/* Headline stats */}
      <div className="stat-grid" style={{marginBottom: 20}}>
        <div className="stat stat-accent">
          <div className="stat-label">Resolved molecules</div>
          <div className="stat-value">{fmtInt(s.resolved_molecules)}</div>
          <div className="stat-foot">
            <span className="mono">{s.refrigerants} refrigerants</span>
            <span className="subtle">+</span>
            <span className="mono">{fmtInt(s.candidates)} candidates</span>
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Property observations</div>
          <div className="stat-value">{fmtInt(s.property_observation)}</div>
          <div className="stat-foot">
            <span className="mono">{fmtInt(s.property_observation_canonical)} canonical</span>
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Canonical recommended</div>
          <div className="stat-value">{fmtInt(s.property_recommended_canonical)}</div>
          <div className="stat-foot">
            <span className="pill good">{fmtInt(s.property_recommended_canonical_strict)} strict / ML-ready</span>
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Model dataset</div>
          <div className="stat-value">{s.model_dataset_index}</div>
          <div className="stat-foot">
            <span className="mono">train {s.train}</span>
            <span className="mono">· val {s.validation}</span>
            <span className="mono">· test {s.test}</span>
          </div>
        </div>
      </div>

      {/* Panels */}
      <div className="grid-2" style={{alignItems:"start"}}>
        {/* Coverage card */}
        <div className="card">
          <div className="card-head">
            <div className="card-title">Inventory by coverage tier</div>
            <div className="card-sub">seed_catalog.csv + generated</div>
          </div>
          <div className="card-body">
            <div className="stack-bar" title="Tier distribution">
              <div style={{width:  s.tier_a/tierTotal*100 + "%", background: "oklch(60% 0.12 150)"}}/>
              <div style={{width:  s.tier_b/tierTotal*100 + "%", background: "oklch(60% 0.12 205)"}}/>
              <div style={{width:  s.tier_c/tierTotal*100 + "%", background: "oklch(65% 0.13 65)"}}/>
              <div style={{width:  s.tier_d/tierTotal*100 + "%", background: "oklch(75% 0.01 250)"}}/>
            </div>
            <div className="legend">
              <span><i className="sw" style={{background:"oklch(60% 0.12 150)"}}/>Tier A · {s.tier_a}</span>
              <span><i className="sw" style={{background:"oklch(60% 0.12 205)"}}/>Tier B · {s.tier_b}</span>
              <span><i className="sw" style={{background:"oklch(65% 0.13 65)"}}/>Tier C · {s.tier_c}</span>
              <span><i className="sw" style={{background:"oklch(75% 0.01 250)"}}/>Tier D · {fmtInt(s.tier_d)}</span>
            </div>

            <div style={{marginTop:22}}>
              <div style={{display:"flex", justifyContent:"space-between", marginBottom:8}}>
                <span className="strong" style={{fontSize:12}}>Promoted subset coverage (Tier A/B/C)</span>
                <span className="mono subtle" style={{fontSize:11}}>{s.model_dataset_index} rows</span>
              </div>
              <div className="kv-list" style={{gridTemplateColumns:"140px 1fr", rowGap:10}}>
                <dt>GWP 100yr</dt>    <dd><CoverageBar value={76} total={120}/></dd>
                <dt>ODP</dt>          <dd><CoverageBar value={73} total={120}/></dd>
                <dt>ASHRAE safety</dt><dd><CoverageBar value={58} total={120} color="oklch(60% 0.12 150)"/></dd>
                <dt>Toxicity</dt>     <dd><CoverageBar value={56} total={120} color="oklch(60% 0.12 150)"/></dd>
                <dt>T_crit</dt>       <dd><CoverageBar value={108} total={120} color="oklch(55% 0.11 205)"/></dd>
                <dt>COP (std cycle)</dt><dd><CoverageBar value={94} total={120} color="oklch(55% 0.11 205)"/></dd>
              </div>
            </div>
          </div>
        </div>

        {/* Canonical pipeline card */}
        <div className="card">
          <div className="card-head">
            <div className="card-title">Canonical property pipeline</div>
            <div className="card-sub">silver → gold → strict</div>
          </div>
          <div className="card-body">
            <div style={{display:"flex", alignItems:"center", gap:12, flexWrap:"wrap"}}>
              <PipelineNode label="Observations" value={fmtInt(s.property_observation)} sub="silver"/>
              <PipelineArrow/>
              <PipelineNode label="Canonical" value={fmtInt(s.property_recommended_canonical)} sub="gold"/>
              <PipelineArrow/>
              <PipelineNode label="Strict" value={fmtInt(s.property_recommended_canonical_strict)} sub="ML-ready" accent/>
            </div>

            <div style={{marginTop:22, display:"grid", gridTemplateColumns:"1fr 1fr", gap:12}}>
              <MiniStat label="Canonical feature keys"     value={s.canonical_keys}/>
              <MiniStat label="Strict feature keys"        value={s.strict_keys}/>
              <MiniStat label="Proxy rules applied"        value={s.proxy_rules_applied}/>
              <MiniStat label="Proxy rows → strict"        value={s.proxy_rows_promoted}/>
              <MiniStat label="Review decisions"           value={s.review_decisions_applied}/>
              <MiniStat label="Open review queue"          value={s.review_queue_open} color={s.review_queue_open===0 ? "good":"warn"}/>
            </div>
          </div>
        </div>
      </div>

      {/* Observation growth + regulatory */}
      <div className="grid-2" style={{marginTop: 20}}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Observation count (last 10 pipeline runs)</div>
            <div className="card-sub">property_observation.parquet</div>
          </div>
          <div className="card-body">
            <div className="spark" style={{height:86}}>
              {growth.map((v,i)=>(
                <div key={i} className="bar" style={{height: (v/Math.max(...growth)*100)+"%"}} title={v}/>
              ))}
            </div>
            <div style={{display:"flex", justifyContent:"space-between", fontSize:11, color:"var(--ink-subtle)", fontFamily:"var(--font-mono)"}}>
              <span>2025-11</span><span>2026-02</span><span>2026-04</span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">Pending & regulatory tracking</div>
            <div className="card-sub">auxiliary tables</div>
          </div>
          <div className="card-body">
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:12}}>
              <MiniStat label="Regulatory rows"    value={s.regulatory}/>
              <MiniStat label="Pending sources"    value={s.pending_sources} color="warn"/>
              <MiniStat label="Mixtures (governed)"value={s.mixtures}/>
              <MiniStat label="Mixture components" value={s.mixture_components}/>
              <MiniStat label="Cycle cases"        value={s.cycle_cases}/>
              <MiniStat label="Operating points"   value={s.cycle_operating_points}/>
            </div>
            <div style={{marginTop:18, fontSize:12, color:"var(--ink-muted)", lineHeight:1.6}}>
              Source adapters: <span className="pill">PubChem</span>{" "}
              <span className="pill">NIST WebBook</span>{" "}
              <span className="pill">EPA SNAP/ODS</span>{" "}
              <span className="pill">CoolProp 6.6</span>{" "}
              <span className="pill">IPCC AR5/AR6</span>{" "}
              <span className="pill">ASHRAE 34</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tier A shortcut */}
      <div className="section-title">Featured Tier A refrigerants</div>
      <div className="grid-3">
        {topMols.map(m => (
          <div key={m.mol_id} className="card" style={{cursor:"pointer"}}
               onClick={()=>{ setSelectedMol(m.mol_id); setPage("molecule"); }}>
            <div className="card-body" style={{display:"flex", gap:14}}>
              <div style={{width:72, height:72, background:"var(--bg-sunken)", border:"1px solid var(--border)",
                           borderRadius:8, display:"grid", placeItems:"center", position:"relative", overflow:"hidden", flexShrink:0}}>
                <div className="struct-stripes"/>
                <span className="mono" style={{fontSize:11, fontWeight:600, position:"relative", color:"var(--ink-muted)"}}>
                  <Formula str={m.formula}/>
                </span>
              </div>
              <div style={{minWidth:0, flex:1}}>
                <div style={{display:"flex", alignItems:"center", gap:8, marginBottom:4}}>
                  <div className="strong" style={{fontFamily:"var(--font-serif)", fontSize:16}}>{m.r_name}</div>
                  <TierPill tier={m.tier}/>
                </div>
                <div className="mono subtle" style={{fontSize:11, marginBottom:8}}>{m.family} · {m.formula}</div>
                <div style={{display:"flex", gap:12, fontSize:12, color:"var(--ink-muted)"}}>
                  <span>GWP <span className="mono strong">{fmt(m.gwp,0)}</span></span>
                  <span>NBP <span className="mono strong">{fmt(m.nbp,1)}</span><span className="subtle"> K</span></span>
                  <SafetyPill cls={m.ashrae}/>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const PipelineNode = ({label, value, sub, accent}) => (
  <div style={{
    flex:1, minWidth:120, textAlign:"center", padding:"14px 12px",
    border:"1px solid " + (accent ? "var(--accent)" : "var(--border)"),
    borderRadius:"var(--radius)",
    background: accent ? "var(--accent-soft)" : "var(--bg-sunken)"
  }}>
    <div style={{fontSize:11, textTransform:"uppercase", letterSpacing:"0.05em", color:"var(--ink-subtle)"}}>{label}</div>
    <div style={{fontFamily:"var(--font-mono)", fontSize:20, fontWeight:500, color: accent?"var(--accent-ink)":"var(--ink)", margin:"2px 0"}}>{value}</div>
    <div style={{fontSize:10.5, fontFamily:"var(--font-mono)", color:"var(--ink-subtle)"}}>{sub}</div>
  </div>
);
const PipelineArrow = () => (
  <svg width="22" height="14" viewBox="0 0 22 14" style={{flexShrink:0, color:"var(--ink-subtle)"}}>
    <path d="M0 7h19M13 2l6 5-6 5" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const MiniStat = ({label, value, color}) => (
  <div style={{display:"flex", alignItems:"center", justifyContent:"space-between",
               padding:"9px 12px", background:"var(--bg-sunken)", borderRadius:"var(--radius)"}}>
    <span style={{fontSize:12, color:"var(--ink-muted)"}}>{label}</span>
    <span className={"mono strong " + (color==="good"?"":(color==="warn"?"":""))}
          style={{fontSize:13, color: color==="good"?"var(--good)":(color==="warn"?"var(--warn)":"var(--ink)")}}>{value}</span>
  </div>
);

Object.assign(window, { Dashboard });
