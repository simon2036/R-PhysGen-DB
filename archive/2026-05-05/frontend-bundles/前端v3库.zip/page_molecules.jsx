// Molecule browser + detail pages.

const { mols: allMols, canonical, observations, regulatory, properties } = window.DB;

const MoleculeBrowser = ({setPage, setSelectedMol, query, compare, toggleCompare, units, setUnits}) => {
  const [tier, setTier] = useState("all");
  const [family, setFamily] = useState("all");
  const [inclusion, setInclusion] = useState("all");
  const [sort, setSort] = useState("r_name");
  const [gwpMax, setGwpMax] = useState("");
  const [odpMax, setOdpMax] = useState("");
  const [nbpMin, setNbpMin] = useState("");
  const [nbpMax, setNbpMax] = useState("");
  const [safety, setSafety] = useState("all");
  const U = UNITS[units];

  const families = useMemo(()=>Array.from(new Set(allMols.map(m=>m.family))).sort(), []);

  const rows = useMemo(()=>{
    let rs = allMols;
    if (tier !== "all") rs = rs.filter(m=>m.tier===tier);
    if (family !== "all") rs = rs.filter(m=>m.family===family);
    if (inclusion !== "all") rs = rs.filter(m=>m.model_inclusion===inclusion);
    if (safety !== "all") rs = rs.filter(m=>m.ashrae===safety);
    if (gwpMax !== "" && !isNaN(+gwpMax)) rs = rs.filter(m=>m.gwp!=null && m.gwp <= +gwpMax);
    if (odpMax !== "" && !isNaN(+odpMax)) rs = rs.filter(m=>m.odp!=null && m.odp <= +odpMax);
    if (nbpMin !== "" && !isNaN(+nbpMin)) rs = rs.filter(m=>m.nbp!=null && m.nbp >= +nbpMin);
    if (nbpMax !== "" && !isNaN(+nbpMax)) rs = rs.filter(m=>m.nbp!=null && m.nbp <= +nbpMax);
    if (query && query.trim()) {
      const q = query.trim().toLowerCase();
      rs = rs.filter(m=>
        m.mol_id.toLowerCase().includes(q) ||
        (m.r_name||"").toLowerCase().includes(q) ||
        (m.formula||"").toLowerCase().includes(q) ||
        (m.cas||"").toLowerCase().includes(q) ||
        (m.inchikey||"").toLowerCase().includes(q) ||
        (m.family||"").toLowerCase().includes(q)
      );
    }
    const dir = sort.startsWith("-") ? -1 : 1;
    const key = sort.replace(/^-/, "");
    rs = [...rs].sort((a,b)=>{
      const av = a[key], bv = b[key];
      if (av==null && bv==null) return 0;
      if (av==null) return 1;
      if (bv==null) return -1;
      return av > bv ? dir : av < bv ? -dir : 0;
    });
    return rs;
  }, [tier, family, inclusion, sort, query, gwpMax, odpMax, nbpMin, nbpMax, safety]);

  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">silver · molecule_core.parquet</div>
        <h1 className="page-title">Molecules</h1>
        <p className="page-sub">
          Resolved single-component refrigerant molecules and candidate species.
          The full inventory includes {fmtInt(5598)} rows; the promoted model-ready subset
          holds {fmtInt(120)} tier A/B/C molecules.
        </p>
      </div>

      <div className="card">
        <div className="filterbar">
          <span className="filter-label">Tier</span>
          <div className="chip-group">
            {["all","A","B","C","D"].map(t=>(
              <button key={t} className={"chip "+(tier===t?"active":"")} onClick={()=>setTier(t)}>
                {t==="all"?"All":t}
              </button>
            ))}
          </div>
          <span className="filter-label" style={{marginLeft:8}}>Model</span>
          <div className="chip-group">
            {["all","yes","no"].map(v=>(
              <button key={v} className={"chip "+(inclusion===v?"active":"")} onClick={()=>setInclusion(v)}>
                {v==="all"?"All":(v==="yes"?"Included":"Excluded")}
              </button>
            ))}
          </div>
          <span className="filter-label" style={{marginLeft:8}}>Family</span>
          <select className="select" value={family} onChange={e=>setFamily(e.target.value)}>
            <option value="all">All families</option>
            {families.map(f=><option key={f} value={f}>{f}</option>)}
          </select>
          <div style={{marginLeft:"auto", display:"flex", alignItems:"center", gap:8}}>
            <UnitToggle units={units} setUnits={setUnits}/>
            <span className="mono subtle" style={{fontSize:11.5}} title="Representative demo slice; the real dataset has 5,598 molecules.">
              {fmtInt(rows.length)} of {fmtInt(allMols.length)}
            </span>
            <button className="btn sm ghost" onClick={()=>{
              downloadText("r-physgen-molecules.csv",
                toCsv(rows, ["mol_id","r_name","formula","cas","inchikey","family","tier","mw","nbp","tcrit","pcrit","gwp","odp","ashrae","tox"]),
                "text/csv");
            }}><Icon name="download" size={12}/> CSV</button>
            <button className="btn sm ghost" onClick={()=>{
              downloadText("r-physgen-molecules.json", JSON.stringify(rows, null, 2), "application/json");
            }}><Icon name="download" size={12}/> JSON</button>
          </div>
        </div>

        {/* Range filter row */}
        <div className="filterbar" style={{borderTop:"1px dashed var(--border)", borderRadius:0, gap:14}}>
          <span className="filter-label">Ranges</span>
          <div style={{display:"grid", gridTemplateColumns:"repeat(3, minmax(180px, 1fr))", gap:12, flex:1}}>
            <div className="range-row"><span className="lbl">GWP ≤</span>
              <input type="number" placeholder="e.g. 150" value={gwpMax} onChange={e=>setGwpMax(e.target.value)}/>
              <span/>
            </div>
            <div className="range-row"><span className="lbl">ODP ≤</span>
              <input type="number" step="0.001" placeholder="e.g. 0" value={odpMax} onChange={e=>setOdpMax(e.target.value)}/>
              <span/>
            </div>
            <div className="range-row"><span className="lbl">NBP / K</span>
              <input type="number" placeholder="min" value={nbpMin} onChange={e=>setNbpMin(e.target.value)}/>
              <input type="number" placeholder="max" value={nbpMax} onChange={e=>setNbpMax(e.target.value)}/>
            </div>
          </div>
          <span className="filter-label">Safety</span>
          <select className="select" value={safety} onChange={e=>setSafety(e.target.value)}>
            <option value="all">Any</option>
            {["A1","A2L","A2","A3","B1","B2L","B2","B3"].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <button className="btn sm ghost" onClick={()=>{
            setTier("all"); setFamily("all"); setInclusion("all"); setSafety("all");
            setGwpMax(""); setOdpMax(""); setNbpMin(""); setNbpMax("");
          }}>Reset</button>
        </div>

        <div style={{maxHeight:"calc(100vh - 280px)", overflowY:"auto"}}>
          <table className="data-table">
            <thead>
              <tr>
                <th style={{width:30}}></th>
                <SortHead label="ID"       k="mol_id"   sort={sort} setSort={setSort}/>
                <SortHead label="Name"     k="r_name"   sort={sort} setSort={setSort}/>
                <th>Formula</th>
                <SortHead label="MW"       k="mw"       sort={sort} setSort={setSort} align="right"/>
                <th>Family</th>
                <th>Tier</th>
                <SortHead label={`NBP / ${U.tempLbl}`}  k="nbp"      sort={sort} setSort={setSort} align="right"/>
                <SortHead label={`Tc / ${U.tempLbl}`}   k="tcrit"    sort={sort} setSort={setSort} align="right"/>
                <SortHead label={`Pc / ${U.pressLbl}`}  k="pcrit"    sort={sort} setSort={setSort} align="right"/>
                <SortHead label="GWP"      k="gwp"      sort={sort} setSort={setSort} align="right"/>
                <SortHead label="ODP"      k="odp"      sort={sort} setSort={setSort} align="right"/>
                <th>ASHRAE</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map(m=>{
                const inCmp = compare && compare.includes(m.mol_id);
                return (
                <tr key={m.mol_id} className={inCmp?"selected":""} onClick={()=>{setSelectedMol(m.mol_id); setPage("molecule");}}>
                  <td onClick={e=>e.stopPropagation()} style={{width:30}}>
                    <input type="checkbox" checked={!!inCmp} onChange={()=>toggleCompare(m.mol_id)} aria-label={"Add "+m.r_name+" to compare"}/>
                  </td>
                  <td className="col-id">{m.mol_id}</td>
                  <td className="col-name" style={{fontFamily:"var(--font-serif)"}}>{m.r_name}</td>
                  <td className="mono" style={{fontSize:12.5}}><Formula str={m.formula}/></td>
                  <td className="col-num">{fmt(m.mw,2)}</td>
                  <td><span className="mono subtle" style={{fontSize:11.5}}>{m.family}</span></td>
                  <td><TierPill tier={m.tier}/></td>
                  <td className="col-num">{m.nbp==null?"—":fmt(U.T(m.nbp),U.tDigits)}</td>
                  <td className="col-num">{m.tcrit==null?"—":fmt(U.T(m.tcrit),U.tDigits)}</td>
                  <td className="col-num">{m.pcrit==null?"—":fmt(U.P(m.pcrit),U.pDigits)}</td>
                  <td className="col-num">{fmt(m.gwp,0)}</td>
                  <td className="col-num">{m.odp==null?"—":fmt(m.odp,3)}</td>
                  <td><SafetyPill cls={m.ashrae}/></td>
                  <td><Icon name="chevron" size={14}/></td>
                </tr>
                );
              })}
              {rows.length===0 && (
                <tr><td colSpan="14" className="empty">No molecules match these filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const SortHead = ({label, k, sort, setSort, align}) => {
  const active = sort===k || sort==="-"+k;
  const desc = sort==="-"+k;
  return (
    <th style={{cursor:"pointer", textAlign:align||"left"}}
        onClick={()=>setSort(active && !desc ? "-"+k : k)}
        aria-sort={active ? (desc ? "descending" : "ascending") : "none"}>
      <span style={{display:"inline-flex", alignItems:"center", gap:4, opacity: active?1:0.8}}>
        {label}
        {active && <span style={{fontSize:9, color:"var(--accent)"}}>{desc?"▼":"▲"}</span>}
      </span>
    </th>
  );
};

// ---------------------------------------------------------------- Detail page
const MoleculeDetail = ({molId, setPage, units="SI", setUnits, compare=[], toggleCompare}) => {
  const m = allMols.find(x=>x.mol_id===molId);
  const [tab, setTab] = useState("properties");
  const inCmp = compare && compare.includes(molId);
  if (!m) return <div className="page"><div className="empty">Molecule not found.</div></div>;

  const molCanon = canonical.filter(c=>c.mol_id===molId);
  const molObs = observations.filter(o=>o.mol_id===molId);
  const molReg = regulatory.filter(r=>r.mol_id===molId);

  // group canonical by property group
  const byGroup = {};
  molCanon.forEach(c=>{
    const prop = properties.find(p=>p.key===c.canonical_feature_key);
    const g = prop?.group || "Other";
    (byGroup[g] = byGroup[g] || []).push({...c, prop});
  });

  return (
    <div className="page">
      <div className="crumbs">
        <a onClick={()=>setPage("molecules")}>Molecules</a>
        <span className="sep">›</span>
        <span>{m.mol_id}</span>
      </div>

      {/* Hero */}
      <div className="hero-panel">
        <div className="struct-box">
          <div className="struct-stripes"/>
          <div className="placeholder-label">2D STRUCTURE · placeholder</div>
          <span className="struct-formula"><Formula str={m.formula}/></span>
        </div>
        <div>
          <div style={{display:"flex", alignItems:"baseline", gap:12, marginBottom:4, flexWrap:"wrap"}}>
            <h1 style={{fontFamily:"var(--font-serif)", fontSize:32, fontWeight:600, margin:0, letterSpacing:"-0.02em", whiteSpace:"nowrap"}}>
              {m.r_name}
            </h1>
            <TierPill tier={m.tier}/>
            <span className={"pill " + (m.model_inclusion==="yes"?"accent":"ghost")}>
              <span className="pill-dot"/>model {m.model_inclusion}
            </span>
          </div>
          <div className="mono subtle" style={{fontSize:12, marginBottom:18}}>{m.mol_id} · {m.family}</div>
          <div style={{display:"flex", gap:10, alignItems:"center", marginBottom:16, flexWrap:"wrap"}}>
            {setUnits && <UnitToggle units={units} setUnits={setUnits}/>}
            {toggleCompare && (
              <button className={"btn sm " + (inCmp?"primary":"")} onClick={()=>toggleCompare(m.mol_id)}>
                {inCmp ? "✓ In compare" : "+ Add to compare"}
              </button>
            )}
          </div>
          <dl className="kv-list" style={{gridTemplateColumns:"140px 1fr"}}>
            <dt>Formula</dt><dd><Formula str={m.formula}/></dd>
            <dt>Molecular weight</dt><dd>{fmt(m.mw,3)} g·mol⁻¹</dd>
            <dt>SMILES</dt><dd style={{wordBreak:"break-all"}}>{m.smiles}</dd>
            <dt>InChIKey</dt><dd>{m.inchikey}</dd>
            <dt>CAS RN</dt><dd>{m.cas}</dd>
            <dt>Applications</dt>
            <dd style={{fontFamily:"var(--font-sans)"}}>
              {(m.applications||[]).map((a,i)=>(
                <span key={i} className="pill" style={{marginRight:4, marginBottom:4}}>{a}</span>
              ))}
            </dd>
          </dl>
        </div>
        <div style={{display:"flex", flexDirection:"column", gap:8}}>
          <button className="btn sm" onClick={()=>copyText(m.inchikey)} aria-label="Copy InChIKey to clipboard">
            <Icon name="copy" size={12}/> Copy InChIKey
          </button>
          <button className="btn sm" onClick={()=>window.open(`https://pubchem.ncbi.nlm.nih.gov/#query=${encodeURIComponent(m.inchikey||m.r_name)}`,"_blank","noopener")}>
            <Icon name="external" size={12}/> PubChem
          </button>
          <button className="btn sm" onClick={()=>window.open(`https://webbook.nist.gov/cgi/cbook.cgi?ID=${encodeURIComponent(m.cas||m.r_name)}`,"_blank","noopener")}>
            <Icon name="external" size={12}/> NIST WebBook
          </button>
          <button className="btn sm primary" onClick={()=>downloadText(`${m.mol_id}.json`, JSON.stringify({molecule:m, canonical:molCanon, observations:molObs, regulatory:molReg}, null, 2), "application/json")}>
            <Icon name="download" size={12}/> Download JSON
          </button>
          <button className="btn sm" onClick={()=>{
            const rows = molCanon.map(c=>({
              mol_id:c.mol_id, key:c.canonical_feature_key, value:c.value, unit:c.unit,
              source:c.selected_source_name, rank:c.source_priority_rank, quality:c.data_quality_score_100,
              strict:c.in_strict, proxy:c.is_proxy_or_screening, conflict:c.conflict_flag,
            }));
            downloadText(`${m.mol_id}-canonical.csv`,
              toCsv(rows, ["mol_id","key","value","unit","source","rank","quality","strict","proxy","conflict"]),
              "text/csv");
          }}><Icon name="download" size={12}/> CSV (canonical)</button>
        </div>
      </div>

      {/* Citation panel */}
      <div className="card" style={{marginBottom:20}}>
        <div className="card-head">
          <div className="card-title">Cite this record</div>
          <div className="card-sub">shareable identifier · v1.5.0-draft</div>
        </div>
        <div className="card-body" style={{display:"grid", gridTemplateColumns:"1fr auto", gap:14, alignItems:"flex-start"}}>
          <div>
            <div style={{fontFamily:"var(--font-serif)", fontSize:14, lineHeight:1.65, color:"var(--ink)"}}>
              R-PhysGen-DB contributors. <em>{m.r_name} canonical property record</em> ({m.formula}).
              R-PhysGen-DB v1.5.0-draft, snapshot 2026-04-24. Record <span className="mono">{m.mol_id}</span>.
            </div>
            <div style={{marginTop:12, display:"flex", gap:10, flexWrap:"wrap", fontSize:12}}>
              <span className="pill ghost mono" style={{background:"var(--bg-sunken)"}}>{window.location.origin + window.location.pathname}#/molecule/{m.mol_id}</span>
            </div>
          </div>
          <div style={{display:"flex", flexDirection:"column", gap:6}}>
            <button className="btn sm" onClick={()=>copyText(`${window.location.origin}${window.location.pathname}#/molecule/${m.mol_id}`)}>
              <Icon name="copy" size={12}/> Copy link
            </button>
            <button className="btn sm" onClick={()=>downloadText(`${m.mol_id}.bib`, toBibtex(m), "application/x-bibtex")}>
              <Icon name="download" size={12}/> BibTeX
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        {[
          {id:"properties", label:"Canonical properties", badge: molCanon.length},
          {id:"observations", label:"Observations", badge: molObs.length},
          {id:"regulatory", label:"Regulatory", badge: molReg.length},
          {id:"provenance", label:"Provenance & QC"},
        ].map(t=>(
          <button key={t.id} className={"tab "+(tab===t.id?"active":"")} onClick={()=>setTab(t.id)}>
            {t.label}{t.badge!=null && <span className="subtle mono" style={{marginLeft:6, fontSize:11}}>{t.badge}</span>}
          </button>
        ))}
      </div>

      {tab==="properties" && <PropertiesTab byGroup={byGroup} units={units}/>}
      {tab==="observations" && <ObservationsTab obs={molObs}/>}
      {tab==="regulatory" && <RegulatoryTab reg={molReg}/>}
      {tab==="provenance" && <ProvenanceTab canon={molCanon} obs={molObs}/>}
    </div>
  );
};

const PropertiesTab = ({byGroup, units}) => {
  const order = ["Thermodynamic","Environmental","Safety","Structural","Cycle","Other"];
  return (
    <div>
      {order.filter(g=>byGroup[g]).map(g=>(
        <div key={g}>
          <div className="section-title">{g}</div>
          <div className="grid-3">
            {byGroup[g].map(c=>(
              <PropertyCard key={c.canonical_feature_key} c={c} units={units}/>
            ))}
          </div>
        </div>
      ))}
      {Object.keys(byGroup).length===0 && (
        <div className="empty"><div className="icon">◌</div>No canonical rows — inventory-only.</div>
      )}
    </div>
  );
};

const PropertyCard = ({c, units="SI"}) => {
  const p = c.prop;
  const cls = c.conflict_flag ? "conflict" : c.is_proxy_or_screening ? "proxy" : c.in_strict ? "strict" : "";
  const [open, setOpen] = useState(false);
  const { v: convV, unit: convUnit } = convertByUnit(c.value, c.unit, units);
  return (
    <div className={"property-card " + cls}>
      <div className="prop-name">
        <span>{p?.name || c.canonical_feature_key}</span>
        {c.in_strict && <span className="pill good" style={{fontSize:10}}><span className="pill-dot"/>strict</span>}
        {c.is_proxy_or_screening && <span className="pill" style={{fontSize:10}}>proxy</span>}
        {c.conflict_flag && <span className="pill warn" style={{fontSize:10}}>conflict</span>}
      </div>
      <div>
        <span className="prop-value">{fmt(isNaN(Number(convV)) ? convV : Number(convV), 4)}</span>
        <span className="prop-unit">{convUnit==="—"?"":convUnit}</span>
      </div>
      <div className="prop-src">
        <span style={{flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}} title={c.selected_source_name}>
          {c.selected_source_name}
        </span>
        <span>rank {c.source_priority_rank}</span>
      </div>
      <div className="quality-bar" title={"quality "+c.data_quality_score_100}>
        <div style={{width: (c.data_quality_score_100||0)+"%"}}/>
      </div>
      <button className="card-link" onClick={()=>setOpen(o=>!o)} aria-expanded={open} style={{marginTop:6}}>
        {open ? "▾ hide provenance" : "▸ provenance"}
      </button>
      {open && (
        <dl className="prov-expand">
          <dt>key</dt><dd>{c.canonical_feature_key}</dd>
          <dt>source</dt><dd>{c.selected_source_name}</dd>
          <dt>rank</dt><dd>{c.source_priority_rank}</dd>
          <dt>quality</dt><dd>{c.data_quality_score_100}/100</dd>
          <dt>strict</dt><dd>{c.in_strict ? "yes" : "no"}</dd>
          <dt>proxy</dt><dd>{c.is_proxy_or_screening ? "yes" : "no"}</dd>
          {c.conflict_flag && (<><dt>conflict</dt><dd>flagged</dd></>)}
          {c.source_divergence_flag && (<><dt>divergence</dt><dd>flagged</dd></>)}
        </dl>
      )}
    </div>
  );
};

const ObservationsTab = ({obs}) => (
  <div className="card" style={{padding:0}}>
    <div className="scroll-x">
      <table className="data-table">
        <thead>
          <tr>
            <th>Observation</th>
            <th>Property</th>
            <th>Value</th>
            <th>Unit</th>
            <th>T / K</th>
            <th>P / kPa</th>
            <th>Phase</th>
            <th>Source</th>
            <th>Type</th>
            <th>Quality</th>
            <th>QC</th>
          </tr>
        </thead>
        <tbody>
          {obs.map(o=>(
            <tr key={o.observation_id}>
              <td className="col-id">{o.observation_id}</td>
              <td><span className="mono" style={{fontSize:12}}>{o.canonical_feature_key||o.property_name}</span></td>
              <td className="col-num strong">{typeof o.value==="number"?fmt(o.value,3):o.value}</td>
              <td className="mono subtle" style={{fontSize:12}}>{o.unit}</td>
              <td className="col-num">{fmt(o.temperature,2)}</td>
              <td className="col-num">{fmt(o.pressure,2)}</td>
              <td><span className="pill" style={{fontSize:10}}>{o.phase||"—"}</span></td>
              <td style={{fontSize:12}}>{o.source}</td>
              <td><span className="pill" style={{fontSize:10}}>{o.source_type}</span></td>
              <td><span className="pill" style={{fontSize:10}}>{o.quality}</span></td>
              <td>
                {o.qc==="pass" ? <span className="pill good" style={{fontSize:10}}>pass</span>
                               : <span className="pill warn" style={{fontSize:10}}>flag</span>}
              </td>
            </tr>
          ))}
          {obs.length===0 && <tr><td colSpan="11" className="empty">No observations.</td></tr>}
        </tbody>
      </table>
    </div>
  </div>
);

const RegulatoryTab = ({reg}) => (
  <div className="card" style={{padding:0}}>
    <table className="data-table">
      <thead>
        <tr><th>Jurisdiction</th><th>End use</th><th>Acceptability</th><th>Effective</th></tr>
      </thead>
      <tbody>
        {reg.map((r,i)=>(
          <tr key={i}>
            <td className="strong">{r.jurisdiction}</td>
            <td>{r.end_use}</td>
            <td>
              <span className={"pill " + (
                /Accept/i.test(r.acceptability) ? "good" :
                /Banned|Unacceptable/i.test(r.acceptability) ? "danger" :
                /Phase/i.test(r.acceptability) ? "warn" : ""
              )}>
                {r.acceptability}
              </span>
            </td>
            <td className="mono subtle" style={{fontSize:12}}>{r.effective}</td>
          </tr>
        ))}
        {reg.length===0 && <tr><td colSpan="4" className="empty">No regulatory records.</td></tr>}
      </tbody>
    </table>
  </div>
);

const ProvenanceTab = ({canon, obs}) => {
  // source breakdown
  const bySource = {};
  obs.forEach(o=>{ bySource[o.source] = (bySource[o.source]||0) + 1; });
  const entries = Object.entries(bySource).sort((a,b)=>b[1]-a[1]);
  const total = obs.length || 1;
  return (
    <div className="grid-2">
      <div className="card">
        <div className="card-head"><div className="card-title">Source composition</div>
          <div className="card-sub">{total} obs</div></div>
        <div className="card-body">
          {entries.map(([src,n])=>(
            <div key={src} style={{marginBottom:10}}>
              <div style={{display:"flex", justifyContent:"space-between", marginBottom:4, fontSize:12.5}}>
                <span>{src}</span>
                <span className="mono subtle">{n}</span>
              </div>
              <div style={{height:5, background:"var(--bg-sunken)", borderRadius:3, overflow:"hidden"}}>
                <div style={{height:"100%", width: (n/total*100)+"%", background:"var(--accent)"}}/>
              </div>
            </div>
          ))}
          {entries.length===0 && <div className="empty">No provenance data.</div>}
        </div>
      </div>
      <div className="card">
        <div className="card-head"><div className="card-title">Canonical selection flags</div>
          <div className="card-sub">{canon.length} features</div></div>
        <div className="card-body">
          <div className="kv-list" style={{gridTemplateColumns:"auto 1fr"}}>
            <dt>Strict-layer eligible</dt>
              <dd>{canon.filter(c=>c.in_strict).length} of {canon.length}</dd>
            <dt>Proxy-only</dt>
              <dd>{canon.filter(c=>c.is_proxy_or_screening).length}</dd>
            <dt>Conflict flagged</dt>
              <dd>{canon.filter(c=>c.conflict_flag).length}</dd>
            <dt>Source divergence</dt>
              <dd>{canon.filter(c=>c.source_divergence_flag).length}</dd>
          </div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { MoleculeBrowser, MoleculeDetail });
