// Compare page + bottom drawer.

const { mols: _cmpMols, canonical: _cmpCanon } = window.DB;

const CompareDrawer = ({ids, toggleCompare, clearCompare, goCompare}) => (
  <div className="compare-drawer" role="region" aria-label="Comparison tray">
    <span className="mono subtle" style={{fontSize:11.5, textTransform:"uppercase", letterSpacing:"0.06em"}}>
      Compare {ids.length}/6
    </span>
    <div style={{display:"flex", gap:6, flexWrap:"wrap", flex:1, minWidth:0}}>
      {ids.map(id => {
        const m = _cmpMols.find(x=>x.mol_id===id);
        return (
          <span key={id} className="compare-chip">
            <span style={{fontFamily:"var(--font-serif)", fontWeight:600, fontSize:12.5}}>{m ? m.r_name : id}</span>
            <button type="button" onClick={()=>toggleCompare(id)} aria-label={"Remove " + (m ? m.r_name : id)}>×</button>
          </span>
        );
      })}
    </div>
    <button className="btn sm ghost" onClick={clearCompare}>Clear</button>
    <button className="btn sm primary" onClick={goCompare} disabled={ids.length<2}>
      Compare side-by-side
    </button>
  </div>
);

const ComparePage = ({ids, setPage, setSelectedMol, toggleCompare, units, setUnits}) => {
  const picked = ids.map(id => _cmpMols.find(m=>m.mol_id===id)).filter(Boolean);

  if (picked.length < 1) {
    return (
      <div className="page">
        <div className="page-head">
          <div className="page-eyebrow">compare</div>
          <h1 className="page-title">Compare candidates</h1>
          <p className="page-sub">
            Select molecules from the browser (the Compare checkbox) to place them side-by-side.
            Up to six at once. The compare set lives in your browser.
          </p>
        </div>
        <div className="card"><div className="card-body" style={{padding:32}}>
          <div className="empty">
            <div className="icon">⇌</div>
            Nothing selected yet.
            <div style={{marginTop:14}}>
              <button className="btn primary" onClick={()=>setPage("molecules")}>Open molecule browser</button>
            </div>
          </div>
        </div></div>
      </div>
    );
  }

  const U = UNITS[units];
  const getCanon = (mol_id, key) => _cmpCanon.find(c => c.mol_id===mol_id && c.canonical_feature_key===key);

  const rows = [
    {group:"Identity", items:[
      {label:"Refrigerant", val: m => <span className="name">{m.r_name}</span>, raw: m => m.r_name},
      {label:"Formula", val: m => <Formula str={m.formula}/>, raw: m => m.formula},
      {label:"Family", val: m => m.family, raw: m => m.family},
      {label:"CAS", val: m => m.cas, raw: m => m.cas},
      {label:"Tier", val: m => <TierPill tier={m.tier}/>, raw: m => m.tier},
    ]},
    {group:"Environmental", items:[
      {label:"GWP (100yr)", raw: m => m.gwp, val: m => fmt(m.gwp,0), better:"min"},
      {label:"ODP", raw: m => m.odp, val: m => m.odp==null?"—":fmt(m.odp,4), better:"min"},
      {label:"Atmospheric lifetime", raw: m => { const c = getCanon(m.mol_id,"environmental.atmospheric_lifetime"); return c?Number(c.value):null; },
       val: m => { const c = getCanon(m.mol_id,"environmental.atmospheric_lifetime"); return c?fmt(Number(c.value),2)+" yr":"—"; }, better:"min"},
    ]},
    {group:"Thermodynamic", items:[
      {label:`NBP / ${U.tempLbl}`, raw: m => m.nbp, val: m => m.nbp==null?"—":fmt(U.T(m.nbp),U.tDigits)},
      {label:`T_crit / ${U.tempLbl}`, raw: m => m.tcrit, val: m => m.tcrit==null?"—":fmt(U.T(m.tcrit),U.tDigits)},
      {label:`P_crit / ${U.pressLbl}`, raw: m => m.pcrit, val: m => m.pcrit==null?"—":fmt(U.P(m.pcrit),U.pDigits)},
      {label:"MW / g·mol⁻¹", raw: m => m.mw, val: m => m.mw==null?"—":fmt(m.mw,2)},
    ]},
    {group:"Cycle performance", items:[
      {label:"COP (std cycle)", raw: m => { const c = getCanon(m.mol_id,"cycle.cop_standard"); return c?Number(c.value):null; },
       val: m => { const c = getCanon(m.mol_id,"cycle.cop_standard"); return c?fmt(Number(c.value),2):"—"; }, better:"max"},
      {label:"Vol. capacity / kJ·m⁻³", raw: m => { const c = getCanon(m.mol_id,"cycle.volumetric_capacity_kj_m3"); return c?Number(c.value):null; },
       val: m => { const c = getCanon(m.mol_id,"cycle.volumetric_capacity_kj_m3"); return c?fmt(Number(c.value),0):"—"; }, better:"max"},
    ]},
    {group:"Safety", items:[
      {label:"ASHRAE class", raw: m => m.ashrae, val: m => <SafetyPill cls={m.ashrae}/>},
      {label:"Toxicity", raw: m => m.tox, val: m => m.tox||"—"},
    ]},
  ];

  // mark "best" per row for numeric comparisons
  const bestIdx = (raws, dir) => {
    const nums = raws.map(r => typeof r === "number" ? r : null);
    const defined = nums.filter(n => n != null);
    if (defined.length < 2) return -1;
    const target = dir === "min" ? Math.min(...defined) : Math.max(...defined);
    return nums.findIndex(n => n === target);
  };

  return (
    <div className="page">
      <div className="page-head">
        <div style={{display:"flex", alignItems:"flex-start", gap:16, flexWrap:"wrap"}}>
          <div style={{flex:1, minWidth:0}}>
            <div className="page-eyebrow">compare · {picked.length} of 6</div>
            <h1 className="page-title">Side-by-side comparison</h1>
            <p className="page-sub">
              Canonical values across identity, environmental, thermophysical and cycle dimensions.
              Best value in each row is highlighted (lower is better for GWP / ODP; higher for COP).
            </p>
          </div>
          <div style={{display:"flex", gap:8, alignItems:"center"}}>
            <UnitToggle units={units} setUnits={setUnits}/>
            <button className="btn sm" onClick={()=>{
              const flat = picked.map(m => ({mol_id:m.mol_id, r_name:m.r_name, family:m.family, formula:m.formula,
                mw:m.mw, nbp:m.nbp, tcrit:m.tcrit, pcrit:m.pcrit, gwp:m.gwp, odp:m.odp, ashrae:m.ashrae}));
              downloadText("r-physgen-compare.csv", toCsv(flat, Object.keys(flat[0])), "text/csv");
            }}><Icon name="download" size={12}/> CSV</button>
          </div>
        </div>
      </div>

      <div className="card" style={{padding:0, overflowX:"auto"}}>
        <table className="compare-table">
          <thead>
            <tr>
              <th></th>
              {picked.map(m => (
                <th key={m.mol_id}>
                  <div style={{display:"flex", alignItems:"center", gap:6}}>
                    <a onClick={()=>{setSelectedMol(m.mol_id); setPage("molecule");}} style={{cursor:"pointer", fontFamily:"var(--font-serif)", fontSize:14, fontWeight:600, color:"var(--ink)"}}>{m.r_name}</a>
                    <button className="btn sm ghost" onClick={()=>toggleCompare(m.mol_id)} aria-label="Remove" style={{padding:"2px 6px"}}>×</button>
                  </div>
                  <div className="mono subtle" style={{fontSize:11, textTransform:"none", letterSpacing:0, marginTop:2}}>{m.mol_id}</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(section => (
              <React.Fragment key={section.group}>
                <tr>
                  <th colSpan={picked.length + 1} style={{background:"var(--bg-sunken)", color:"var(--ink-muted)", fontSize:11, textTransform:"uppercase", letterSpacing:"0.06em", padding:"8px 14px"}}>
                    {section.group}
                  </th>
                </tr>
                {section.items.map(item => {
                  const raws = picked.map(m => item.raw ? item.raw(m) : null);
                  const bi = item.better ? bestIdx(raws, item.better) : -1;
                  return (
                    <tr key={item.label}>
                      <th>{item.label}</th>
                      {picked.map((m,i) => (
                        <td key={m.mol_id} className={bi===i?"best":""}>
                          {item.val(m)}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{marginTop:16, display:"flex", gap:8}}>
        <button className="btn ghost" onClick={()=>setPage("molecules")}>← Back to browser</button>
      </div>
    </div>
  );
};

const UnitToggle = ({units, setUnits}) => (
  <div className="chip-group" role="radiogroup" aria-label="Unit system">
    <button className={"chip "+(units==="SI"?"active":"")} onClick={()=>setUnits("SI")} aria-pressed={units==="SI"}>K · kPa</button>
    <button className={"chip "+(units==="Eng"?"active":"")} onClick={()=>setUnits("Eng")} aria-pressed={units==="Eng"}>°C · MPa</button>
  </div>
);

Object.assign(window, { CompareDrawer, ComparePage, UnitToggle });
