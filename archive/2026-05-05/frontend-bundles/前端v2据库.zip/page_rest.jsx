// Remaining pages: mixtures, properties registry, canonical, review, regulatory, cycle, AL, sources.

const _DB = window.DB;

// ============================================================ MIXTURES
const MixturesPage = ({setPage, setSelectedMol}) => {
  const mixes = _DB.mixtures;
  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">silver · mixture_core.parquet</div>
        <h1 className="page-title">Mixtures</h1>
        <p className="page-sub">
          PR-G governed blends. Mixtures are silver-layer entities and are not model_ready subjects in V1;
          component fractions come from the property-governance bundle.
        </p>
      </div>
      <div className="grid-2">
        {mixes.map(mx => {
          const compsResolved = mx.components.map(c=>{
            const m = _DB.mols.find(x=>x.mol_id===c.mol_id);
            return {...c, r_name: m?m.r_name:c.mol_id, formula: m?m.formula:"", family: m?m.family:""};
          });
          return (
            <div key={mx.mixture_id} className="card">
              <div className="card-head">
                <div className="card-title" style={{fontFamily:"var(--font-serif)", fontSize:16}}>{mx.mixture_name}</div>
                <div className="card-sub">{mx.mixture_id}</div>
              </div>
              <div className="card-body">
                <div style={{display:"flex", gap:8, flexWrap:"wrap", marginBottom:14}}>
                  <SafetyPill cls={mx.ashrae_class}/>
                  <span className="pill">GWP <span className="strong" style={{marginLeft:4}}>{fmt(mx.gwp,0)}</span></span>
                  <span className="pill">Glide <span className="strong" style={{marginLeft:4}}>{fmt(mx.glide_k,1)}</span> K</span>
                  <span className="pill ghost">{mx.app}</span>
                </div>
                <div style={{marginBottom:8, fontSize:11.5, color:"var(--ink-subtle)", textTransform:"uppercase", letterSpacing:"0.05em"}}>
                  Composition
                </div>
                <div className="stack-bar" style={{height:14, marginBottom:10}}>
                  {compsResolved.map((c,i)=>(
                    <div key={i} style={{width: c.pct+"%", background: ["oklch(55% 0.11 205)","oklch(60% 0.12 150)","oklch(65% 0.13 65)","oklch(60% 0.14 330)"][i%4]}} title={`${c.r_name} · ${c.pct}%`}/>
                  ))}
                </div>
                {compsResolved.map((c,i)=>(
                  <div key={i} style={{display:"flex", alignItems:"center", gap:10, padding:"6px 0", fontSize:13}}>
                    <span style={{width:10, height:10, borderRadius:2, background:["oklch(55% 0.11 205)","oklch(60% 0.12 150)","oklch(65% 0.13 65)","oklch(60% 0.14 330)"][i%4]}}/>
                    <a onClick={()=>{setSelectedMol(c.mol_id); setPage("molecule");}} style={{cursor:"pointer"}}>{c.r_name}</a>
                    <span className="mono subtle" style={{fontSize:11}}><Formula str={c.formula}/></span>
                    <span style={{marginLeft:"auto"}} className="mono">{fmt(c.pct,1)}%</span>
                  </div>
                ))}
                {mx.app && /unresolved/i.test(mx.app) && (
                  <div style={{marginTop:12, padding:"8px 10px", background:"var(--warn-soft)", borderRadius:"var(--radius)",
                               fontSize:12, color:"oklch(42% 0.12 65)", display:"flex", gap:8, alignItems:"center"}}>
                    <Icon name="warn" size={12}/>
                    Unresolved fraction group — retained without imputation.
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================ PROPERTIES REGISTRY
const PropertiesPage = () => {
  const ps = _DB.properties;
  const [group, setGroup] = useState("all");
  const groups = Array.from(new Set(ps.map(p=>p.group)));
  const rows = group==="all" ? ps : ps.filter(p=>p.group===group);
  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">gold · property_dictionary.parquet</div>
        <h1 className="page-title">Canonical property registry</h1>
        <p className="page-sub">
          The canonical feature key namespace. {fmtInt(_DB.stats.canonical_keys)} recommended keys,
          of which <span className="mono strong">{_DB.stats.strict_keys}</span> are ML-strict.
        </p>
      </div>
      <div className="card">
        <div className="filterbar">
          <span className="filter-label">Group</span>
          <div className="chip-group">
            <button className={"chip "+(group==="all"?"active":"")} onClick={()=>setGroup("all")}>All</button>
            {groups.map(g=>(
              <button key={g} className={"chip "+(group===g?"active":"")} onClick={()=>setGroup(g)}>{g}</button>
            ))}
          </div>
        </div>
        <table className="data-table">
          <thead><tr>
            <th>Canonical feature key</th><th>Name</th><th>Group</th><th>Unit</th><th>Strict</th><th>Coverage</th>
          </tr></thead>
          <tbody>
            {rows.map(p=>{
              const cov = _DB.canonical.filter(c=>c.canonical_feature_key===p.key).length;
              const strictCov = _DB.canonical.filter(c=>c.canonical_feature_key===p.key && c.in_strict).length;
              return (
                <tr key={p.key}>
                  <td className="mono" style={{fontSize:12.5}}>{p.key}</td>
                  <td className="strong">{p.name}</td>
                  <td><span className="pill ghost">{p.group}</span></td>
                  <td className="mono subtle" style={{fontSize:12}}>{p.unit}</td>
                  <td>{p.strict
                    ? <span className="pill good" style={{fontSize:10}}><span className="pill-dot"/>yes</span>
                    : <span className="pill" style={{fontSize:10}}>no</span>}</td>
                  <td style={{width:220}}>
                    <CoverageBar value={strictCov} total={Math.max(cov,1)} color={p.strict?"var(--good)":"var(--accent)"}/>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================ CANONICAL
const CanonicalPage = ({setPage, setSelectedMol}) => {
  const [filter, setFilter] = useState("all"); // all, strict, proxy, conflict
  const rows = useMemo(()=>{
    let rs = _DB.canonical;
    if (filter==="strict") rs = rs.filter(c=>c.in_strict);
    if (filter==="proxy") rs = rs.filter(c=>c.is_proxy_or_screening);
    if (filter==="conflict") rs = rs.filter(c=>c.conflict_flag || c.source_divergence_flag);
    return rs;
  }, [filter]);
  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">gold · property_recommended_canonical</div>
        <h1 className="page-title">Canonical layer</h1>
        <p className="page-sub">
          The recommended canonical value per (molecule, feature) after source-priority selection
          and governance bundle fusion. Strict slice powers ML outputs.
        </p>
      </div>
      <div className="card">
        <div className="filterbar">
          <div className="chip-group">
            <button className={"chip "+(filter==="all"?"active":"")} onClick={()=>setFilter("all")}>All · {_DB.stats.property_recommended_canonical}</button>
            <button className={"chip "+(filter==="strict"?"active":"")} onClick={()=>setFilter("strict")}>Strict · {_DB.stats.property_recommended_canonical_strict}</button>
            <button className={"chip "+(filter==="proxy"?"active":"")} onClick={()=>setFilter("proxy")}>Proxy-only · 466</button>
            <button className={"chip "+(filter==="conflict"?"active":"")} onClick={()=>setFilter("conflict")}>Divergence · 35</button>
          </div>
          <span className="mono subtle" style={{marginLeft:"auto", fontSize:11.5}}>{rows.length} rows</span>
        </div>
        <table className="data-table">
          <thead><tr>
            <th>Molecule</th><th>Canonical key</th><th>Value</th><th>Unit</th><th>Source</th>
            <th>Rank</th><th>Quality</th><th>Flags</th>
          </tr></thead>
          <tbody>
            {rows.map((c,i)=>{
              const m = _DB.mols.find(x=>x.mol_id===c.mol_id);
              return (
                <tr key={i} onClick={()=>{ if(m){setSelectedMol(m.mol_id); setPage("molecule");}}}>
                  <td>
                    <div className="strong" style={{fontFamily:"var(--font-serif)"}}>{m?m.r_name:"—"}</div>
                    <div className="col-id">{c.mol_id}</div>
                  </td>
                  <td className="mono" style={{fontSize:12}}>{c.canonical_feature_key}</td>
                  <td className="col-num strong">{c.value}</td>
                  <td className="mono subtle" style={{fontSize:12}}>{c.unit}</td>
                  <td style={{fontSize:12.5}}>{c.selected_source_name}</td>
                  <td className="col-num mono">{c.source_priority_rank}</td>
                  <td style={{width:120}}>
                    <div className="quality-bar"><div style={{width:(c.data_quality_score_100||0)+"%"}}/></div>
                  </td>
                  <td>
                    <div style={{display:"flex", gap:4, flexWrap:"wrap"}}>
                      {c.in_strict && <span className="pill good" style={{fontSize:10}}>strict</span>}
                      {c.is_proxy_or_screening && <span className="pill" style={{fontSize:10}}>proxy</span>}
                      {c.conflict_flag && <span className="pill warn" style={{fontSize:10}}>conflict</span>}
                      {c.source_divergence_flag && <span className="pill warn" style={{fontSize:10}}>diverge</span>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================ REVIEW
const ReviewPage = ({setPage, setSelectedMol}) => (
  <div className="page">
    <div className="page-head">
      <div className="page-eyebrow">gold · canonical_review_decisions</div>
      <h1 className="page-title">Canonical review decisions</h1>
      <p className="page-sub">
        Manual adjudication log for canonical-layer conflicts and strict-rejection rows.
        {" "}<span className="mono strong">{_DB.stats.review_decisions_applied}</span> decisions applied,
        {" "}<span className="mono strong">{_DB.stats.review_queue_open}</span> open.
      </p>
    </div>
    <div className="stat-grid" style={{marginBottom:20}}>
      <div className="stat"><div className="stat-label">accept_selected_source</div><div className="stat-value">35</div><div className="stat-foot">retain top-rank value despite divergence</div></div>
      <div className="stat"><div className="stat-label">accept_out_of_strict</div><div className="stat-value">85</div><div className="stat-foot">keep canonical; exclude from ML strict</div></div>
      <div className="stat"><div className="stat-label">proxy-only policy</div><div className="stat-value">13</div><div className="stat-foot">rules · 396 rows → strict</div></div>
      <div className="stat stat-accent"><div className="stat-label">open queue</div><div className="stat-value" style={{color:"var(--good)"}}>0</div><div className="stat-foot">green — nothing to adjudicate</div></div>
    </div>
    <div className="card">
      <div className="card-head"><div className="card-title">Decision log</div>
        <div className="card-sub">most-recent first</div></div>
      <table className="data-table">
        <thead><tr>
          <th>Decision</th><th>Molecule</th><th>Canonical key</th><th>Type</th><th>Note</th><th>Applied</th>
        </tr></thead>
        <tbody>
          {_DB.reviewQueue.map(d=>{
            const m = _DB.mols.find(x=>x.mol_id===d.mol_id);
            return (
              <tr key={d.decision_id} onClick={()=>{ if(m){setSelectedMol(d.mol_id); setPage("molecule");}}}>
                <td className="col-id">{d.decision_id}</td>
                <td className="strong" style={{fontFamily:"var(--font-serif)"}}>{m?m.r_name:d.mol_id}</td>
                <td className="mono" style={{fontSize:12}}>{d.canonical_feature_key}</td>
                <td>
                  <span className={"pill " + (d.decision==="accept_selected_source"?"accent":"")}>
                    {d.decision}
                  </span>
                </td>
                <td style={{fontSize:12.5, maxWidth:420}}>{d.note}</td>
                <td className="mono subtle" style={{fontSize:12}}>{d.applied}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  </div>
);

// ============================================================ REGULATORY
const RegulatoryPage = ({setPage, setSelectedMol}) => {
  const [j, setJ] = useState("all");
  const js = Array.from(new Set(_DB.regulatory.map(r=>r.jurisdiction)));
  const rows = j==="all" ? _DB.regulatory : _DB.regulatory.filter(r=>r.jurisdiction===j);
  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">silver · regulatory_status.parquet</div>
        <h1 className="page-title">Regulatory status</h1>
        <p className="page-sub">EPA SNAP, EU F-Gas, Kigali, Montreal Protocol listings scoped to end-use and jurisdiction.</p>
      </div>
      <div className="card">
        <div className="filterbar">
          <span className="filter-label">Jurisdiction</span>
          <div className="chip-group">
            <button className={"chip "+(j==="all"?"active":"")} onClick={()=>setJ("all")}>All</button>
            {js.map(x=>(
              <button key={x} className={"chip "+(j===x?"active":"")} onClick={()=>setJ(x)}>{x}</button>
            ))}
          </div>
        </div>
        <table className="data-table">
          <thead><tr>
            <th>Molecule</th><th>Jurisdiction</th><th>End use</th><th>Acceptability</th><th>Effective</th>
          </tr></thead>
          <tbody>
            {rows.map((r,i)=>{
              const m = _DB.mols.find(x=>x.mol_id===r.mol_id);
              return (
                <tr key={i} onClick={()=>{ if(m){setSelectedMol(m.mol_id); setPage("molecule");}}}>
                  <td className="strong" style={{fontFamily:"var(--font-serif)"}}>{m?m.r_name:r.mol_id}</td>
                  <td>{r.jurisdiction}</td>
                  <td>{r.end_use}</td>
                  <td>
                    <span className={"pill " + (
                      /Accept|Permitted/i.test(r.acceptability) ? "good" :
                      /Banned|Unacceptable/i.test(r.acceptability) ? "danger" :
                      /Phase/i.test(r.acceptability) ? "warn" : ""
                    )}>
                      {r.acceptability}
                    </span>
                  </td>
                  <td className="mono subtle" style={{fontSize:12}}>{r.effective}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================ CYCLE
const CyclePage = () => (
  <div className="page">
    <div className="page-head">
      <div className="page-eyebrow">silver · cycle_operating_point.parquet</div>
      <h1 className="page-title">Cycle operating points</h1>
      <p className="page-sub">PR-D standard refrigeration cycle — R-PhysGen reference points evaluated via CoolProp 6.6.0.</p>
    </div>
    <div className="grid-2">
      <div className="card">
        <div className="card-head"><div className="card-title">Standard evaporator / condenser</div>
          <div className="card-sub">CYC_REF_STD</div></div>
        <div className="card-body">
          <dl className="kv-list" style={{gridTemplateColumns:"180px 1fr"}}>
            <dt>Evaporator T</dt><dd>278.15 K <span className="subtle">(5 °C)</span></dd>
            <dt>Condenser T</dt><dd>318.15 K <span className="subtle">(45 °C)</span></dd>
            <dt>Superheat</dt><dd>5 K</dd>
            <dt>Subcooling</dt><dd>5 K</dd>
            <dt>Isentropic efficiency</dt><dd>0.70</dd>
            <dt>Cycle model</dt><dd>vapor compression · single stage</dd>
            <dt>EOS source</dt><dd>CoolProp.HEOS backend</dd>
            <dt>Molecules evaluated</dt><dd>398 observations / 120 promoted</dd>
          </dl>
        </div>
      </div>
      <div className="card">
        <div className="card-head"><div className="card-title">R-744 transcritical</div>
          <div className="card-sub">CYC_REF_CO2_TC</div></div>
        <div className="card-body">
          <dl className="kv-list" style={{gridTemplateColumns:"180px 1fr"}}>
            <dt>Evaporator T</dt><dd>273.15 K <span className="subtle">(0 °C)</span></dd>
            <dt>Gas cooler outlet</dt><dd>308.15 K <span className="subtle">(35 °C)</span></dd>
            <dt>High-side pressure</dt><dd>9000 kPa</dd>
            <dt>Superheat</dt><dd>5 K</dd>
            <dt>Isentropic efficiency</dt><dd>0.70</dd>
            <dt>Cycle model</dt><dd>transcritical CO₂ · single stage</dd>
            <dt>EOS source</dt><dd>CoolProp.HEOS (Span-Wagner)</dd>
          </dl>
        </div>
      </div>
    </div>

    <div className="section-title">COP at standard cycle — promoted subset</div>
    <div className="card" style={{padding:0}}>
      <table className="data-table">
        <thead><tr><th>Molecule</th><th>Family</th><th>Tier</th><th>COP</th><th>Vol. capacity / kJ·m⁻³</th><th>Source</th></tr></thead>
        <tbody>
          {_DB.canonical.filter(c=>c.canonical_feature_key==="cycle.cop_standard").map((c,i)=>{
            const m = _DB.mols.find(x=>x.mol_id===c.mol_id);
            const vc = _DB.canonical.find(x=>x.mol_id===c.mol_id && x.canonical_feature_key==="cycle.volumetric_capacity_kj_m3");
            return (
              <tr key={i}>
                <td className="strong" style={{fontFamily:"var(--font-serif)"}}>{m?m.r_name:c.mol_id}</td>
                <td><span className="mono subtle" style={{fontSize:11.5}}>{m?.family}</span></td>
                <td><TierPill tier={m?.tier||"C"}/></td>
                <td className="col-num strong">{fmt(Number(c.value),2)}</td>
                <td className="col-num">{vc?fmt(Number(vc.value),0):"—"}</td>
                <td style={{fontSize:12.5}}>{c.selected_source_name}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  </div>
);

// ============================================================ ACTIVE LEARNING
const ActiveLearningPage = () => (
  <div className="page">
    <div className="page-head">
      <div className="page-eyebrow">gold · active_learning_queue.parquet</div>
      <h1 className="page-title">Active learning queue</h1>
      <p className="page-sub">
        PR-H nomination output. Not configured in current build — optional manual CSV at
        {" "}<span className="mono">data/raw/manual/active_learning_queue.csv</span> drives real entries. Shown below is an illustrative preview.
      </p>
    </div>
    <div className="card">
      <div className="card-head">
        <div className="card-title">Illustrative nominations</div>
        <div className="card-sub">preview · not yet policy-driven</div>
      </div>
      <table className="data-table">
        <thead><tr>
          <th>Item</th><th>Candidate</th><th>Target feature</th><th>Uncertainty</th><th>Priority</th><th>Status</th>
        </tr></thead>
        <tbody>
          {_DB.activeLearning.map(a=>(
            <tr key={a.item_id}>
              <td className="col-id">{a.item_id}</td>
              <td className="col-id">{a.mol_id}</td>
              <td className="mono" style={{fontSize:12}}>{a.feature}</td>
              <td className="col-num">{fmt(a.uncertainty,2)}</td>
              <td>
                <span className={"pill " + (a.priority===1?"danger":a.priority===2?"warn":"")}>
                  P{a.priority}
                </span>
              </td>
              <td><span className="pill ghost">{a.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

// ============================================================ SOURCES
const SourcesPage = () => {
  const sources = [
    {name:"NIST WebBook (REFPROP 10.0)", type:"standard",    rank:1, obs:4210, note:"Primary thermophysical source for well-characterized refrigerants."},
    {name:"CoolProp 6.6.0",              type:"standard",    rank:2, obs:3894, note:"EOS-based evaluation, transcritical handling for R-744."},
    {name:"IPCC AR6 WG1",                type:"assessment",  rank:1, obs:286,  note:"GWP, atmospheric lifetime."},
    {name:"IPCC AR5 WG1",                type:"assessment",  rank:2, obs:312,  note:"Legacy GWP values retained for continuity."},
    {name:"ASHRAE 34-2022",              type:"standard",    rank:1, obs:148,  note:"Safety classification — A/B and flammability tier."},
    {name:"EPA SNAP",                    type:"regulatory",  rank:1, obs:63,   note:"US substitute acceptability."},
    {name:"EU F-Gas",                    type:"regulatory",  rank:1, obs:19,   note:"EU phase-down schedule."},
    {name:"Montreal Protocol Assessment 2022", type:"assessment",rank:1, obs:112, note:"ODP reference values."},
    {name:"DIPPR 801 (2020)",            type:"compiled",    rank:3, obs:1902, note:"Compiled literature — secondary for critical constants."},
    {name:"PubChem (bulk)",              type:"database",    rank:4, obs:5598, note:"Structure resolution + first-pass candidate intake."},
    {name:"R-PhysGen proxy heuristics v1", type:"proxy",     rank:9, obs:11196,note:"Local structure heuristics — screening only."},
  ];
  return (
    <div className="page">
      <div className="page-head">
        <div className="page-eyebrow">bronze · source_manifest.parquet</div>
        <h1 className="page-title">Sources & provenance</h1>
        <p className="page-sub">
          Registered sources, ranked by source-priority rules. Lower rank = higher preference during canonical selection.
        </p>
      </div>
      <div className="card">
        <table className="data-table">
          <thead><tr>
            <th>Source</th><th>Type</th><th>Priority rank</th><th>Observation count</th><th>Notes</th>
          </tr></thead>
          <tbody>
            {sources.map((s,i)=>(
              <tr key={i}>
                <td className="strong">{s.name}</td>
                <td><span className="pill ghost">{s.type}</span></td>
                <td className="col-num mono">{s.rank}</td>
                <td className="col-num">{fmtInt(s.obs)}</td>
                <td style={{fontSize:12.5, color:"var(--ink-muted)", maxWidth:520}}>{s.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

Object.assign(window, {
  MixturesPage, PropertiesPage, CanonicalPage, ReviewPage,
  RegulatoryPage, CyclePage, ActiveLearningPage, SourcesPage,
});
