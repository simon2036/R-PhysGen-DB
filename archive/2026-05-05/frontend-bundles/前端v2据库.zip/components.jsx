// Shared UI primitives used across pages.
// Exported to window at the bottom so other Babel scripts can use them.

const { useState, useEffect, useMemo, useRef } = React;

// ---------------------------------------------------------------- Icons
const Icon = ({name, size=14}) => {
  const paths = {
    dashboard: <><path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/></>,
    molecule:  <><circle cx="5" cy="5" r="2.5"/><circle cx="19" cy="5" r="2.5"/><circle cx="12" cy="12" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M7 6l3 4.5M17 6l-3 4.5M10 13l-3 4.5M14 13l3 4.5"/></>,
    mixture:   <><circle cx="9" cy="9" r="5"/><circle cx="15" cy="15" r="5"/></>,
    property:  <><path d="M4 20V8M12 20V4M20 20V12"/><path d="M3 20h18"/></>,
    canonical: <><path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/><path d="M9 12l2 2 4-4"/></>,
    review:    <><path d="M4 5h14l2 3v11a1 1 0 0 1-1 1H4z"/><path d="M8 12h8M8 16h5"/></>,
    regulatory:<><path d="M5 4h9l5 5v11H5z"/><path d="M14 4v5h5"/><path d="M9 13h6M9 17h4"/></>,
    cycle:     <><path d="M20 12a8 8 0 1 1-3-6.2"/><path d="M20 4v5h-5"/></>,
    al:        <><path d="M3 12l4-8 5 16 5-14 4 6"/></>,
    source:    <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 15 0 18-3-3-3-14.5 0-18z"/></>,
    download:  <><path d="M12 3v12"/><path d="M6 11l6 6 6-6"/><path d="M4 21h16"/></>,
    search:    <><circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/></>,
    sun:       <><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></>,
    moon:      <><path d="M20 14A8 8 0 1 1 10 4a7 7 0 0 0 10 10z"/></>,
    filter:    <><path d="M3 5h18M6 12h12M10 19h4"/></>,
    copy:      <><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></>,
    external:  <><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M20 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h5"/></>,
    chevron:   <><path d="M9 6l6 6-6 6"/></>,
    down:      <><path d="M6 9l6 6 6-6"/></>,
    info:      <><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/></>,
    check:     <><path d="M5 12l5 5 9-11"/></>,
    warn:      <><path d="M12 4l10 17H2z"/><path d="M12 10v5M12 18v.01"/></>,
    flag:      <><path d="M5 20V4l10 2-2 4 4 2-2 4H5"/></>,
  };
  return (
    <svg className="nav-icon" width={size} height={size} viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      {paths[name]}
    </svg>
  );
};

// ---------------------------------------------------------------- Brand
const Brand = () => (
  <div className="brand">
    <div className="brand-mark">R</div>
    <div>
      <div className="brand-name">R-PhysGen-DB</div>
      <div className="brand-sub">refrigerant · v1.5.0-draft</div>
    </div>
  </div>
);

// ---------------------------------------------------------------- Theme toggle
const ThemeToggle = ({theme, setTheme}) => (
  <div className="theme-toggle" role="radiogroup" aria-label="Theme">
    <button className={theme==="light"?"active":""} onClick={()=>setTheme("light")} aria-pressed={theme==="light"}>
      <Icon name="sun" size={12}/> Light
    </button>
    <button className={theme==="dark"?"active":""} onClick={()=>setTheme("dark")} aria-pressed={theme==="dark"}>
      <Icon name="moon" size={12}/> Dark
    </button>
  </div>
);

// ---------------------------------------------------------------- Sidebar
const NAV = [
  {group:"Browse", items:[
    {id:"dashboard",  label:"Home",                 icon:"dashboard"},
    {id:"molecules",  label:"Molecules",            icon:"molecule"},
    {id:"mixtures",   label:"Mixtures",             icon:"mixture"},
    {id:"compare",    label:"Compare",              icon:"property"},
    {id:"properties", label:"Property registry",    icon:"property"},
  ]},
  {group:"Curation", items:[
    {id:"canonical",  label:"Canonical layer",      icon:"canonical"},
    {id:"review",     label:"Review decisions",     icon:"review"},
    {id:"regulatory", label:"Regulatory",           icon:"regulatory"},
  ]},
  {group:"Research", items:[
    {id:"cycle",      label:"Cycle operating points", icon:"cycle"},
    {id:"al",         label:"Active learning queue",  icon:"al"},
    {id:"sources",    label:"Sources & provenance",   icon:"source"},
  ]},
];

const Sidebar = ({page, setPage, theme, setTheme}) => (
  <aside className="sidebar" aria-label="Primary">
    <Brand/>
    {NAV.map(g => (
      <div key={g.group}>
        <div className="nav-section">{g.group}</div>
        {g.items.map(it => (
          <button
            type="button"
            key={it.id}
            className={"nav-item " + (page===it.id?"active":"")}
            onClick={()=>setPage(it.id)}
            aria-current={page===it.id ? "page" : undefined}
          >
            <Icon name={it.icon}/>
            <span>{it.label}</span>
            {it.badge && <span className="nav-badge">{it.badge}</span>}
          </button>
        ))}
      </div>
    ))}
    <div className="sidebar-foot">
      <ThemeToggle theme={theme} setTheme={setTheme}/>
      <div className="version-line">
        Build <span className="strong">v1.5.0-draft</span><br/>
        Snapshot 2026-04-24<br/>
        <span style={{color:"var(--ink-subtle)"}}>Demo snapshot · local mock data</span>
      </div>
    </div>
  </aside>
);

// ---------------------------------------------------------------- Topbar
const Topbar = ({query, onQuery}) => (
  <div className="topbar">
    <div className="search">
      <Icon name="search" size={14}/>
      <input value={query} onChange={e=>onQuery(e.target.value)}
             placeholder="Search molecule, CAS, formula, InChIKey, mixture, property key…"
             aria-label="Search"/>
      <span className="kbd">⌘K</span>
    </div>
    <div className="topbar-right">
      <span className="pill ghost" title="Prototype dataset; not backed by a live DuckDB instance.">
        <span style={{width:6, height:6, background:"var(--ink-subtle)", borderRadius:"50%", display:"inline-block"}}/> Prototype · local mock data
      </span>
    </div>
  </div>
);

// ---------------------------------------------------------------- Downloads
function toCsv(rows, columns) {
  const esc = (v) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s;
  };
  return [columns.join(","), ...rows.map(r => columns.map(c => esc(r[c])).join(","))].join("\n");
}
function downloadText(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 800);
}
function copyText(s, onOk) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(s).then(()=>onOk && onOk()).catch(()=>{});
  }
}
function toBibtex(m) {
  return `@misc{rphysgendb_${m.mol_id},
  author       = {{R-PhysGen-DB contributors}},
  title        = {${m.r_name} canonical property record (${m.formula})},
  howpublished = {R-PhysGen-DB v1.5.0-draft, snapshot 2026-04-24, Record ${m.mol_id}},
  year         = {2026},
  note         = {Prototype dataset}
}`;
}

// ---------------------------------------------------------------- Formula rendering
const Formula = ({str}) => {
  if (!str) return null;
  const parts = [];
  let i = 0;
  while (i < str.length) {
    const ch = str[i];
    if (ch >= '0' && ch <= '9') {
      let n = "";
      while (i < str.length && str[i] >= '0' && str[i] <= '9') { n += str[i++]; }
      parts.push(<sub key={"s"+parts.length}>{n}</sub>);
    } else {
      parts.push(<React.Fragment key={"c"+parts.length}>{ch}</React.Fragment>);
      i++;
    }
  }
  return <span>{parts}</span>;
};

// ---------------------------------------------------------------- Tier pill
const TierPill = ({tier}) => (
  <span className={"pill tier-" + tier.toLowerCase()}>Tier {tier}</span>
);

// ---------------------------------------------------------------- Safety class pill
const SafetyPill = ({cls}) => {
  if (!cls) return <span className="subtle mono" style={{fontSize:11}}>—</span>;
  return <span className={"sc sc-" + cls}>{cls}</span>;
};

// ---------------------------------------------------------------- Number formatter
const fmt = (v, digits=3) => {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "string") return v;
  if (Math.abs(v) >= 1000) return v.toLocaleString(undefined, {maximumFractionDigits:0});
  return Number(v).toLocaleString(undefined, {maximumFractionDigits:digits});
};
const fmtInt = n => n == null ? "—" : Number(n).toLocaleString();

// ---------------------------------------------------------------- Simple line chart for coverage
const CoverageBar = ({value, total, color="var(--accent)"}) => {
  const pct = total ? Math.round(value/total*100) : 0;
  return (
    <div style={{display:"flex", alignItems:"center", gap:8}}>
      <div style={{flex:1, height:6, background:"var(--bg-sunken)", borderRadius:3, overflow:"hidden"}}>
        <div style={{width: pct+"%", height:"100%", background:color}}></div>
      </div>
      <span className="mono subtle" style={{fontSize:11, minWidth:36, textAlign:"right"}}>{pct}%</span>
    </div>
  );
};

// ---------------------------------------------------------------- Unit conversions
const UNITS = {
  SI: { tempLbl: "K", pressLbl: "kPa", T: v => v, P: v => v, tDigits: 1, pDigits: 0 },
  Eng: { tempLbl: "°C", pressLbl: "MPa", T: v => v == null ? v : v - 273.15, P: v => v == null ? v : v / 1000, tDigits: 1, pDigits: 3 },
};
const convertByUnit = (value, unit, u) => {
  if (value == null || value === "" || isNaN(Number(value))) return { v: value, unit };
  const num = Number(value);
  if (unit === "K" && u === "Eng") return { v: num - 273.15, unit: "°C" };
  if (unit === "kPa" && u === "Eng") return { v: num / 1000, unit: "MPa" };
  return { v: num, unit };
};

Object.assign(window, {
  Icon, Brand, ThemeToggle, Sidebar, Topbar, Formula, TierPill, SafetyPill,
  fmt, fmtInt, CoverageBar, NAV,
  toCsv, downloadText, copyText, toBibtex,
  UNITS, convertByUnit,
});
