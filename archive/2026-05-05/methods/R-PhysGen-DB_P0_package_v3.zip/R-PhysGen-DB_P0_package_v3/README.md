# R-PhysGen-DB P0 Draft Package（v3）

> 基线：`R-PhysGen-DB_P0_package (2).zip` + `R-PhysGen-DB_P0_review.md`  
> v3 目标：在 v2 已响应 24 项评审意见的基础上，进一步闭合 canonical key、manifest attempt、readiness config、迁移脚本和 PR-B 等价性检查。

## 本版核心增强

v2 已经覆盖评审报告中的 24 项问题。v3 继续修正了 v2 中仍可能落地受阻的五个点：

1. **canonical key 对齐现有 governance 体系**  
   `canonical_feature_registry.yaml` 改为 namespaced key，例如 `thermodynamic.normal_boiling_temperature`、`environmental.gwp_100yr`、`safety.safety_group`。同时保留 `legacy_property_name`，用于兼容当前 `boiling_point_c`、`gwp_100yr`、`ashrae_safety` 等 legacy projection。

2. **stage manifest 支持多次 attempt**  
   `stage_run_manifest.yaml` 主键改为 `run_id + stage_id + attempt_id`，避免 resume/retry 时同一 stage 只能记录一行。

3. **readiness 规则从 schema 描述升级为可执行 YAML config**  
   `research_task_readiness_rules.yaml` 现在包含 `rules:`，每个任务明确 `must_have`、`should_have`、`minimum_molecule_count`、proxy/strict/source 规则。

4. **迁移和验收脚本落地**  
   新增 `scripts/backfill_condition_set.py` 和 `scripts/pr_b_equivalence_check.py`，分别对应 condition migration 和 PR-B 输出等价性验收。

5. **补齐评审第七节建议的占位 schema**  
   新增 `mixture_composition.yaml` 和 `molecule_split_definition.yaml`，为 mixtures 与 split provenance 提前留下明确接口。

## 文件结构

```text
docs/
  p0_scope_and_exit_criteria.md
  p0_phase2_interfaces_draft.md
  p0_pipeline_stage_refactor_plan.md
  p0_validation_rules_draft.md
  p0_review_response_matrix.md

schemas/drafts/
  canonical_feature_registry.yaml
  observation_condition_set.yaml
  property_observation_v2.yaml
  normalization_rules.yaml
  stage_run_manifest.yaml
  research_task_readiness_rules.yaml
  mixture_composition.yaml
  molecule_split_definition.yaml

src/blueprints/
  pipeline_staged_blueprint.py

scripts/
  backfill_condition_set.py
  pr_b_equivalence_check.py
```

## 建议采用顺序

1. 先审 `docs/p0_review_response_matrix.md`，确认 24 项评审问题的处置方式；
2. 再审 `schemas/drafts/canonical_feature_registry.yaml`，确认 namespaced canonical keys 是否与 governance bundle 对齐；
3. 然后审 `stage_run_manifest.yaml` 和 `pipeline_staged_blueprint.py`，确认 stage/retry/resume 的工程语义；
4. 最后审两个脚本，决定是否进入 PR-A 或作为 PR-B/PR-C 的 CI 辅助工具。

## 合并建议

- PR-A：docs + schemas + scripts skeleton；
- PR-B：pipeline stage 化，强制运行 `scripts/pr_b_equivalence_check.py`；
- PR-C：condition_set 接入和 readiness validator。

本包仍是草案，但已经从“评审响应版”推进到“可开 PR 的 P0 工作包”。
