# Phase 2 接口草案（v3）

## 1. 目标

P0 不实现量子计算、多工况循环或主动学习后端，但必须把接口定义到足以避免实现歧义。接口的核心原则是：任何 Phase 2 结果都不能直接绕过数据库治理层，必须登记来源、记录 artifact、写回 observation 或扩展表，再由推荐层或 readiness 层消费。

通用规则：

- 每个 request/result 都有 `request_id`、`run_id`、`status`、`artifact_manifest_json`；
- 每个 result 都必须能回溯到 `source_manifest`；
- 每个 derived observation 必须带 `canonical_feature_key`、`quality_level`、`method`、`source_id`；
- 条件敏感结果必须引用 `condition_set_id` 或足以生成它的结构化条件；
- 所有 status 字段使用受控词表。

## 2. 通用枚举

```yaml
request_status_vocabulary:
  - queued
  - running
  - succeeded
  - failed
  - cancelled
  - superseded

quality_level_vocabulary:
  - computed_high
  - computed_standard
  - eos_model
  - estimated_group_contrib
  - ml_predicted
  - proxy_screening
```

## 3. Quantum Calculation Interface

### 3.1 QuantumCalculationRequest

```yaml
request_id: string
mol_id: string
isomeric_smiles: string
charge: int
spin_multiplicity: int
conformer_generation_method: ETKDG | MMFF | xTB | user_provided
conformer_force_field: MMFF94 | UFF | xTB-GFN2 | none
conformer_count: int
conformer_selection_criterion: lowest_energy | boltzmann_weighted | all
method_family: DFT | HF | post-HF | semi-empirical | force-field
program: ORCA | Gaussian | Psi4 | PySCF | xTB | other
program_version: string
model_chemistry: string
basis_set: string
theory_level: string
solvation_model: gas_phase | SMD | PCM | COSMO | other
target_canonical_features:
  - quantum.homo_energy
  - quantum.lumo_energy
  - quantum.homo_lumo_gap
artifact_root: string
metadata_json: string
```

`theory_level` 是可读的完整方法字符串，例如 `B3LYP/6-311+G(2d,p)/gas_phase`；`method_family` 只用于过滤和分层统计。

### 3.2 QuantumCalculationResult

```yaml
request_id: string
run_id: string
status: succeeded | failed | cancelled
failure_reason: string
program_version: string
wall_time_s: float
converged: bool
imaginary_frequency_count: int
lowest_energy_conformer_id: string
artifact_manifest_json: string
derived_observations_json: string
quality_level: computed_high | computed_standard | estimated_group_contrib
notes: string
```

### 3.3 默认计算 profile

P0 建议配置而非硬编码：

```yaml
default_quantum_profile:
  profile_id: quantum_std_dft_b3lyp_6311g2dp_gas
  geometry_optimization: B3LYP/6-311+G(2d,p)
  frequency: same_as_geometry
  conformer_generation: ETKDG
  conformer_prefilter: MMFF94
  conformer_count_minimum: 50
  conformer_selection: lowest_energy
  acceptance_rule:
    - converged = true
    - imaginary_frequency_count = 0
```

关键分子可用 `CCSD(T)/cc-pVTZ` 单点能做 benchmark，但这属于 `computed_high`，不应与常规 DFT 混成同一质量层。

### 3.4 Write-back

量子结果优先写回：

- `quantum.homo_energy`
- `quantum.lumo_energy`
- `quantum.homo_lumo_gap`
- `quantum.dipole_moment`（若注册）
- `quantum.polarizability`（若注册）

每条 observation 至少包含：

- `mol_id`
- `canonical_feature_key`
- `value_num`
- `unit`
- `method`
- `source_id`
- `quality_level`
- `condition_set_id`，通常对应 `gas_phase_298k`
- `normalization_rule_id`，如果有单位换算

## 4. Cycle Simulation Interface

### 4.1 CycleOperatingPoint

```yaml
evaporating_temperature_c: float
condensing_temperature_c: float
subcooling_k: float
superheat_k: float
compressor_isentropic_efficiency: float
ambient_temperature_c: float_optional
gas_cooler_outlet_temperature_c: float_optional
high_side_pressure_mpa: float_optional
```

`operating_point_hash` 应使用稳定 JSON 哈希生成：

```text
op_ + sha256(canonical_json(CycleOperatingPoint)).hexdigest()[:20]
```

### 4.2 CycleSimulationRequest

```yaml
request_id: string
mol_id: string_optional
fluid_name: string_optional
mixture_id: string_optional
mixture_composition_json: string_optional
cycle_case_id: string
operating_point: CycleOperatingPoint
operating_point_hash: string
cycle_model: subcritical_vapor_compression | transcritical_co2 | custom
eos_source: CoolProp | REFPROP | PC-SAFT | PR | SRK | custom
compressor_efficiency: float
artifact_root: string
metadata_json: string
```

纯物质：`mol_id` 必填，`mixture_composition_json` 为空。  
混合物：`mixture_id` 或 `mixture_composition_json` 必填，`mol_id` 可为空或指向主组分。

### 4.3 CycleSimulationResult

```yaml
request_id: string
run_id: string
status: succeeded | failed | cancelled
cycle_case_id: string
operating_point_hash: string
convergence_flag: bool
warning_flags_json: string
artifact_manifest_json: string
derived_observations_json: string
notes: string
```

### 4.4 Write-back

循环结果不应只产出 `cop` 和 `qvol` 两个摘要。建议最小写回：

- `cycle.cop`
- `cycle.volumetric_cooling_capacity`
- `cycle.pressure_ratio`
- `cycle.discharge_temperature`
- `cycle.evaporating_pressure`（待注册）
- `cycle.condensing_pressure`（待注册）
- `cycle.specific_cooling_capacity`（待注册）
- `cycle.compressor_work`（待注册）

每条循环 observation 必须有 `cycle_case_id`、`operating_point_hash` 和 `condition_set_id`。

## 5. Active Learning Queue Interface

### 5.1 Queue Entry

```yaml
queue_entry_id: string
mol_id: string
campaign_id: string
model_version: string
acquisition_strategy: pareto | uncertainty | novelty | diversity | manual
priority_score: float
uncertainty_score: float
novelty_score: float
feasibility_score: float
hard_constraint_status: passed | failed | partially_passed | not_evaluated
recommended_next_action: run_quantum | run_cycle | manual_curation | literature_search | defer | reject
payload_json: string
created_at: timestamp
updated_at: timestamp
expires_at: timestamp_optional
```

### 5.2 设计规则

主动学习队列只记录候选被提名的原因和下一步建议，不直接修改 `model_ready` 或推荐值。新数据必须通过 source/observation/governance 进入数据库。

## 6. 建议预留扩展表

- `quantum_job`
- `quantum_artifact`
- `cycle_case`
- `cycle_result`
- `active_learning_queue`
- `active_learning_decision_log`

P0 只定义接口。V1.5 才决定哪些扩展表正式落地。
