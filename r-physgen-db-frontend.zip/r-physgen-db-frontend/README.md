# R-PhysGen-DB Frontend Delivery

This package contains two deliverables:

1. `docs/frontend-blueprint.png` — the visual frontend planning blueprint.
2. `frontend/` — a complete Next.js + TypeScript frontend scaffold for the R-PhysGen-DB repository.

Recommended repository placement:

```text
R-PhysGen-DB/
  data/...
  frontend/   <- copy this folder here
```

Then run:

```bash
cd frontend
pnpm install
pnpm dev
```

The frontend can start from the demo dataset in `frontend/public/data/compounds.json`. For the real repository dataset, set `R_PHYSGEN_DATA_PATH` in `.env.local`, or convert a CSV file using `scripts/normalize-csv.mjs`.
