import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";

export const metadata: Metadata = {
  title: "R-PhysGen-DB",
  description: "A modern academic database interface for physical-property and refrigerant candidate data.",
  metadataBase: new URL("https://example.org")
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <SiteHeader />
        <main className="relative z-10 mx-auto max-w-7xl px-6 py-10 md:py-14">{children}</main>
      </body>
    </html>
  );
}
