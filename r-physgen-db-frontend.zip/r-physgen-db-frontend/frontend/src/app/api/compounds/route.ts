import { NextRequest, NextResponse } from "next/server";
import { loadCompounds, loadDataset } from "@/lib/data.server";
import { filterCompounds, parseListParam, parseNumberParam } from "@/lib/search";

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const records = await loadCompounds();
  const dataset = await loadDataset();

  const filtered = filterCompounds(records, {
    text: url.searchParams.get("q") ?? undefined,
    generations: parseListParam(url.searchParams.get("generation")),
    safety: parseListParam(url.searchParams.get("safety")),
    gwpMax: parseNumberParam(url.searchParams.get("gwpMax")),
    odpMax: parseNumberParam(url.searchParams.get("odpMax")),
    bpMin: parseNumberParam(url.searchParams.get("bpMin")),
    bpMax: parseNumberParam(url.searchParams.get("bpMax")),
    tcritMin: parseNumberParam(url.searchParams.get("tcritMin")),
    tcritMax: parseNumberParam(url.searchParams.get("tcritMax")),
    pcritMin: parseNumberParam(url.searchParams.get("pcritMin")),
    pcritMax: parseNumberParam(url.searchParams.get("pcritMax"))
  });

  return NextResponse.json({
    meta: {
      dataset: dataset.meta,
      count: filtered.length,
      total: records.length,
      query: Object.fromEntries(url.searchParams.entries())
    },
    records: filtered
  });
}
