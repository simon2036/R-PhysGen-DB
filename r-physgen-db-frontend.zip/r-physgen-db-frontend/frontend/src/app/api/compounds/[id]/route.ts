import { NextRequest, NextResponse } from "next/server";
import { getCompoundById, loadDataset } from "@/lib/data.server";

export async function GET(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [compound, dataset] = await Promise.all([getCompoundById(id), loadDataset()]);

  if (!compound) {
    return NextResponse.json({ error: "Compound not found", id }, { status: 404 });
  }

  return NextResponse.json({ meta: { dataset: dataset.meta }, record: compound });
}
