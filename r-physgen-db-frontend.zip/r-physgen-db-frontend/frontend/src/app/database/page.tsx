import { ExplorerClient } from "@/components/explorer-client";
import { loadCompounds } from "@/lib/data.server";

export default async function DatabasePage({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const records = await loadCompounds();
  const params = searchParams ? await searchParams : {};
  const q = typeof params.q === "string" ? params.q : "";

  return (
    <div className="space-y-8">
      <div>
        <div className="eyebrow">Search and screen</div>
        <h1 className="mt-3 section-title">Database Explorer</h1>
        <p className="mt-3 max-w-3xl text-slate-400">
          Filter by environmental indicators, safety class, and thermophysical properties. Export filtered records or send them to the comparison view.
        </p>
      </div>
      <ExplorerClient records={records} initialQuery={q} />
    </div>
  );
}
