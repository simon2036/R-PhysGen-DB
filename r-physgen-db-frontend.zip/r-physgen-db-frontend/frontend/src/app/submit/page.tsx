import { GlassCard } from "@/components/glass-card";

const checklist = [
  "Every numeric property has a unit and canonical field name.",
  "Every record has at least one sourceRef before publication.",
  "Computed values are clearly separated from experimental values.",
  "GWP/ODP and safety class definitions are versioned.",
  "CAS, formula, and SMILES are cross-checked against external identifiers where possible.",
  "Missing values are null, not zero."
];

export default function SubmitPage() {
  return (
    <div className="space-y-8">
      <div>
        <div className="eyebrow">Curation workflow</div>
        <h1 className="mt-3 section-title">Submit or curate data</h1>
        <p className="mt-3 max-w-3xl text-slate-400">
          This page is a frontend scaffold for future authenticated submissions. For now, it documents the data-quality checklist and expected CSV/JSON import workflow.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <GlassCard>
          <h2 className="text-2xl font-semibold text-white">Publication checklist</h2>
          <ul className="mt-5 space-y-3 text-sm leading-6 text-slate-300">
            {checklist.map((item) => <li key={item}>• {item}</li>)}
          </ul>
        </GlassCard>

        <GlassCard>
          <h2 className="text-2xl font-semibold text-white">CSV import example</h2>
          <pre className="mt-5 overflow-auto rounded-2xl border border-line bg-ink/80 p-5 text-sm leading-7 text-cyan">{`node scripts/normalize-csv.mjs ../data/raw_refrigerants.csv public/data/compounds.json
pnpm dev
# inspect /database and /api/compounds before publishing`}</pre>
          <p className="mt-5 text-sm leading-6 text-slate-400">
            In production, connect this page to an authenticated review workflow with draft records, validation errors, and curator approval states.
          </p>
        </GlassCard>
      </div>
    </div>
  );
}
