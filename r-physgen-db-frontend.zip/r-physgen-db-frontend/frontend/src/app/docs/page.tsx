import { GlassCard } from "@/components/glass-card";

const schema = `{
  id: string,
  name: string,
  formula: string,
  cas?: string,
  generation: string,
  category: string,
  safety: string,
  gwp100?: number | null,
  odp?: number | null,
  boilingPointC?: number | null,
  criticalTempK?: number | null,
  criticalPressureMPa?: number | null,
  molecularWeight?: number | null,
  confidence: "reviewed" | "experimental" | "computed" | "estimated" | "draft",
  tags: string[],
  sourceRefs: SourceRef[]
}`;

export default function DocsPage() {
  return (
    <div className="space-y-8">
      <div>
        <div className="eyebrow">Developer interface</div>
        <h1 className="mt-3 section-title">API and data contract</h1>
        <p className="mt-3 max-w-3xl text-slate-400">
          Keep the frontend and database aligned by treating this schema as the public data contract. Add fields only when units, sources, and confidence are defined.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <GlassCard>
          <h2 className="text-2xl font-semibold text-white">Endpoints</h2>
          <div className="mt-5 space-y-3 text-sm text-slate-300">
            <pre className="rounded-2xl border border-line bg-ink/80 p-4 text-cyan">GET /api/compounds</pre>
            <pre className="rounded-2xl border border-line bg-ink/80 p-4 text-cyan">GET /api/compounds?q=R-1234yf&amp;gwpMax=150&amp;safety=A2L</pre>
            <pre className="rounded-2xl border border-line bg-ink/80 p-4 text-cyan">GET /api/compounds/R-1234yf</pre>
          </div>
        </GlassCard>

        <GlassCard>
          <h2 className="text-2xl font-semibold text-white">Query parameters</h2>
          <ul className="mt-5 space-y-3 text-sm leading-6 text-slate-300">
            <li><span className="font-mono text-cyan">q</span>: free-text search across id, name, formula, CAS, tags, notes, and sources.</li>
            <li><span className="font-mono text-cyan">generation</span>: comma-separated generation/category labels.</li>
            <li><span className="font-mono text-cyan">safety</span>: comma-separated safety classes, such as A1,A2L,A3.</li>
            <li><span className="font-mono text-cyan">gwpMax</span>, <span className="font-mono text-cyan">odpMax</span>: environmental screening cutoffs.</li>
            <li><span className="font-mono text-cyan">bpMin</span>, <span className="font-mono text-cyan">bpMax</span>, <span className="font-mono text-cyan">tcritMin</span>: thermophysical ranges.</li>
          </ul>
        </GlassCard>
      </div>

      <GlassCard>
        <h2 className="text-2xl font-semibold text-white">Compound schema</h2>
        <pre className="mt-5 overflow-auto rounded-2xl border border-line bg-ink/80 p-5 text-sm leading-7 text-slate-300">{schema}</pre>
      </GlassCard>
    </div>
  );
}
