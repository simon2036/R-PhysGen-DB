import { CompareClient } from "@/components/compare-client";
import { loadCompounds } from "@/lib/data.server";

export default async function ComparePage({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const records = await loadCompounds();
  const params = searchParams ? await searchParams : {};
  const initialIds = typeof params.ids === "string" ? params.ids.split(",").filter(Boolean) : [];

  return (
    <div className="space-y-8">
      <div>
        <div className="eyebrow">Decision support</div>
        <h1 className="mt-3 section-title">Compare candidates</h1>
        <p className="mt-3 max-w-3xl text-slate-400">
          Normalize properties across selected candidates. This view is designed for screening discussions, not final engineering qualification.
        </p>
      </div>
      <CompareClient records={records} initialIds={initialIds} />
    </div>
  );
}
