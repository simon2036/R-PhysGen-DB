import Link from "next/link";
import { HeroSearch } from "@/components/hero-search";
import { GlassCard } from "@/components/glass-card";
import { StatCard } from "@/components/stat-card";
import { MiniLine } from "@/components/mini-line";
import { loadCompounds, loadDataset } from "@/lib/data.server";
import { formatNumber } from "@/lib/format";

export default async function HomePage() {
  const dataset = await loadDataset();
  const records = await loadCompounds();
  const sourceCount = records.reduce((sum, record) => sum + record.sourceRefs.length, 0);
  const lowGwp = records.filter((record) => typeof record.gwp100 === "number" && record.gwp100 <= 10).length;
  const featured = records.slice(0, 3);

  return (
    <div className="space-y-12">
      <section className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
        <div>
          <div className="eyebrow">Refrigerant physical-property database</div>
          <h1 className="mt-5 max-w-4xl text-5xl font-semibold tracking-tight text-white md:text-7xl">
            Discover low-impact candidates with source-aware scientific data.
          </h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
            R-PhysGen-DB is framed as a modern academic database: fast search, rigorous property records, reproducible exports, and API-ready data access for next-generation refrigerant research.
          </p>
          <div className="mt-8">
            <HeroSearch />
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/database" className="btn-primary">Browse database</Link>
            <Link href="/compare" className="btn-secondary">Compare candidates</Link>
            <Link href="/docs" className="btn-secondary">Read API docs</Link>
          </div>
        </div>
        <GlassCard className="relative overflow-hidden">
          <div className="absolute right-[-6rem] top-[-6rem] h-64 w-64 rounded-full bg-cyan/10 blur-3xl" />
          <div className="eyebrow">Dataset version</div>
          <div className="mt-3 text-4xl font-semibold text-white">{String(dataset.meta.version ?? "0.1.0")}</div>
          <p className="mt-3 text-sm leading-6 text-slate-400">Updated {String(dataset.meta.updatedAt ?? "unknown")}. Replace demo values with curated repository records before publication.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
            <StatCard label="Records" value={records.length} helper="Compound-level entries" />
            <StatCard label="Low-GWP" value={lowGwp} helper="GWP100 ≤ 10" />
            <StatCard label="Sources" value={sourceCount} helper="Attached references" />
          </div>
        </GlassCard>
      </section>

      <section className="grid gap-6 lg:grid-cols-3">
        {featured.map((record) => (
          <Link key={record.id} href={`/compound/${encodeURIComponent(record.id)}`} className="group rounded-3xl border border-line bg-panel/80 p-6 shadow-card transition hover:border-cyan/60 hover:bg-panel2/90">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="font-mono text-sm text-cyan">{record.id}</div>
                <h2 className="mt-2 text-xl font-semibold text-white group-hover:text-cyan">{record.name}</h2>
                <p className="mt-2 font-mono text-sm text-slate-400">{record.formula}</p>
              </div>
              <span className="rounded-full border border-amber/30 bg-amber/10 px-3 py-1 text-xs text-amber">{record.safety}</span>
            </div>
            <div className="mt-5 grid grid-cols-3 gap-3 text-sm">
              <div><span className="block text-slate-500">GWP</span><span className="text-mint">{formatNumber(record.gwp100)}</span></div>
              <div><span className="block text-slate-500">ODP</span><span className="text-mint">{formatNumber(record.odp)}</span></div>
              <div><span className="block text-slate-500">Tb</span><span className="text-slate-200">{formatNumber(record.boilingPointC)}°C</span></div>
            </div>
          </Link>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
        <GlassCard>
          <div className="eyebrow">Design logic</div>
          <h2 className="mt-3 section-title">Professional, but not old-fashioned.</h2>
          <p className="mt-4 leading-7 text-slate-300">
            The interface avoids the legacy database look by combining high-density scientific tables with polished cards, clear focus states, and modern export/API workflows. The visual system stays restrained so the data remains authoritative.
          </p>
          <ul className="mt-6 space-y-3 text-sm text-slate-300">
            <li>• Citation-first detail pages for academic trust.</li>
            <li>• Faceted search and range filters for screening workflows.</li>
            <li>• API and JSON/CSV export for reproducibility.</li>
            <li>• Data-source abstraction for future backend migration.</li>
          </ul>
        </GlassCard>
        <MiniLine records={records} keyName="gwp100" />
      </section>
    </div>
  );
}
