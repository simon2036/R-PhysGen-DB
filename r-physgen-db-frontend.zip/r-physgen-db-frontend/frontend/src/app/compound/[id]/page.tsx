import Link from "next/link";
import { notFound } from "next/navigation";
import { GlassCard } from "@/components/glass-card";
import { PropertyGrid } from "@/components/property-grid";
import { SourceList } from "@/components/source-list";
import { MiniLine } from "@/components/mini-line";
import { getCompoundById, loadCompounds, loadDataset } from "@/lib/data.server";
import { makeApiUrl, makeCitation } from "@/lib/format";

export async function generateStaticParams() {
  const records = await loadCompounds();
  return records.map((record) => ({ id: record.id }));
}

export default async function CompoundDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [compound, records, dataset] = await Promise.all([getCompoundById(id), loadCompounds(), loadDataset()]);
  if (!compound) notFound();

  const citation = makeCitation(compound, String(dataset.meta.version ?? "0.1.0"));
  const apiUrl = makeApiUrl(compound.id);

  return (
    <div className="space-y-8">
      <section className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <GlassCard>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="eyebrow">Compound record</div>
              <h1 className="mt-3 text-5xl font-semibold tracking-tight text-white">{compound.id}</h1>
              <p className="mt-3 text-xl text-slate-300">{compound.name}</p>
              <p className="mt-2 font-mono text-sm text-cyan">{compound.formula}{compound.cas ? ` · CAS ${compound.cas}` : ""}</p>
            </div>
            <span className="rounded-full border border-amber/30 bg-amber/10 px-4 py-2 text-sm font-semibold text-amber">{compound.safety}</span>
          </div>
          {compound.notes ? <p className="mt-6 max-w-3xl leading-7 text-slate-300">{compound.notes}</p> : null}
          <div className="mt-6 flex flex-wrap gap-2">
            {compound.tags.map((tag) => <span key={tag} className="rounded-full border border-line bg-white/5 px-3 py-1 text-xs text-slate-300">{tag}</span>)}
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={`/compare?ids=${encodeURIComponent(compound.id)}`} className="btn-primary">Start comparison</Link>
            <Link href="/database" className="btn-secondary">Back to database</Link>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="eyebrow">Structure metadata</div>
          <div className="mt-5 rounded-3xl border border-cyan/20 bg-cyan/[0.08] p-6">
            <div className="text-sm text-slate-400">SMILES</div>
            <div className="mt-2 break-all font-mono text-cyan">{compound.structure?.smiles ?? "Not available"}</div>
          </div>
          <div className="mt-4 rounded-3xl border border-line bg-white/5 p-6">
            <div className="text-sm text-slate-400">Confidence</div>
            <div className="mt-2 text-2xl font-semibold capitalize text-white">{compound.confidence}</div>
          </div>
        </GlassCard>
      </section>

      <section className="space-y-4">
        <div>
          <div className="eyebrow">Properties</div>
          <h2 className="mt-2 text-3xl font-semibold text-white">Thermophysical and environmental indicators</h2>
        </div>
        <PropertyGrid compound={compound} />
      </section>

      <section className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <GlassCard>
          <div className="eyebrow">Sources</div>
          <h2 className="mt-2 text-2xl font-semibold text-white">Traceable references</h2>
          <div className="mt-5"><SourceList sources={compound.sourceRefs} /></div>
        </GlassCard>
        <MiniLine records={records} keyName="criticalTempK" />
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <GlassCard>
          <div className="eyebrow">Citation</div>
          <h2 className="mt-2 text-2xl font-semibold text-white">Cite this record</h2>
          <pre className="mt-5 overflow-auto rounded-2xl border border-line bg-ink/80 p-4 text-sm leading-6 text-slate-300">{citation}</pre>
        </GlassCard>
        <GlassCard>
          <div className="eyebrow">API</div>
          <h2 className="mt-2 text-2xl font-semibold text-white">Programmatic access</h2>
          <pre className="mt-5 overflow-auto rounded-2xl border border-line bg-ink/80 p-4 text-sm leading-6 text-cyan">GET {apiUrl}</pre>
        </GlassCard>
      </section>
    </div>
  );
}
