import type { Compound } from "./types";

export type CompoundQuery = {
  text?: string;
  generations?: string[];
  safety?: string[];
  tags?: string[];
  gwpMax?: number;
  odpMax?: number;
  bpMin?: number;
  bpMax?: number;
  tcritMin?: number;
  tcritMax?: number;
  pcritMin?: number;
  pcritMax?: number;
  requireSource?: boolean;
};

function includesAny(value: string, targets?: string[]): boolean {
  if (!targets || targets.length === 0) return true;
  const normalized = value.toLowerCase();
  return targets.some((target) => normalized === target.toLowerCase());
}

function inRange(value: number | null | undefined, min?: number, max?: number): boolean {
  if (min === undefined && max === undefined) return true;
  if (value === null || value === undefined || Number.isNaN(value)) return false;
  if (min !== undefined && value < min) return false;
  if (max !== undefined && value > max) return false;
  return true;
}

function textHaystack(record: Compound): string {
  return [
    record.id,
    record.name,
    record.formula,
    record.cas,
    record.generation,
    record.category,
    record.safety,
    record.notes,
    record.structure?.smiles,
    ...record.tags,
    ...record.sourceRefs.map((source) => source.label)
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

export function filterCompounds(records: Compound[], query: CompoundQuery): Compound[] {
  const text = query.text?.trim().toLowerCase();
  return records.filter((record) => {
    if (text && !textHaystack(record).includes(text)) return false;
    if (!includesAny(record.generation, query.generations)) return false;
    if (!includesAny(record.safety, query.safety)) return false;
    if (query.tags?.length) {
      const recordTags = new Set(record.tags.map((tag) => tag.toLowerCase()));
      if (!query.tags.some((tag) => recordTags.has(tag.toLowerCase()))) return false;
    }
    if (!inRange(record.gwp100, undefined, query.gwpMax)) return false;
    if (!inRange(record.odp, undefined, query.odpMax)) return false;
    if (!inRange(record.boilingPointC, query.bpMin, query.bpMax)) return false;
    if (!inRange(record.criticalTempK, query.tcritMin, query.tcritMax)) return false;
    if (!inRange(record.criticalPressureMPa, query.pcritMin, query.pcritMax)) return false;
    if (query.requireSource && record.sourceRefs.length === 0) return false;
    return true;
  });
}

export function uniqueSorted(records: Compound[], selector: (record: Compound) => string): string[] {
  return Array.from(new Set(records.map(selector).filter(Boolean))).sort((a, b) => a.localeCompare(b));
}

export function parseNumberParam(value: string | null): number | undefined {
  if (value === null || value.trim() === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function parseListParam(value: string | null): string[] | undefined {
  if (!value) return undefined;
  return value.split(",").map((part) => part.trim()).filter(Boolean);
}
