import { z } from "zod";

export const sourceRefSchema = z.object({
  id: z.string(),
  label: z.string(),
  type: z.enum(["repository", "paper", "standard", "external", "computed", "experimental"]).default("repository"),
  year: z.number().int().optional(),
  doi: z.string().optional(),
  url: z.string().url().optional()
});

export const compoundSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  formula: z.string().min(1),
  cas: z.string().optional(),
  generation: z.string().min(1),
  category: z.string().min(1),
  safety: z.string().min(1),
  gwp100: z.number().nullable().optional(),
  odp: z.number().nullable().optional(),
  boilingPointC: z.number().nullable().optional(),
  criticalTempK: z.number().nullable().optional(),
  criticalPressureMPa: z.number().nullable().optional(),
  molecularWeight: z.number().nullable().optional(),
  densityLiquidKgM3: z.number().nullable().optional(),
  vaporPressureKPa25C: z.number().nullable().optional(),
  confidence: z.enum(["reviewed", "experimental", "computed", "estimated", "draft"]).default("draft"),
  tags: z.array(z.string()).default([]),
  notes: z.string().optional(),
  structure: z.object({
    smiles: z.string().optional(),
    inchi: z.string().optional(),
    image: z.string().optional()
  }).optional(),
  sourceRefs: z.array(sourceRefSchema).default([])
});

export const datasetSchema = z.object({
  meta: z.object({
    datasetName: z.string().default("R-PhysGen-DB"),
    version: z.string().default("0.1.0"),
    updatedAt: z.string().default("unknown"),
    disclaimer: z.string().optional()
  }).default({}),
  records: z.array(compoundSchema)
});

export type SourceRef = z.infer<typeof sourceRefSchema>;
export type Compound = z.infer<typeof compoundSchema>;
export type Dataset = z.infer<typeof datasetSchema>;

export type NumericPropertyKey =
  | "gwp100"
  | "odp"
  | "boilingPointC"
  | "criticalTempK"
  | "criticalPressureMPa"
  | "molecularWeight"
  | "densityLiquidKgM3"
  | "vaporPressureKPa25C";
