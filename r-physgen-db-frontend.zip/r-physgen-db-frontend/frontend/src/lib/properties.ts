import type { NumericPropertyKey } from "./types";

export type PropertyDefinition = {
  key: NumericPropertyKey;
  label: string;
  shortLabel: string;
  unit: string;
  help: string;
  better: "lower" | "higher" | "contextual";
};

export const PROPERTY_DEFINITIONS: PropertyDefinition[] = [
  {
    key: "gwp100",
    label: "100-year Global Warming Potential",
    shortLabel: "GWP100",
    unit: "CO₂-eq",
    help: "Lower values are preferred for low-climate-impact screening.",
    better: "lower"
  },
  {
    key: "odp",
    label: "Ozone Depletion Potential",
    shortLabel: "ODP",
    unit: "relative",
    help: "Zero is preferred for ozone-layer protection.",
    better: "lower"
  },
  {
    key: "boilingPointC",
    label: "Normal Boiling Point",
    shortLabel: "Tb",
    unit: "°C",
    help: "Used to screen operating pressure and cycle suitability.",
    better: "contextual"
  },
  {
    key: "criticalTempK",
    label: "Critical Temperature",
    shortLabel: "Tcrit",
    unit: "K",
    help: "Higher values can simplify subcritical cycle design, but interpretation is application dependent.",
    better: "contextual"
  },
  {
    key: "criticalPressureMPa",
    label: "Critical Pressure",
    shortLabel: "Pcrit",
    unit: "MPa",
    help: "Relevant for compressor and heat-exchanger pressure envelope design.",
    better: "contextual"
  },
  {
    key: "molecularWeight",
    label: "Molecular Weight",
    shortLabel: "MW",
    unit: "g/mol",
    help: "Useful for transport-property and mass-flow comparisons.",
    better: "contextual"
  },
  {
    key: "densityLiquidKgM3",
    label: "Liquid Density",
    shortLabel: "ρliq",
    unit: "kg/m³",
    help: "Approximate saturated-liquid density value used in engineering screening.",
    better: "contextual"
  },
  {
    key: "vaporPressureKPa25C",
    label: "Vapor Pressure at 25°C",
    shortLabel: "Pvap 25°C",
    unit: "kPa",
    help: "Useful for pressure-level comparison at ambient temperature.",
    better: "contextual"
  }
];

export const PROPERTY_BY_KEY = Object.fromEntries(
  PROPERTY_DEFINITIONS.map((property) => [property.key, property])
) as Record<NumericPropertyKey, PropertyDefinition>;
