import "server-only";

import fs from "node:fs/promises";
import path from "node:path";
import { datasetSchema, type Compound } from "./types";

async function exists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function resolveDatasetPath(): Promise<string> {
  const cwd = process.cwd();
  const candidates = [
    process.env.R_PHYSGEN_DATA_PATH ? path.resolve(cwd, process.env.R_PHYSGEN_DATA_PATH) : undefined,
    path.resolve(cwd, "public/data/compounds.json"),
    path.resolve(cwd, "../data/compounds.json"),
    path.resolve(cwd, "../data/refrigerants.json"),
    path.resolve(cwd, "../database/compounds.json")
  ].filter(Boolean) as string[];

  for (const candidate of candidates) {
    if (await exists(candidate)) return candidate;
  }

  throw new Error(`No R-PhysGen-DB dataset found. Checked: ${candidates.join(", ")}`);
}

let cache: { path: string; loadedAt: number; records: Compound[]; meta: Record<string, unknown> } | null = null;

export async function loadDataset() {
  const datasetPath = await resolveDatasetPath();
  if (cache?.path === datasetPath && Date.now() - cache.loadedAt < 30_000) {
    return cache;
  }

  const raw = await fs.readFile(datasetPath, "utf8");
  const parsed = JSON.parse(raw);
  const normalized = Array.isArray(parsed) ? { meta: {}, records: parsed } : parsed;
  const dataset = datasetSchema.parse(normalized);

  cache = {
    path: datasetPath,
    loadedAt: Date.now(),
    records: dataset.records.sort((a, b) => a.id.localeCompare(b.id)),
    meta: dataset.meta
  };

  return cache;
}

export async function loadCompounds(): Promise<Compound[]> {
  return (await loadDataset()).records;
}

export async function getCompoundById(id: string): Promise<Compound | undefined> {
  const normalizedId = decodeURIComponent(id).toLowerCase();
  const records = await loadCompounds();
  return records.find((record) => record.id.toLowerCase() === normalizedId);
}
