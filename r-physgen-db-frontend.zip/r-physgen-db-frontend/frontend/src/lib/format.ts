import type { Compound, NumericPropertyKey } from "./types";
import { PROPERTY_BY_KEY } from "./properties";

export function formatNumber(value: number | null | undefined, digits = 2): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  if (Math.abs(value) >= 100) return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);
  if (Math.abs(value) >= 10) return new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(value);
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: digits }).format(value);
}

export function formatProperty(compound: Compound, key: NumericPropertyKey): string {
  const definition = PROPERTY_BY_KEY[key];
  const value = compound[key];
  if (value === null || value === undefined) return "—";
  return `${formatNumber(value)} ${definition.unit}`;
}

export function propertyTone(key: NumericPropertyKey, value: number | null | undefined): "good" | "warn" | "neutral" {
  if (value === null || value === undefined) return "neutral";
  if (key === "gwp100") return value <= 10 ? "good" : value <= 150 ? "warn" : "neutral";
  if (key === "odp") return value === 0 ? "good" : "warn";
  return "neutral";
}

export function clsx(...values: Array<string | false | null | undefined>): string {
  return values.filter(Boolean).join(" ");
}

export function toCsv(records: Compound[]): string {
  const headers = [
    "id", "name", "formula", "cas", "generation", "category", "safety", "gwp100", "odp",
    "boilingPointC", "criticalTempK", "criticalPressureMPa", "molecularWeight", "confidence", "tags"
  ];
  const escape = (value: unknown) => {
    const text = Array.isArray(value) ? value.join(";") : String(value ?? "");
    return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  };
  return [
    headers.join(","),
    ...records.map((record) => headers.map((key) => escape((record as unknown as Record<string, unknown>)[key])).join(","))
  ].join("\n");
}

export function makeCitation(compound: Compound, version = "0.1.0"): string {
  return `R-PhysGen-DB Consortium. ${compound.id}: ${compound.name}. R-PhysGen-DB, version ${version}. Accessed ${new Date().toISOString().slice(0, 10)}.`;
}

export function makeApiUrl(compoundId?: string): string {
  if (compoundId) return `/api/compounds/${encodeURIComponent(compoundId)}`;
  return "/api/compounds?q=R-1234yf&gwpMax=150&safety=A2L";
}
