import type { ReactNode } from "react";
import { clsx } from "@/lib/format";

export function GlassCard({
  children,
  className
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={clsx("rounded-3xl border border-line/80 bg-panel/80 p-6 shadow-card backdrop-blur", className)}>
      {children}
    </section>
  );
}
