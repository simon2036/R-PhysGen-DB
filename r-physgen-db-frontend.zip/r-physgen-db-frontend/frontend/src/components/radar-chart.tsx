import type { Compound, NumericPropertyKey } from "@/lib/types";
import { PROPERTY_BY_KEY } from "@/lib/properties";

const METRICS: NumericPropertyKey[] = ["gwp100", "boilingPointC", "criticalTempK", "criticalPressureMPa", "molecularWeight"];

function scale(records: Compound[], key: NumericPropertyKey, value: number | null | undefined): number {
  if (typeof value !== "number") return 0.1;
  const values = records.map((record) => record[key]).filter((candidate): candidate is number => typeof candidate === "number");
  const min = Math.min(...values);
  const max = Math.max(...values);
  if (!Number.isFinite(min) || !Number.isFinite(max) || max === min) return 0.55;
  const raw = (value - min) / (max - min);
  return key === "gwp100" ? 1 - raw : raw;
}

function polygonPoints(record: Compound, records: Compound[], radius: number, cx: number, cy: number): string {
  return METRICS.map((key, index) => {
    const angle = -Math.PI / 2 + (index * 2 * Math.PI) / METRICS.length;
    const factor = 0.18 + scale(records, key, record[key]) * 0.78;
    const x = cx + Math.cos(angle) * radius * factor;
    const y = cy + Math.sin(angle) * radius * factor;
    return `${x},${y}`;
  }).join(" ");
}

export function RadarChart({ records }: { records: Compound[] }) {
  const cx = 160;
  const cy = 150;
  const radius = 105;
  const selected = records.slice(0, 6);

  return (
    <div className="rounded-3xl border border-line bg-white/5 p-5">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold text-white">Normalized property profile</div>
          <div className="text-xs text-slate-400">GWP is inverted: higher area means lower climate impact in this chart.</div>
        </div>
      </div>
      <svg viewBox="0 0 320 310" className="mx-auto h-80 w-full max-w-xl" role="img" aria-label="Compound comparison radar chart">
        {[0.25, 0.5, 0.75, 1].map((factor) => (
          <polygon
            key={factor}
            points={METRICS.map((_, index) => {
              const angle = -Math.PI / 2 + (index * 2 * Math.PI) / METRICS.length;
              return `${cx + Math.cos(angle) * radius * factor},${cy + Math.sin(angle) * radius * factor}`;
            }).join(" ")}
            fill="none"
            stroke="rgba(148,163,184,0.18)"
          />
        ))}
        {METRICS.map((key, index) => {
          const angle = -Math.PI / 2 + (index * 2 * Math.PI) / METRICS.length;
          const x = cx + Math.cos(angle) * (radius + 20);
          const y = cy + Math.sin(angle) * (radius + 20);
          return (
            <g key={key}>
              <line x1={cx} y1={cy} x2={cx + Math.cos(angle) * radius} y2={cy + Math.sin(angle) * radius} stroke="rgba(148,163,184,0.16)" />
              <text x={x} y={y} textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="11">
                {PROPERTY_BY_KEY[key].shortLabel}
              </text>
            </g>
          );
        })}
        {selected.map((record, index) => {
          const colors = ["#50e3ff", "#63f0b4", "#ffd166", "#bd8cff", "#ff6b7a", "#5d8dff"];
          return (
            <polygon
              key={record.id}
              points={polygonPoints(record, selected, radius, cx, cy)}
              fill={colors[index % colors.length]}
              fillOpacity="0.10"
              stroke={colors[index % colors.length]}
              strokeWidth="2.5"
            />
          );
        })}
      </svg>
    </div>
  );
}
