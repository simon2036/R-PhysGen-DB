"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { Compound } from "@/lib/types";
import { filterCompounds, uniqueSorted } from "@/lib/search";
import { formatNumber, toCsv } from "@/lib/format";

function download(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function ToggleGroup({
  label,
  options,
  selected,
  setSelected
}: {
  label: string;
  options: string[];
  selected: string[];
  setSelected: (next: string[]) => void;
}) {
  return (
    <fieldset className="space-y-2">
      <legend className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">{label}</legend>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const active = selected.includes(option);
          return (
            <button
              key={option}
              type="button"
              onClick={() => setSelected(active ? selected.filter((item) => item !== option) : [...selected, option])}
              className={`rounded-full border px-3 py-1.5 text-xs transition ${active ? "border-cyan bg-cyan/15 text-cyan" : "border-line bg-white/5 text-slate-300 hover:border-cyan/50"}`}
            >
              {option}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

function RangeInput({ label, value, setValue, placeholder }: { label: string; value: string; setValue: (value: string) => void; placeholder: string }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">{label}</span>
      <input
        value={value}
        onChange={(event) => setValue(event.target.value)}
        inputMode="decimal"
        placeholder={placeholder}
        className="mt-2 w-full rounded-2xl border border-line bg-ink/70 px-4 py-3 text-sm text-white outline-none placeholder:text-slate-600 focus:border-cyan/70"
      />
    </label>
  );
}

function asNumber(value: string): number | undefined {
  if (!value.trim()) return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function ExplorerClient({ records, initialQuery = "" }: { records: Compound[]; initialQuery?: string }) {
  const [query, setQuery] = useState(initialQuery);
  const [generations, setGenerations] = useState<string[]>([]);
  const [safety, setSafety] = useState<string[]>([]);
  const [gwpMax, setGwpMax] = useState("150");
  const [odpMax, setOdpMax] = useState("0");
  const [bpMin, setBpMin] = useState("");
  const [bpMax, setBpMax] = useState("");
  const [tcritMin, setTcritMin] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const generationOptions = useMemo(() => uniqueSorted(records, (record) => record.generation), [records]);
  const safetyOptions = useMemo(() => uniqueSorted(records, (record) => record.safety), [records]);

  const filtered = useMemo(
    () => filterCompounds(records, {
      text: query,
      generations,
      safety,
      gwpMax: asNumber(gwpMax),
      odpMax: asNumber(odpMax),
      bpMin: asNumber(bpMin),
      bpMax: asNumber(bpMax),
      tcritMin: asNumber(tcritMin)
    }),
    [records, query, generations, safety, gwpMax, odpMax, bpMin, bpMax, tcritMin]
  );

  function toggleSelection(id: string) {
    setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id].slice(-6));
  }

  const compareHref = `/compare?ids=${encodeURIComponent(selectedIds.join(","))}`;

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <aside className="space-y-6 rounded-3xl border border-line bg-panel/80 p-5 shadow-card">
        <div>
          <div className="text-lg font-semibold text-white">Advanced filters</div>
          <p className="mt-2 text-sm leading-6 text-slate-400">Use scientific filters first, then inspect records with citations and source metadata.</p>
        </div>
        <label className="block">
          <span className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">Unified search</span>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="R-1234yf, C3H2F4, A2L, low-GWP..."
            className="mt-2 w-full rounded-2xl border border-line bg-ink/70 px-4 py-3 text-sm text-white outline-none placeholder:text-slate-600 focus:border-cyan/70"
          />
        </label>
        <ToggleGroup label="Generation" options={generationOptions} selected={generations} setSelected={setGenerations} />
        <ToggleGroup label="Safety" options={safetyOptions} selected={safety} setSelected={setSafety} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
          <RangeInput label="GWP max" value={gwpMax} setValue={setGwpMax} placeholder="150" />
          <RangeInput label="ODP max" value={odpMax} setValue={setOdpMax} placeholder="0" />
          <RangeInput label="Tb min °C" value={bpMin} setValue={setBpMin} placeholder="-60" />
          <RangeInput label="Tb max °C" value={bpMax} setValue={setBpMax} placeholder="0" />
          <RangeInput label="Tcrit min K" value={tcritMin} setValue={setTcritMin} placeholder="330" />
        </div>
        <div className="rounded-2xl border border-cyan/20 bg-cyan/[0.08] p-4 text-sm text-slate-300">
          <div className="font-semibold text-cyan">{filtered.length} matched records</div>
          <div className="mt-1 text-xs text-slate-400">{selectedIds.length} selected for comparison. Keep comparison to 2–6 records.</div>
        </div>
      </aside>

      <section className="overflow-hidden rounded-3xl border border-line bg-panel/80 shadow-card">
        <div className="flex flex-col gap-4 border-b border-line p-5 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-white">Database Explorer</h1>
            <p className="mt-1 text-sm text-slate-400">High-density table with source-aware scientific records.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => download("r-physgen-filtered.json", JSON.stringify(filtered, null, 2), "application/json")} className="btn-secondary">Export JSON</button>
            <button onClick={() => download("r-physgen-filtered.csv", toCsv(filtered), "text/csv")} className="btn-secondary">Export CSV</button>
            <Link aria-disabled={selectedIds.length < 2} href={selectedIds.length >= 2 ? compareHref : "#"} className={`btn-primary ${selectedIds.length < 2 ? "pointer-events-none opacity-50" : ""}`}>Compare selected</Link>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-line text-sm">
            <thead className="bg-white/5 text-left text-xs uppercase tracking-[0.18em] text-slate-500">
              <tr>
                <th className="px-5 py-4">Compare</th>
                <th className="px-5 py-4">ID</th>
                <th className="px-5 py-4">Name</th>
                <th className="px-5 py-4">Formula</th>
                <th className="px-5 py-4">GWP100</th>
                <th className="px-5 py-4">ODP</th>
                <th className="px-5 py-4">Safety</th>
                <th className="px-5 py-4">Tb</th>
                <th className="px-5 py-4">Tcrit</th>
                <th className="px-5 py-4">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/70">
              {filtered.map((record) => (
                <tr key={record.id} className="transition hover:bg-white/5">
                  <td className="px-5 py-4">
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(record.id)}
                      onChange={() => toggleSelection(record.id)}
                      aria-label={`Select ${record.id} for comparison`}
                      className="h-4 w-4 rounded border-line bg-ink text-cyan focus:ring-cyan"
                    />
                  </td>
                  <td className="px-5 py-4 font-mono text-cyan"><Link href={`/compound/${encodeURIComponent(record.id)}`} className="hover:underline">{record.id}</Link></td>
                  <td className="px-5 py-4 text-white">{record.name}</td>
                  <td className="px-5 py-4 font-mono text-slate-300">{record.formula}</td>
                  <td className="px-5 py-4 text-mint">{formatNumber(record.gwp100)}</td>
                  <td className="px-5 py-4 text-mint">{formatNumber(record.odp)}</td>
                  <td className="px-5 py-4"><span className="rounded-full border border-amber/30 bg-amber/10 px-2 py-1 text-xs text-amber">{record.safety}</span></td>
                  <td className="px-5 py-4 text-slate-300">{formatNumber(record.boilingPointC)} °C</td>
                  <td className="px-5 py-4 text-slate-300">{formatNumber(record.criticalTempK)} K</td>
                  <td className="px-5 py-4 text-slate-400">{record.sourceRefs.length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
