import type { Compound } from "@/lib/types";
import { PROPERTY_DEFINITIONS } from "@/lib/properties";
import { PropertyBadge } from "./property-badge";

export function PropertyGrid({ compound }: { compound: Compound }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {PROPERTY_DEFINITIONS.map((property) => (
        <PropertyBadge key={property.key} compound={compound} keyName={property.key} />
      ))}
    </div>
  );
}
