"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function HeroSearch() {
  const router = useRouter();
  const [query, setQuery] = useState("");

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const params = query.trim() ? `?q=${encodeURIComponent(query.trim())}` : "";
    router.push(`/database${params}`);
  }

  return (
    <form onSubmit={onSubmit} className="glass-search flex flex-col gap-3 rounded-[2rem] border border-cyan/30 bg-white/[0.07] p-3 shadow-glow md:flex-row">
      <label className="sr-only" htmlFor="global-search">Search R-PhysGen-DB</label>
      <input
        id="global-search"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search by R-code, formula, CAS, SMILES, property range, or source"
        className="min-h-12 flex-1 rounded-3xl border border-transparent bg-ink/80 px-5 text-base text-white outline-none placeholder:text-slate-500 focus:border-cyan/70"
      />
      <button className="rounded-3xl bg-cyan px-7 py-3 font-semibold text-ink transition hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">
        Search database
      </button>
    </form>
  );
}
