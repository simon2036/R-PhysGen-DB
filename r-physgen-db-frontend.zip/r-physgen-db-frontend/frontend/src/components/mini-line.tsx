import type { Compound, NumericPropertyKey } from "@/lib/types";
import { PROPERTY_BY_KEY } from "@/lib/properties";

export function MiniLine({ records, keyName }: { records: Compound[]; keyName: NumericPropertyKey }) {
  const values = records.map((record) => record[keyName]).filter((value): value is number => typeof value === "number");

  if (values.length === 0) {
    return (
      <div className="rounded-3xl border border-line bg-white/5 p-5">
        <div className="text-sm font-semibold text-white">{PROPERTY_BY_KEY[keyName].label}</div>
        <div className="mt-2 text-sm text-slate-400">No numeric values available for this property.</div>
      </div>
    );
  }

  const min = Math.min(...values);
  const max = Math.max(...values);
  const points = records.map((record, index) => {
    const value = typeof record[keyName] === "number" ? record[keyName] as number : min;
    const x = 20 + index * (260 / Math.max(records.length - 1, 1));
    const y = 90 - ((value - min) / Math.max(max - min, 1)) * 70;
    return `${x},${y}`;
  }).join(" ");

  return (
    <div className="rounded-3xl border border-line bg-white/5 p-5">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold text-white">{PROPERTY_BY_KEY[keyName].label}</div>
          <div className="text-xs text-slate-400">Dataset distribution sketch</div>
        </div>
        <div className="text-xs text-slate-500">{PROPERTY_BY_KEY[keyName].unit}</div>
      </div>
      <svg viewBox="0 0 300 110" className="h-28 w-full" role="img" aria-label={`${PROPERTY_BY_KEY[keyName].label} distribution`}>
        <path d="M20 95H285" stroke="rgba(148,163,184,0.25)" />
        <polyline fill="none" stroke="#5d8dff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" points={points} />
        {points.split(" ").map((point) => {
          const [x, y] = point.split(",").map(Number);
          return <circle key={point} cx={x} cy={y} r="4" fill="#50e3ff" />;
        })}
      </svg>
    </div>
  );
}
