import type { Compound, NumericPropertyKey } from "@/lib/types";
import { PROPERTY_BY_KEY } from "@/lib/properties";
import { formatNumber, propertyTone } from "@/lib/format";

const toneClass = {
  good: "border-mint/40 bg-mint/10 text-mint",
  warn: "border-amber/40 bg-amber/10 text-amber",
  neutral: "border-line bg-white/5 text-white"
};

export function PropertyBadge({ compound, keyName }: { compound: Compound; keyName: NumericPropertyKey }) {
  const definition = PROPERTY_BY_KEY[keyName];
  const value = compound[keyName];
  const tone = propertyTone(keyName, value);

  return (
    <div className={`rounded-2xl border p-4 ${toneClass[tone]}`} title={definition.help}>
      <div className="text-xs uppercase tracking-[0.22em] text-slate-400">{definition.shortLabel}</div>
      <div className="mt-2 text-2xl font-semibold">{formatNumber(value)}</div>
      <div className="mt-1 text-xs text-slate-400">{definition.unit}</div>
    </div>
  );
}
