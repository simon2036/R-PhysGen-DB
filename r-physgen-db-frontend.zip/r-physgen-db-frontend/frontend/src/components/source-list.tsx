import type { SourceRef } from "@/lib/types";

export function SourceList({ sources }: { sources: SourceRef[] }) {
  if (!sources.length) {
    return <p className="text-sm text-slate-400">No source metadata attached yet. Add sourceRefs to the dataset record before publication.</p>;
  }

  return (
    <div className="space-y-3">
      {sources.map((source) => (
        <div key={source.id} className="rounded-2xl border border-line bg-white/5 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-cyan/30 bg-cyan/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.18em] text-cyan">
              {source.type}
            </span>
            {source.year ? <span className="text-xs text-slate-400">{source.year}</span> : null}
          </div>
          <div className="mt-2 text-sm font-medium text-white">{source.label}</div>
          {source.doi ? <div className="mt-1 text-xs text-slate-400">DOI: {source.doi}</div> : null}
          {source.url ? (
            <a className="mt-1 block text-xs text-cyan underline-offset-4 hover:underline" href={source.url} target="_blank" rel="noreferrer">
              Open source
            </a>
          ) : null}
        </div>
      ))}
    </div>
  );
}
