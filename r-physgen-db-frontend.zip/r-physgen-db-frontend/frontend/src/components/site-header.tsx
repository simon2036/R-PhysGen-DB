import Link from "next/link";

const navItems = [
  { href: "/database", label: "Database" },
  { href: "/compare", label: "Compare" },
  { href: "/docs", label: "API Docs" },
  { href: "/submit", label: "Submit" }
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-line/70 bg-ink/[0.82] backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="group flex items-center gap-3" aria-label="R-PhysGen-DB home">
          <span className="grid h-10 w-10 place-items-center rounded-2xl border border-cyan/40 bg-cyan/10 text-cyan shadow-glow">
            R
          </span>
          <span>
            <span className="block text-sm uppercase tracking-[0.32em] text-cyan/80">R-PhysGen-DB</span>
            <span className="block text-xs text-slate-400">Physical-property database</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-2 md:flex" aria-label="Main navigation">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="rounded-full px-4 py-2 text-sm text-slate-300 transition hover:bg-white/[0.08] hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-cyan">
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
