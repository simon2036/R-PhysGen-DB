import { GlassCard } from "./glass-card";

export function StatCard({ label, value, helper }: { label: string; value: string | number; helper?: string }) {
  return (
    <GlassCard className="p-5">
      <div className="text-3xl font-semibold text-cyan">{value}</div>
      <div className="mt-1 text-sm font-medium text-white">{label}</div>
      {helper ? <div className="mt-2 text-xs leading-5 text-slate-400">{helper}</div> : null}
    </GlassCard>
  );
}
