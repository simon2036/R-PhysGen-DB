"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import type { Compound } from "@/lib/types";
import { RadarChart } from "./radar-chart";
import { formatNumber } from "@/lib/format";

export function CompareClient({ records, initialIds = [] }: { records: Compound[]; initialIds?: string[] }) {
  const [selectedIds, setSelectedIds] = useState<string[]>(initialIds.length ? initialIds : records.slice(0, 3).map((record) => record.id));
  const selected = useMemo(() => records.filter((record) => selectedIds.includes(record.id)).slice(0, 6), [records, selectedIds]);

  function toggle(id: string) {
    setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id].slice(-6));
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <aside className="rounded-3xl border border-line bg-panel/80 p-5 shadow-card">
        <h2 className="text-lg font-semibold text-white">Select compounds</h2>
        <p className="mt-2 text-sm leading-6 text-slate-400">Choose 2–6 records. The chart normalizes values inside the selected set.</p>
        <div className="mt-5 max-h-[620px] space-y-2 overflow-auto pr-2">
          {records.map((record) => (
            <button
              key={record.id}
              onClick={() => toggle(record.id)}
              className={`w-full rounded-2xl border p-3 text-left transition ${selectedIds.includes(record.id) ? "border-cyan bg-cyan/10" : "border-line bg-white/5 hover:border-cyan/40"}`}
            >
              <span className="block font-mono text-sm text-cyan">{record.id}</span>
              <span className="block text-xs text-slate-400">{record.name}</span>
            </button>
          ))}
        </div>
      </aside>

      <section className="space-y-6">
        <RadarChart records={selected} />
        <div className="overflow-hidden rounded-3xl border border-line bg-panel/80 shadow-card">
          <table className="min-w-full divide-y divide-line text-sm">
            <thead className="bg-white/5 text-left text-xs uppercase tracking-[0.18em] text-slate-500">
              <tr>
                <th className="px-5 py-4">ID</th>
                <th className="px-5 py-4">GWP100</th>
                <th className="px-5 py-4">ODP</th>
                <th className="px-5 py-4">Safety</th>
                <th className="px-5 py-4">Tb</th>
                <th className="px-5 py-4">Tcrit</th>
                <th className="px-5 py-4">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/70">
              {selected.map((record) => (
                <tr key={record.id} className="hover:bg-white/5">
                  <td className="px-5 py-4 font-mono text-cyan">{record.id}</td>
                  <td className="px-5 py-4 text-mint">{formatNumber(record.gwp100)}</td>
                  <td className="px-5 py-4 text-mint">{formatNumber(record.odp)}</td>
                  <td className="px-5 py-4 text-amber">{record.safety}</td>
                  <td className="px-5 py-4 text-slate-300">{formatNumber(record.boilingPointC)} °C</td>
                  <td className="px-5 py-4 text-slate-300">{formatNumber(record.criticalTempK)} K</td>
                  <td className="px-5 py-4"><Link className="text-cyan hover:underline" href={`/compound/${encodeURIComponent(record.id)}`}>Open</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
