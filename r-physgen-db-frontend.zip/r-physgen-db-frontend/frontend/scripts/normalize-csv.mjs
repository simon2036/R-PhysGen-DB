#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const [input, output = "public/data/compounds.json"] = process.argv.slice(2);

if (!input) {
  console.error("Usage: node scripts/normalize-csv.mjs <input.csv> [output.json]");
  process.exit(1);
}

function parseCsv(text) {
  const rows = [];
  let current = "";
  let row = [];
  let quoted = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"' && quoted && next === '"') {
      current += '"';
      i++;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(current.trim());
      current = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i++;
      row.push(current.trim());
      if (row.some((cell) => cell.length)) rows.push(row);
      row = [];
      current = "";
    } else {
      current += char;
    }
  }
  row.push(current.trim());
  if (row.some((cell) => cell.length)) rows.push(row);
  return rows;
}

function num(value) {
  if (value === undefined || value === null || String(value).trim() === "") return null;
  const normalized = String(value).replace(/[<>~≈]/g, "").trim();
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function pick(row, ...keys) {
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== "") return row[key];
  }
  return undefined;
}

const raw = fs.readFileSync(input, "utf8");
const [headers, ...body] = parseCsv(raw);
const normalizedHeaders = headers.map((header) => header.trim().toLowerCase().replaceAll(" ", "_").replaceAll("-", "_"));
const rows = body.map((cells) => Object.fromEntries(normalizedHeaders.map((header, index) => [header, cells[index] ?? ""])));

const records = rows.map((row) => ({
  id: pick(row, "id", "code", "r_code", "refrigerant") ?? "UNKNOWN",
  name: pick(row, "name", "compound", "chemical_name") ?? pick(row, "id", "code") ?? "Unknown compound",
  formula: pick(row, "formula", "molecular_formula") ?? "unknown",
  cas: pick(row, "cas", "cas_number", "casrn"),
  generation: pick(row, "generation", "class", "family") ?? "unclassified",
  category: pick(row, "category", "type") ?? "single-fluid",
  safety: pick(row, "safety", "ashrae_safety", "safety_class") ?? "unknown",
  gwp100: num(pick(row, "gwp100", "gwp_100", "gwp")),
  odp: num(pick(row, "odp", "ozone_depletion_potential")),
  boilingPointC: num(pick(row, "boilingpointc", "boiling_point_c", "normal_boiling_point_c", "tb_c")),
  criticalTempK: num(pick(row, "criticaltempk", "critical_temp_k", "tcrit_k", "tc_k")),
  criticalPressureMPa: num(pick(row, "criticalpressurempa", "critical_pressure_mpa", "pcrit_mpa", "pc_mpa")),
  molecularWeight: num(pick(row, "molecularweight", "molecular_weight", "mw")),
  densityLiquidKgM3: num(pick(row, "density_liquid_kg_m3", "liquid_density")),
  vaporPressureKPa25C: num(pick(row, "vapor_pressure_kpa_25c", "pvap_25c")),
  confidence: pick(row, "confidence") ?? "draft",
  tags: (pick(row, "tags") ?? "").split(/[;|]/).map((tag) => tag.trim()).filter(Boolean),
  notes: pick(row, "notes", "comment", "remarks"),
  structure: {
    smiles: pick(row, "smiles"),
    inchi: pick(row, "inchi")
  },
  sourceRefs: [{
    id: pick(row, "source_id") ?? "repository-csv",
    label: pick(row, "source", "reference", "source_label") ?? "Repository CSV import",
    type: "repository"
  }]
}));

const dataset = {
  meta: {
    datasetName: "R-PhysGen-DB",
    version: new Date().toISOString().slice(0, 10),
    updatedAt: new Date().toISOString().slice(0, 10),
    disclaimer: "Generated from CSV. Review units, sourceRefs, and confidence before publication."
  },
  records
};

fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, JSON.stringify(dataset, null, 2));
console.log(`Wrote ${records.length} records to ${output}`);
