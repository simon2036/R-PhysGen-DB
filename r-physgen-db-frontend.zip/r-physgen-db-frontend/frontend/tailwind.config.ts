import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "sans-serif"],
        mono: ["JetBrains Mono", "SFMono-Regular", "Consolas", "monospace"]
      },
      colors: {
        ink: "#07111f",
        panel: "#0b1729",
        panel2: "#0d1f34",
        line: "#284461",
        cyan: "#50e3ff",
        prism: "#5d8dff",
        mint: "#63f0b4",
        amber: "#ffd166",
        danger: "#ff6b7a"
      },
      boxShadow: {
        glow: "0 0 40px rgba(80, 227, 255, 0.12)",
        card: "0 16px 40px rgba(0, 0, 0, 0.28)"
      }
    }
  },
  plugins: []
};

export default config;
