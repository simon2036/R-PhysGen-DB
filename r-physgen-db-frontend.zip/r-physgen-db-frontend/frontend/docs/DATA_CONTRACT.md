# R-PhysGen-DB Frontend Data Contract

The frontend reads a JSON file with this shape:

```json
{
  "meta": {
    "datasetName": "R-PhysGen-DB",
    "version": "0.1.0",
    "updatedAt": "2026-04-24",
    "disclaimer": "Optional note"
  },
  "records": [
    {
      "id": "R-1234yf",
      "name": "2,3,3,3-Tetrafluoropropene",
      "formula": "C3H2F4",
      "cas": "754-12-1",
      "generation": "HFO",
      "category": "single-fluid",
      "safety": "A2L",
      "gwp100": 0.5,
      "odp": 0,
      "boilingPointC": -29.5,
      "criticalTempK": 367.85,
      "criticalPressureMPa": 3.38,
      "molecularWeight": 114.04,
      "confidence": "reviewed",
      "tags": ["low-GWP"],
      "notes": "Optional note",
      "structure": { "smiles": "C=C(F)C(F)(F)F" },
      "sourceRefs": [
        { "id": "source-1", "label": "Paper or standard title", "type": "paper", "year": 2026, "doi": "optional" }
      ]
    }
  ]
}
```

## Required field rules

- `id`, `name`, `formula`, `generation`, `category`, and `safety` are required.
- Missing numeric values must be `null`, not `0`.
- Every published record should include at least one `sourceRef`.
- Every property value shown to users must have a unit in the frontend property definition.
- Use `confidence` to distinguish curated experimental values from computed or estimated values.

## Recommended publication workflow

1. Normalize raw CSV/Excel data to JSON.
2. Validate source references and units.
3. Run `pnpm typecheck` and `pnpm build`.
4. Open `/database`, `/compare`, `/api/compounds`, and several `/compound/[id]` pages.
5. Add citation text and dataset version before deployment.
