# Implementation Plan

## Phase 1 — Frontend MVP

1. Add this `frontend/` folder to the repository root.
2. Use the bundled demo dataset to verify UI and API behavior.
3. Map the repository's real database file into `public/data/compounds.json` using `scripts/normalize-csv.mjs` or by writing a direct JSON export.
4. Validate detail pages, export buttons, and API endpoint responses.
5. Deploy as a Next.js app.

## Phase 2 — Data credibility layer

1. Add source pages for standards, papers, and computed workflows.
2. Introduce per-property source mapping instead of record-level source mapping if the database contains mixed provenance.
3. Add unit conversion and canonical units.
4. Add dataset version history and changelog.
5. Add downloadable BibTeX and citation files.

## Phase 3 — Research workflow features

1. Saved searches and shareable query URLs.
2. Similarity search by formula/SMILES or property vector.
3. Compare view with application profiles, such as mobile AC, heat pumps, chillers, industrial refrigeration.
4. Authenticated data submission and curator review states.
5. Backed API using SQLite/PostgreSQL instead of file-based JSON.

## Phase 4 — Publication-quality deployment

1. Add DOI, institution/lab identity, and citation metadata.
2. Add accessibility audit and keyboard navigation test.
3. Add server-side caching for large datasets.
4. Add API rate limiting and downloadable bulk dataset archives.
5. Add documentation pages for methodology and data limitations.
