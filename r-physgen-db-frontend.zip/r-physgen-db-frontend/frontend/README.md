# R-PhysGen-DB Frontend

A modern academic database frontend for the `simon2036/R-PhysGen-DB` repository.

The implementation is intentionally placed inside `frontend/` so it can be added to the current repository without changing existing data or backend code.

## What this frontend provides

- A professional landing page for an academic database.
- Unified search by refrigerant code, formula, name, CAS, source, notes, and tags.
- Advanced faceted filtering for generation, safety class, GWP, ODP, boiling point, critical temperature, critical pressure, and source availability.
- High-density result table with export to CSV / JSON.
- Compound detail pages with property cards, source references, citation block, API example, and comparison entry point.
- Multi-compound comparison page with normalized radar visualization.
- REST-style API endpoints for programmatic access.
- CSV normalization script to map repository data into the frontend data contract.

## Quick start

```bash
cd frontend
pnpm install
pnpm dev
```

Then open `http://localhost:3000`.

Equivalent npm commands:

```bash
cd frontend
npm install
npm run dev
```

## Data source strategy

By default, the frontend reads sample data from:

```text
frontend/public/data/compounds.json
```

For the real repository dataset, set:

```bash
cp .env.example .env.local
```

Then edit:

```text
R_PHYSGEN_DATA_PATH=../data/compounds.json
```

The loader checks these paths in order:

1. `R_PHYSGEN_DATA_PATH`
2. `frontend/public/data/compounds.json`
3. `../data/compounds.json`
4. `../data/refrigerants.json`
5. `../database/compounds.json`

## Converting a CSV dataset

If the repository has a CSV table, normalize it with:

```bash
node scripts/normalize-csv.mjs ../data/raw_refrigerants.csv public/data/compounds.json
```

The script maps common column names such as `id`, `code`, `formula`, `cas`, `gwp`, `odp`, `boiling_point_c`, `critical_temp_k`, `critical_pressure_mpa`, and `safety`.

## API endpoints

```text
GET /api/compounds
GET /api/compounds?q=R-1234yf&gwpMax=150&safety=A2L
GET /api/compounds/R-1234yf
```

The API response includes a `meta` object and typed `records`.

## Production build

```bash
pnpm build
pnpm start
```

For static deployment, use a platform that supports Next.js App Router server functions, because data loading and API routes use server-side file reads.

## Design principles

1. Scientific credibility first: every property should carry unit, method/source, confidence, and citation metadata.
2. Modern but not decorative: deep navy background, glass data cards, sparse grid, high-density tables, clear focus states.
3. Database usability: advanced filters, saved query shape, export, copyable API URL, and BibTeX/citation block.
4. Evolvability: data source is abstracted so the frontend can start with JSON/CSV and later move to SQLite/PostgreSQL/API.
