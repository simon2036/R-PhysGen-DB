# 科研任务就绪性验证草案（P0 Draft）

## 1. 为什么要加这层验证

当前 `validate.py` 已经覆盖了：

- schema checks
- integration checks
- inventory checks
- quality gate checks

这对数据库工程足够好，但对科研任务仍不够。
因为“表存在”不等于“可用于第五代制冷剂设计任务”。

P0 建议新增一层：

- `research_task_readiness`

它回答的是：
- 这套数据能否做单组分候选 down-selection？
- 能否做多任务核心标签训练？
- 能否做 canonical strict ML slice？
- 能否支撑下一步的 cycle / quantum 增量接入？

## 2. 建议定义的任务

### TASK-01 `single_component_downselection`
目标：
用于单组分候选的约束筛选。

最低要求：
- 有明确 `mol_id`
- 有 `boiling_point_c`
- 有 `critical_temp_c`
- 有 `critical_pressure_mpa`
- 有 `gwp_100yr` 或版本化 GWP
- 有 `odp`
- 至少一个安全标签

### TASK-02 `core_multitask_training`
目标：
训练 V1 当前的核心多任务属性预测器。

最低要求：
- 在 promoted subset 内
- 标签必须 numeric / categorical 可消费
- 不允许无来源推荐值
- 对 proxy 行有明确策略

### TASK-03 `canonical_strict_ml`
目标：
使用 canonical strict 层进行高可信度 ML。

最低要求：
- 来自 `property_recommended_canonical_strict`
- 满足 readiness rule
- 不使用开放 review queue 中的行

### TASK-04 `phase2_cycle_seed`
目标：
为后续多工况循环试算提供候选种子。

最低要求：
- identity 完整
- 至少有基础热物性
- CoolProp / EOS source 状态明确
- 不处于明确的 structure ambiguity

## 3. 建议新增表

建议新增：
- `research_task_readiness_rules`
- （可选）`research_task_readiness_report`

## 4. 验证规则建议

### 4.1 completeness
按任务定义必需属性集合，检查 coverage。

### 4.2 source eligibility
检查推荐值是否来自允许的 source type / quality level。

### 4.3 proxy policy
检查某任务是否允许 proxy-only 行进入。

### 4.4 strict compatibility
检查 strict 层与任务定义是否一致。

### 4.5 split eligibility
检查任务是否要求 `model_inclusion=yes`、是否只能在 promoted subset 上运行。

## 5. 输出形式建议

建议在 `validation_report.json` 里增加：

```json
{
  "research_task_readiness": {
    "single_component_downselection": {...},
    "core_multitask_training": {...},
    "canonical_strict_ml": {...},
    "phase2_cycle_seed": {...}
  }
}
```

## 6. 与现有验证的关系

- 现有验证继续保留；
- 新验证是更上层的任务视角，不替代 schema / integration checks；
- 二者一起构成“数据库工程可用 + 科研任务可用”的双层保证。