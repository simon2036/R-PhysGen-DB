# Phase 2 接口草案（P0 Draft）

## 1. 目标

现有 `quantum_calculation`、`cycle_simulation`、`active_learning_queue` 仍停留在 placeholder 级别。
P0 的目标不是立刻实现这些服务，而是把它们定义成“以后任何实现者都能无歧义对接”的接口契约。

核心规则保持不变：

- Phase 2 输出必须回写到 `property_observation` 或其扩展表；
- 所有外部计算、外部服务或手工审阅都必须登记进 `source_manifest`；
- 任何增量结果都必须可以追溯到 `mol_id`、运行方法、工况和产物路径。

## 2. Quantum Calculation 接口草案

### 2.1 Request
建议请求对象至少包含：

- `request_id`
- `mol_id`
- `isomeric_smiles`
- `charge`
- `spin_multiplicity`
- `conformer_policy`
- `method_family`
- `program`
- `model_chemistry`
- `basis_set`
- `solvation_model`
- `target_properties`
- `artifact_root`
- `metadata`

### 2.2 Result
建议结果对象至少包含：

- `request_id`
- `run_id`
- `status`
- `failure_reason`
- `program_version`
- `wall_time_s`
- `artifact_manifest`
- `derived_observations`
- `quality_level`
- `notes`

### 2.3 Write-back 规则
量子结果不直接写入 `model_ready`。
应先落到：

- `source_manifest`
- `property_observation`
- （可选）`quantum_job` / `quantum_artifact` 扩展表

建议优先写回以下属性：

- HOMO
- LUMO
- HOMO-LUMO gap
- dipole moment
- polarizability
- total energy
- zero-point energy
- frequency convergence status

这些值必须带：
- `method`
- `software`
- `basis_set`
- `temperature`（若适用）
- `phase`
- `quality_level`
- `uncertainty`
- `notes`

## 3. Cycle Simulation 接口草案

### 3.1 Request
建议请求对象至少包含：

- `request_id`
- `mol_id`
- `fluid_name`
- `cycle_case_id`
- `operating_point`
- `cycle_model`
- `eos_source`
- `compressor_efficiency`
- `artifact_root`
- `metadata`

### 3.2 Result
建议结果对象至少包含：

- `request_id`
- `run_id`
- `status`
- `cycle_case_id`
- `operating_point_hash`
- `artifact_manifest`
- `derived_observations`
- `convergence_flag`
- `warning_flags`
- `notes`

### 3.3 Write-back 规则
循环结果不应只产出摘要分数。
建议至少回写：

- `cop`
- `volumetric_cooling`
- `pressure_ratio`
- `discharge_temperature`
- `evaporating_pressure`
- `condensing_pressure`
- `specific_cooling_capacity`
- `compressor_work`
- `cycle_convergence_flag`

这类 observation 应引用：

- `cycle_case_id`
- `condition_set_id`
- `method`
- `source_id`

## 4. Active Learning Queue 接口草案

### 4.1 Entry
建议队列条目至少包含：

- `queue_entry_id`
- `mol_id`
- `acquisition_strategy`
- `priority_score`
- `uncertainty_score`
- `novelty_score`
- `feasibility_score`
- `hard_constraint_status`
- `recommended_next_action`
- `payload`

### 4.2 Allowed next actions
- `run_quantum`
- `run_cycle`
- `manual_curation`
- `literature_search`
- `defer`
- `reject`

### 4.3 设计原则
主动学习队列不直接改数据库主结果。
它只负责：
- 记录为什么某个分子被选中；
- 指向下一步应该补什么标签；
- 保证新数据回流后能够解释“为什么是这批分子”。

## 5. 建议新增扩展表

P0 不强制实现，但建议预留：

- `quantum_job`
- `quantum_artifact`
- `cycle_case`
- `cycle_result`
- `active_learning_queue`
- `active_learning_decision_log`

## 6. 与现有仓库的兼容策略

- `interfaces.py` 先只增加 dataclass 和协议，不接真实后端；
- `build_dataset()` 仍可保持 V1 运行；
- 未来任何 Phase 2 服务只要遵守本草案，就能增量接入，不需要重构 data contract。