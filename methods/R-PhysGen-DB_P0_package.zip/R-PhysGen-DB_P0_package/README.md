# R-PhysGen-DB P0 Draft Package

本文件包用于把当前评审结论直接落成可执行草案，范围只覆盖 P0 级事项：

1. 明确 P0 范围、交付件与退出标准；
2. 把 `phase2_interfaces` 从“占位说明”提升为“可对接接口草案”；
3. 把 `property_observation` 的条件语义从松散字符串提升为规范化 schema 草案；
4. 给出 `pipeline.py` 的 stage 化改造方案与代码蓝图；
5. 补一套科研任务就绪性的验证规则草案。

目录说明：

- `docs/`
  - `p0_scope_and_exit_criteria.md`
  - `p0_phase2_interfaces_draft.md`
  - `p0_pipeline_stage_refactor_plan.md`
  - `p0_validation_rules_draft.md`
- `schemas/drafts/`
  - `observation_condition_set.yaml`
  - `property_observation_v2.yaml`
  - `stage_run_manifest.yaml`
  - `research_task_readiness_rules.yaml`
- `src/blueprints/`
  - `pipeline_staged_blueprint.py`

使用建议：

- 先把 `docs/p0_scope_and_exit_criteria.md` 过一遍，确认 P0 边界；
- 再审 `schemas/drafts/`，决定哪些列先在 V1.5 落地、哪些先保留兼容层；
- 最后按 `docs/p0_pipeline_stage_refactor_plan.md` 和 `src/blueprints/pipeline_staged_blueprint.py` 开始拆 `src/r_physgen_db/pipeline.py`。