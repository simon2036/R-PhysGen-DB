"""Blueprint for stage-oriented R-PhysGen-DB pipeline refactor.

This file is intentionally a draft blueprint rather than production code.
Its purpose is to make the P0 stage split concrete before editing the live
`src/r_physgen_db/pipeline.py`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable


@dataclass(slots=True)
class ArtifactRef:
    name: str
    path: Path
    exists: bool = False
    notes: str = ""


@dataclass(slots=True)
class StageResult:
    stage_id: str
    status: str
    outputs: list[ArtifactRef] = field(default_factory=list)
    row_count_summary: dict[str, int] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    notes: str = ""


@dataclass(slots=True)
class BuildContext:
    project_root: Path
    data_dir: Path
    run_id: str
    refresh_remote: bool = False
    config: dict[str, Any] = field(default_factory=dict)
    artifacts: dict[str, ArtifactRef] = field(default_factory=dict)
    state: dict[str, Any] = field(default_factory=dict)

    def register_artifact(self, name: str, path: Path, notes: str = "") -> ArtifactRef:
        ref = ArtifactRef(name=name, path=path, exists=path.exists(), notes=notes)
        self.artifacts[name] = ref
        return ref

    def get_artifact(self, name: str) -> ArtifactRef | None:
        return self.artifacts.get(name)


StageCallable = Callable[[BuildContext], StageResult]


@dataclass(slots=True)
class StageSpec:
    stage_id: str
    stage_name: str
    order: int
    func: StageCallable
    required_inputs: tuple[str, ...] = ()
    produced_outputs: tuple[str, ...] = ()


def stage00_init_run(ctx: BuildContext) -> StageResult:
    # TODO:
    # - initialize output directories
    # - initialize stage_run_manifest row
    # - load runtime config
    return StageResult(stage_id="00", status="succeeded", notes="init_run blueprint")


def stage01_load_inventory(ctx: BuildContext) -> StageResult:
    # TODO:
    # - read seed_catalog.csv
    # - read manual_property_observations.csv
    # - read observations/*.csv
    # - read coolprop_aliases.yaml
    # - register input artifacts
    return StageResult(stage_id="01", status="succeeded", notes="load_inventory blueprint")


def stage02_resolve_identity(ctx: BuildContext) -> StageResult:
    # TODO:
    # - resolve PubChem / bulk PubChem lookup
    # - standardize smiles
    # - build molecule_core and molecule_alias
    return StageResult(stage_id="02", status="succeeded", notes="resolve_identity blueprint")


def stage03_acquire_global_sources(ctx: BuildContext) -> StageResult:
    # TODO:
    # - fetch EPA technology transitions GWP table
    # - fetch EPA ODS table
    # - fetch EPA SNAP pages
    # - register source_manifest rows for global sources
    return StageResult(stage_id="03", status="succeeded", notes="acquire_global_sources blueprint")


def stage04_acquire_entity_sources(ctx: BuildContext) -> StageResult:
    # TODO:
    # - fetch NIST snapshots for entity rows
    # - generate CoolProp observations
    # - populate seed_resolution
    return StageResult(stage_id="04", status="succeeded", notes="acquire_entity_sources blueprint")


def stage05_harmonize_observations(ctx: BuildContext) -> StageResult:
    # TODO:
    # - merge manual / EPA / NIST / CoolProp / Excel inputs
    # - normalize into property_observation
    # - create observation_condition_set where possible
    # - run QC
    return StageResult(stage_id="05", status="succeeded", notes="harmonize_observations blueprint")


def stage06_integrate_governance_bundle(ctx: BuildContext) -> StageResult:
    # TODO:
    # - call integrate_property_governance_bundle(...)
    # - persist extension mirror
    # - persist canonical overlay / strict / review queue
    return StageResult(stage_id="06", status="succeeded", notes="integrate_governance_bundle blueprint")


def stage07_build_feature_and_recommendation_layers(ctx: BuildContext) -> StageResult:
    # TODO:
    # - build property_recommended
    # - compute structure_features
    # - build molecule_master and property_matrix
    return StageResult(stage_id="07", status="succeeded", notes="build_feature_and_recommendation_layers blueprint")


def stage08_build_model_outputs(ctx: BuildContext) -> StageResult:
    # TODO:
    # - build model_dataset_index
    # - build model_ready
    # - keep compatibility with current gold outputs
    return StageResult(stage_id="08", status="succeeded", notes="build_model_outputs blueprint")


def stage09_validate_and_publish(ctx: BuildContext) -> StageResult:
    # TODO:
    # - run validate_dataset()
    # - emit quality_report.json
    # - write duckdb index
    # - update stage_run_manifest
    return StageResult(stage_id="09", status="succeeded", notes="validate_and_publish blueprint")


STAGES: tuple[StageSpec, ...] = (
    StageSpec("00", "init_run", 0, stage00_init_run),
    StageSpec("01", "load_inventory", 1, stage01_load_inventory),
    StageSpec("02", "resolve_identity", 2, stage02_resolve_identity),
    StageSpec("03", "acquire_global_sources", 3, stage03_acquire_global_sources),
    StageSpec("04", "acquire_entity_sources", 4, stage04_acquire_entity_sources),
    StageSpec("05", "harmonize_observations", 5, stage05_harmonize_observations),
    StageSpec("06", "integrate_governance_bundle", 6, stage06_integrate_governance_bundle),
    StageSpec("07", "build_feature_and_recommendation_layers", 7, stage07_build_feature_and_recommendation_layers),
    StageSpec("08", "build_model_outputs", 8, stage08_build_model_outputs),
    StageSpec("09", "validate_and_publish", 9, stage09_validate_and_publish),
)


def build_dataset_staged(
    project_root: Path,
    data_dir: Path,
    run_id: str,
    *,
    refresh_remote: bool = False,
    selected_stage_ids: Iterable[str] | None = None,
    stop_after: str | None = None,
) -> list[StageResult]:
    ctx = BuildContext(
        project_root=project_root,
        data_dir=data_dir,
        run_id=run_id,
        refresh_remote=refresh_remote,
    )

    enabled = set(selected_stage_ids) if selected_stage_ids is not None else None
    results: list[StageResult] = []

    for spec in STAGES:
        if enabled is not None and spec.stage_id not in enabled:
            continue

        result = spec.func(ctx)
        results.append(result)

        if result.status != "succeeded":
            break

        if stop_after is not None and spec.stage_id == stop_after:
            break

    return results


if __name__ == "__main__":
    # Example only; replace with real CLI integration when adopted.
    import uuid

    run_id = f"draft-{uuid.uuid4().hex[:8]}"
    results = build_dataset_staged(
        project_root=Path(".").resolve(),
        data_dir=Path("./data").resolve(),
        run_id=run_id,
        refresh_remote=False,
    )
    for item in results:
        print(item.stage_id, item.status, item.notes)